#ifndef UTILS_H
#define UTILS_H
#include <string.h>

size_t bstrcpy(char *dest, size_t size, const char *src);

#endif