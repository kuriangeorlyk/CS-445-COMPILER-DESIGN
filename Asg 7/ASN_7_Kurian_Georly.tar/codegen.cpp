#define NUM_OPS 20
#include "codegen.h"
#include "emitcode.h"
#include "symbolTable.h"
#include "TokenTree.h"
#include <stack>
#include "string.h"
int idfor;
int idflag;
int indexOffset=0;
// Prototypes
void _generateCode(TokenTree *tree);

char flag[20];
extern TokenTree *syntaxTree;
extern SymbolTable *symbolTable;
extern int globalOffset;
int initLine = -1;

int tOffset = globalOffset;
int fOffset;
char fileName[100];
std::stack<int> lastLineOfWhile;

//FOr loop
int forOff = 0, forLoc = 0, forSkp = 0;
int doingFor = false;

void lineSep() {
    emitComment((char *) "** ** ** ** ** ** ** ** ** ** ** **");
}

void funcHeader(char *funcName)
{
    lineSep();
    char *line;
    asprintf(&line, "FUNCTION %s", funcName);
    emitComment(line);
    free(line);

    // //TOFF
    // asprintf(&line, ">>TOFF set: %d", tOffset);
    // emitComment(line);

    // Save function address!
    TokenTree *func = (TokenTree *) symbolTable->lookupGlobal(funcName);
    // if (func == NULL) {
    //     //throw std::runtime_error("ERROR: Symbol table lookup error.");
    // }
    func->setMemoryOffset(emitSkip(0));

    // char buffer[10];
    // sprintf(buffer, "%d", tOffset);
    // emitComment((char *) ">>TOFF set: ",buffer);  
    // printf("%d\n",func->getMemorySize());
    // //if(strcmp(funcName,"main")==0)
    // {
    //     emitComment((char *) ">>TOFF set: ",buffer);  
    // }


    emitRM((char *) "ST", 3, -1, 1, (char *) "Store return address");
}

void popLeftIntoAC1()
{
    tOffset++; 
    //tOffset++;//IMP
    // emitRM((char *) "LD", AC1, tOffset, 1, (char *) "Pop left hand side into AC1");
    emitRM((char *) "LD", AC1, tOffset, 1, (char *) "Pop left into ac1");//may tOffset-1 is correct in tM developed by SIr
    //tOffset--;//IMP
}

// END of a function Occures
void standardClosing()  
{
    emitComment((char *) "Add standard closing in case there is no return statement");
    emitRM((char *) "LDC", 2, 0, 6, (char *) "Set return value to 0");
    emitRM((char *) "LD", 3, -1, 1, (char *) "Load return address");
    emitRM((char *) "LD", 1, 0, 1, (char *) "Adjust fp");
    emitGoto(0, 3, (char *) "Return");
}

//END of FUNCTION
void funcFooter(char *funcName, bool includeStdClosing) 
{
    char *line;
    if (includeStdClosing) {
        standardClosing();
    }
    asprintf(&line, "END FUNCTION %s", funcName);
    emitComment(line);
    free(line);
    // if(strcmp(funcName,"main")!=0)
    // {
    //     emitComment((char *) "");
    // }
      
    
}

void funcFooter(char *funcName) {
    funcFooter(funcName, false);
}

//Displaing the file name and Header
void generateHeader()
{
    emitComment((char *) "C- compiler version C-S21");
    emitComment((char *) "Built: Apr 18, 2021 (toffset telemetry)");
    emitComment((char *) "Author: Robert B. Heckendorn");
    emitComment((char *) "File compiled: ",fileName);
    emitComment((char *) ""); 
}

void jumpToFunction(char *funcName) {
    char *comment;
    asprintf(&comment, "Jump to %s", funcName);
    TokenTree *func = (TokenTree *) symbolTable->lookupGlobal(funcName);
    emitGotoAbs(func->getMemoryOffset(), comment);
    free(comment);
}

void handlePlus(TokenTree *tree) {
    popLeftIntoAC1();
    emitRO((char *) "ADD", AC, AC1, AC, (char *) "Op +");
}

void handleChSignOrMinus(TokenTree *tree) {
    if (tree->children[1] == NULL) {
        emitRO((char *) "NEG", 3, 3, 3, (char *) "Op unary -");
    } else {
        popLeftIntoAC1();
        emitRO((char *) "SUB", AC, AC1, AC, (char *) "Op -");
    }
}

void handleSizeOfOrTimes(TokenTree *tree) 
{
    if (tree->children[1] == NULL) 
    {
        char *line;
        asprintf(&line, "Load address of base array %s", tree->children[0]->getStringValue());
        if (tree->children[0]->isInGlobalMemory()) 
        {
            emitRM((char *) "LDA", AC, tree->children[0]->getMemoryOffset(), GP, line);
        } 
        else 
        {
            if (tree->children[0]->getMemoryType() == MemoryType::PARAM) 
            {
                emitRM((char *) "LD", AC, tree->children[0]->getMemoryOffset(), FP, line);
            } 
            else 
            {
                emitRM((char *) "LDA", AC, tree->children[0]->getMemoryOffset(), FP, line);
            }
        }
        free(line);
        emitRM((char *) "LD", AC, 1, AC, (char *) "Load array size");
    } 
    else 
    {
        popLeftIntoAC1();
        emitRO((char *) "MUL", AC, AC1, AC, (char *) "Op *");
    }
}

void handleEquality(TokenTree *tree) {
    popLeftIntoAC1();
    emitRO((char *) "TEQ", AC, AC1, AC, (char *) "Op =");
}

void handleNotEquality(TokenTree *tree) {
    popLeftIntoAC1();
    emitRO((char *) "TNE", AC, AC1, AC, (char *) "Op ><");
}

void handleAnd(TokenTree *tree) {
    popLeftIntoAC1();
    // emitRO((char *) "AND", AC, AC1, AC, (char *) "AND operation store in AC");
    emitRO((char *) "AND", AC, AC1, AC, (char *) "Op AND");
}

void handleOr(TokenTree *tree) {
    popLeftIntoAC1();
    // emitRO((char *) "OR", AC, AC1, AC, (char *) "OR operation store in AC");
    emitRO((char *) "OR", AC, AC1, AC, (char *) "Op OR");
}

void handleRand(TokenTree *tree) {
    emitRO((char *) "RND", AC, AC, 0, (char *) "Gen rand between 0 and value of AC1 in AC");
}

void handleLEQ(TokenTree *tree) 
{
    popLeftIntoAC1();
    emitRO((char *) "TLE", AC, AC1, AC, (char *) "LEQ <= operation store in AC");
}

void handleLessThan(TokenTree *tree) 
{
    popLeftIntoAC1();
     if(tree->children[0]->isArray() && tree->children[1]->isArray())
    {

            emitRM((char*)"LD", 5, 1, 3, (char*)("AC2 <- |RHS|"));
            emitRM((char*)"LD", 6, 1, 4, (char*)("AC3 <- |LHS|"));
            emitRM((char*)"LDA", 2, 0, 5, (char*)("R2 <- |RHS|"));
            emitRO((char *)"SWP", 5, 6, 6, (char *)"pick smallest size");
            emitRM((char*)"LD", 6, 1, 4, (char*)("AC3 <- |LHS|"));
            emitRO((char*)"CO", 4, 3, 5, (char*)("setup array compare LHS vs RHS"));
            emitRO((char*)"TNE", 5, 4, 3, (char*)("if not equal then test"));
            emitRO((char*)"JNZ", 5, 2, 7, (char*)("jump not equal"));
            emitRM((char*)"LDA", 3, 0, 2, (char*)("AC1 <- |RHS|"));
            emitRM((char*)"LDA", 4, 0, 6, (char*)("AC <- |LHS|"));
    }
    emitRO((char *) "TLT", AC, AC1, AC, (char *) "Op <");
}

void handleGEQ(TokenTree *tree) {
    popLeftIntoAC1();
    emitRO((char *) "TGE", AC, AC1, AC, (char *) "GEQ >- operation store in AC");
}

//New 
//Handling !> and !<
void handleNotLessThan(TokenTree *tree) 
{
    popLeftIntoAC1();
     if(tree->children[0]->isArray() && tree->children[1]->isArray())
    {

            emitRM((char*)"LD", 5, 1, 3, (char*)("AC2 <- |RHS|"));
            emitRM((char*)"LD", 6, 1, 4, (char*)("AC3 <- |LHS|"));
            emitRM((char*)"LDA", 2, 0, 5, (char*)("R2 <- |RHS|"));
            emitRO((char *)"SWP", 5, 6, 6, (char *)"pick smallest size");
            emitRM((char*)"LD", 6, 1, 4, (char*)("AC3 <- |LHS|"));
            emitRO((char*)"CO", 4, 3, 5, (char*)("setup array compare LHS vs RHS"));
            emitRO((char*)"TNE", 5, 4, 3, (char*)("if not equal then test"));
            emitRO((char*)"JNZ", 5, 2, 7, (char*)("jump not equal"));
            emitRM((char*)"LDA", 3, 0, 2, (char*)("AC1 <- |RHS|"));
            emitRM((char*)"LDA", 4, 0, 6, (char*)("AC <- |LHS|"));
    }
    emitRO((char *) "TGE", AC, AC1, AC, (char *) "Op !<");    //Actually its !<
}

void handleNotGreaterThan(TokenTree *tree) 
{
    popLeftIntoAC1();
     if(tree->children[0]->isArray() && tree->children[1]->isArray())
    {

            emitRM((char*)"LD", 5, 1, 3, (char*)("AC2 <- |RHS|"));
            emitRM((char*)"LD", 6, 1, 4, (char*)("AC3 <- |LHS|"));
            emitRM((char*)"LDA", 2, 0, 5, (char*)("R2 <- |RHS|"));
            emitRO((char *)"SWP", 5, 6, 6, (char *)"pick smallest size");
            emitRM((char*)"LD", 6, 1, 4, (char*)("AC3 <- |LHS|"));
            emitRO((char*)"CO", 4, 3, 5, (char*)("setup array compare LHS vs RHS"));
            emitRO((char*)"TNE", 5, 4, 3, (char*)("if not equal then test"));
            emitRO((char*)"JNZ", 5, 2, 7, (char*)("jump not equal"));
            emitRM((char*)"LDA", 3, 0, 2, (char*)("AC1 <- |RHS|"));
            emitRM((char*)"LDA", 4, 0, 6, (char*)("AC <- |LHS|"));
    }

    emitRO((char *) "TLE", AC, AC1, AC, (char *) "Op !>"); //Actually its !>
}




void handleGreaterThan(TokenTree *tree) {
    popLeftIntoAC1();
    //printf("%s\n",tree->getStringValue());
    if(tree->children[0]->isArray() && tree->children[1]->isArray())
    {

            emitRM((char*)"LD", 5, 1, 3, (char*)("AC2 <- |RHS|"));
            emitRM((char*)"LD", 6, 1, 4, (char*)("AC3 <- |LHS|"));
            emitRM((char*)"LDA", 2, 0, 5, (char*)("R2 <- |RHS|"));
            emitRO((char *)"SWP", 5, 6, 6, (char *)"pick smallest size");
            emitRM((char*)"LD", 6, 1, 4, (char*)("AC3 <- |LHS|"));
            emitRO((char*)"CO", 4, 3, 5, (char*)("setup array compare LHS vs RHS"));
            emitRO((char*)"TNE", 5, 4, 3, (char*)("if not equal then test"));
            emitRO((char*)"JNZ", 5, 2, 7, (char*)("jump not equal"));
            emitRM((char*)"LDA", 3, 0, 2, (char*)("AC1 <- |RHS|"));
            emitRM((char*)"LDA", 4, 0, 6, (char*)("AC <- |LHS|"));
    }

    
    emitRO((char *) "TGT", AC, AC1, AC, (char *) "Op >");
}

void handleNotCG(TokenTree *tree) 
{
    //emitRM((char *) "LDC", AC1, 1, 0, (char *) "Load 1 into AC1 for not operation");
    emitRM((char *) "LDC", AC1, 1, 6, (char *) "Load 1");
    //Note: This line is wants change 300:    XOR  3,3,4        Op XOR to get logical not
    //emitRO((char * ) "XOR", AC, AC1, AC, (char * ) "Op XOR to get logical not");//machange AC and AC1 position
    emitRO((char * ) "TNE", AC, AC1, AC, (char * ) "Not ! operation store in AC");
}

void handleDivision(TokenTree *tree) {
    popLeftIntoAC1();
    emitRO((char *) "DIV", AC, AC1, AC, (char *) "Op /");
}

void handleMod(TokenTree *tree) {
    popLeftIntoAC1();
    emitRO((char *) "MOD", AC, AC1, AC, (char *) "Op %");
}

void handleUnimplemented(TokenTree *tree) {
    char *line;
    asprintf(&line, "Operation %s not implemented!", tree->getStringValue());
    //throw std::runtime_error(line);
}

void handleArrayAccessCG(TokenTree *tree) 
{
    
    if (tree->parent->getNodeKind() == NodeKind::EXPRESSION && tree->parent->getExprKind() == ExprKind::ASSIGN && tree->parent->children[0] == tree) {
        emitRM((char *) "ST", 3, tOffset, FP, (char *) " [ Push array index onto temp stack");
        tOffset--;
    } 
    else
    {
    //C7 pop left
    int flag1=0;
    if(strcmp(tree->parent->getStringValue(),"outputc")==0)
    if(tree->children[0]->isArray()  && (int)flag[10]==118&&strcmp( tree->children[0]->getTypeString2(),"char")==0) 
    {
        flag1=1;
        emitRM((char *)"LD", 4, tOffset+1, 1, (char *)"[ CH only Pop left into ac1");
    }
    TokenTree *arr = tree->children[0];
    char *line;
//C8 not needed for ch array
       // flag1 der mines char array 
       if(flag1==0)
        {
            asprintf(&line, "[ Load base address of array %s into AC2", arr->getStringValue());
            if (arr->isInGlobalMemory()) 
            {
                emitRM((char *) "LDA", AC2, arr->getMemoryOffset(), GP, line);
            } 
            else 
            {
                if (arr->getMemoryType() == MemoryType::PARAM) {
                    emitRM((char *) "LD", AC2, arr->getMemoryOffset(), FP, line);
                } else {
                    emitRM((char *) "LDA", AC2, arr->getMemoryOffset(), FP, line);
                }
            }            
            free(line);
        emitRO((char *) "SUB", AC2, AC2, AC, (char *) "[ Compute offset for array");
        //emitRO((char *) "SUB", AC2, AC2, AC, (char *) "compute location from index");

        asprintf(&line, "[ Load array element %s from AC into loc from AC2", arr->getStringValue());
        //asprintf(&line, "Load array element");
        emitRM((char *) "LD", AC, 0, AC2, line);
        free(line);
        }
//C9 only for Char array
        else
        {
           
        emitRO((char *) "SUB", 3, 4, AC, (char *) "[ Compute offset for array");
        asprintf(&line, "[ Load array element %s from AC into loc from AC2", arr->getStringValue());
        emitRM((char *) "LD", AC, 0, 3, line);
        free(line);
        }
    }
}

const char *operationsCodeGen[NUM_OPS] = {
    "!>",
    "!<",
    ">=",
    "<",
    "<=",
    ">",
    "and",
    "or",
    "not",
    "+",
    "-",
    "*",
    "/",
    "%",
    "++",
    "--",
    "?",
    "=",
    "!=",
    "["
};

void (*functionPointersCodeGen[NUM_OPS])(TokenTree *) = {
    handleNotGreaterThan, // GREATHER THAN
    handleNotLessThan, // LESS THAN
    handleLEQ, // LEQ
    handleLessThan, // LESS THAN
    handleGEQ, // GEQ
    handleGreaterThan, // GREATHER THAN
    handleAnd, // AND
    handleOr, // OR
    handleNotCG, // NOT
    handlePlus, // PLUS
    handleChSignOrMinus, // CHANGE SIGN OR MINUS
    handleSizeOfOrTimes, // SIZEOF OR TIMES
    handleDivision, // DIVISION
    handleMod, // MOD
    handleUnimplemented, // INC
    handleUnimplemented, // DEC
    handleRand, // RANDOM ?
    handleEquality, // EQUALS
    handleNotEquality, // NOT EQUALS
    handleArrayAccessCG, // ARRAY ACCESSOR []
};

int indexOfOperationCodeGen(TokenTree *tree) 
{
    for (int i = 0; i < NUM_OPS; i++) {
        if (strcmp(tree->getTokenString(), operationsCodeGen[i]) == 0) {
            return i;
        }
    }
    return -1;
}

//GLOBAL VARIABLES FOUND THEN
void initGlobal(TokenTree *tree) 
{
    for (int i = 0; i < MAX_CHILDREN; i++) {
        if (tree->children[i] != NULL) {
            initGlobal(tree->children[i]);
        }
    }
    if (tree->getNodeKind() == NodeKind::DECLARATION && tree->getDeclKind() == DeclKind::VARIABLE && tree->isInGlobalMemory()) 
    {
        if (tree->isArray()) 
        {
            char *line;
            asprintf(&line, "Load size of %s into AC", tree->getStringValue());
            //asprintf(&line, "load size of array %s", tree->getStringValue());
            emitRM((char *) "LDC", 3, tree->getMemorySize() - 1, 0, line);
            free(line);
            asprintf(&line, "Store size of %s in data memory", tree->getStringValue());
            //asprintf(&line, "save size of array %s", tree->getStringValue());
            emitRM((char *) "ST", 3, tree->getMemoryOffset() + 1, 0, line);
            free(line);
        } 
        else 
        {
            tree->setGenerated(false, true);
            for (int i = 0; i < MAX_CHILDREN; i++) {
                if (tree->children[i] != NULL) {
                    _generateCode(tree->children[i]);
                }
            }
            if (tree->children[0] != NULL) {
                char *line;
                asprintf(&line, "Assigning variable %s in %s", tree->getStringValue(), tree->getMemoryTypeString());
                emitRM((char *) "ST", AC, tree->getMemoryOffset(), 0, line);
                free(line);
            }
        }
    }

    if (tree->sibling != NULL) {
        initGlobal(tree->sibling);
    }
}

void processBreaks(TokenTree *whileParent, int lastLine, TokenTree *tree)
{
    if (tree == NULL) {
        return;
    }
    if (tree->getNodeKind() == NodeKind::STATEMENT && tree->getStmtKind() == StmtKind::BREAK) 
    {
        if (tree->hasLastLine()) {
            emitBackup(tree->getLastLine());
            tree->setHasLastLine(false);
            emitRMAbs((char *) "JMP", 0, lastLine, (char *) "Break statement backpatch jump");
        }
    }

    for (int i = 0; i < MAX_CHILDREN; i++) {
        TokenTree *child = tree->children[i];
        if (child != NULL) {
            processBreaks(whileParent, lastLine, child);
        }
    }

    if (tree->sibling != NULL) {
        processBreaks(whileParent, lastLine, tree->sibling);
    }
}

void processMathAssign(TokenTree *tree) 
{
    char *str = tree->getTokenString();
    if (strcmp(str, "+=") == 0) {
        emitRO((char *) "ADD", AC, AC1, AC, (char *) "op +=");
    } else if (strcmp(str, "-=") == 0) {
        emitRO((char *) "SUB", AC, AC1, AC, (char *) "op -=");
    } else if (strcmp(str, "*=") == 0) {
        emitRO((char *) "MUL", AC, AC1, AC, (char *) "op *=");
    } else if (strcmp(str, "/=") == 0) {
        emitRO((char *) "DIV", AC, AC1, AC, (char *) "op /=");
    } else if (strcmp(str, "++") == 0) {
        emitRM((char *) "LDA", AC, 1, AC1, (char *) "increment value of",tree->children[0]->getStringValue());
    } else if (strcmp(str, "--") == 0) {
        emitRM((char *) "LDA", AC, -1, AC1, (char *) "decrement value of",tree->children[0]->getStringValue());
    }
}

//THE INITIALIZATION part starts and END
void generateInit() 
{
    backPatchAJumpToHere(0, (char *) "Jump to init [backpatch]");
    emitComment((char *) "INIT");   
    //emitRM((char *) "LD", 0, 0, 0, (char *) "Set the global pointer");
    emitRM((char *) "LDA", 1, globalOffset, 0, (char *) "set first frame at end of globals");
    emitRM((char *) "ST", 1, 0, 1, (char *) "store old fp (point to self)");
    emitComment((char *) "INIT GLOBALS AND STATICS");
    initGlobal(syntaxTree);
    emitComment((char *) "END INIT GLOBALS AND STATICS");
    emitRM((char *) "LDA", 3, 1, 7, (char *) "Return address in ac");
    jumpToFunction((char *) "main");
    emitRO((char *) "HALT", 0, 0, 0, (char *) "DONE!");
    emitComment((char *) "END INIT");
}

void generateIOLibrary() 
{
    funcHeader((char *) "input");
    emitRO((char *) "IN", 2, 2, 2, (char *) "Grab int input");
    emitRM((char *) "LD", 3, -1, 1, (char *) "Load return address");
    emitRM((char *) "LD", 1, 0, 1, (char *) "Adjust fp");
    emitGoto(0, 3, (char *) "Return");
    funcFooter((char *) "input");
emitComment((char *) "");

    funcHeader((char *) "output");
    emitRM((char *) "LD", 3, -2, 1, (char *) "Load parameter");
    emitRO((char *) "OUT", 3, 3, 3, (char *) "Output integer");
    emitRM((char *) "LD", 3, -1, 1, (char *) "Load return address");
    emitRM((char *) "LD", 1, 0, 1, (char *) "Adjust fp");
    emitGoto(0, 3, (char *) "Return");
    funcFooter((char *) "output");
emitComment((char *) "");

    funcHeader((char *) "inputb");
    emitRO((char *) "INB", 2, 2, 2, (char *) "Grab bool input");
    emitRM((char *) "LD", 3, -1, 1, (char *) "Load return address");
    emitRM((char *) "LD", 1, 0, 1, (char *) "Adjust fp");
    emitGoto(0, 3, (char *) "Return");
    funcFooter((char *) "inputb");
emitComment((char *) "");

    funcHeader((char *) "outputb");
    emitRM((char *) "LD", 3, -2, 1, (char *) "Load parameter");
    emitRO((char *) "OUTB", 3, 3, 3, (char *) "Output bool");
    emitRM((char *) "LD", 3, -1, 1, (char *) "Load return address");
    emitRM((char *) "LD", 1, 0, 1, (char *) "Adjust fp");
    emitGoto(0, 3, (char *) "Return");
    funcFooter((char *) "outputb");
emitComment((char *) "");

    funcHeader((char *) "inputc");
    emitRO((char *) "INC", 2, 2, 2, (char *) "Grab char input");
    emitRM((char *) "LD", 3, -1, 1, (char *) "Load return address");
    emitRM((char *) "LD", 1, 0, 1, (char *) "Adjust fp");
    emitGoto(0, 3, (char *) "Return");
    funcFooter((char *) "inputc");
emitComment((char *) "");

    funcHeader((char *) "outputc");
    emitRM((char *) "LD", 3, -2, 1, (char *) "Load parameter");
    emitRO((char *) "OUTC", 3, 3, 3, (char *) "Output char");
    emitRM((char *) "LD", 3, -1, 1, (char *) "Load return address");
    emitRM((char *) "LD", 1, 0, 1, (char *) "Adjust fp");
    emitGoto(0, 3, (char *) "Return");
    funcFooter((char *) "outputc");
emitComment((char *) "");

    funcHeader((char *) "outnl");
    emitRO((char *) "OUTNL", 3, 3, 3, (char *) "Output a newline");
    emitRM((char *) "LD", 3, -1, 1, (char *) "Load return address");
    emitRM((char *) "LD", 1, 0, 1, (char *) "Adjust fp");
    emitGoto(0, 3, (char *) "Return");
    funcFooter((char *) "outnl");
emitComment((char *) "");
}

//---------------------------------------------------------------------------------------B4 Children---------------------

void beforeChildrenCodeGen(TokenTree *tree) 
{
    switch (tree->getNodeKind())
    {
        case NodeKind::DECLARATION: 
        {
            switch (tree->getDeclKind()) 
            {
                case DeclKind::FUNCTION:
                {
                    funcHeader(tree->getStringValue());
                    tOffset = -tree->getMemorySize();
                    fOffset = -2;
                    break;
                }
            }
            break;
        }
        case NodeKind::EXPRESSION: 
        {
            //emitComment((char *) "EXPRESSION");
            switch (tree->getExprKind()) 
            {
                case ExprKind::CALL: 
                {

                    //emitComment((char *) "EXPRESSION");
                    TokenTree *func = (TokenTree *) symbolTable->lookup(tree->getStringValue());
                    char *line;
                    asprintf(&line, "CALL%s", tree->getStringValue()); // HERE %S is FUNCTION NAME
                    emitComment(line);
                    asprintf(&line, "Store fp in ghost frame for %s", tree->getStringValue());
                    emitRM((char *) "ST", FP, tOffset, FP, (char *) line);
                    int previousFoffset = fOffset;
                    int previousTOffset = tOffset;
                    fOffset = tOffset - 2;
                    tOffset -= func->getMemorySize();
                    free(line);
                    //IF there is PArameters in function Call Then 
                    for (int i = 0; i < MAX_CHILDREN; i++) 
                    {
                        TokenTree *child = tree->children[i];
                        if (child != NULL) 
                        {
                            char *line2;
                            // asprintf(&line2, ">>TOFF set: %d", tOffset);
                            // emitComment(line2);

                            asprintf(&line, "Param %d", i+1); // HERE %S is FUNCTION NAME
                            emitComment(line);

                            _generateCode(child);

                            //emitStrLit(tree->children[0]->getMemoryOffset(), tree->children[0]->getStringValue() );
                            
                        }
                    }
                    //After Parameter Handling it works defaultly. ie. If there is no parameter then it also works PRAMETER END 
                    asprintf(&line, "Param end %s", tree->getStringValue()); // HERE %S is FUNCTION NAME
                    emitComment(line);
                    //emitComment((char *) "Begin call");
                    
                //emitRM((char *) "LDA", 1, previousTOffset, 1, (char *) "Move the fp to the new frame");
                emitRM((char *) "LDA", 1, previousTOffset, 1, (char *) "Ghost frame becomes new active frame");
                //emitRM((char *) "LDA", AC, 1, 7, (char *) "Store the return address in ac (skip 1 ahead)");
                emitRM((char *) "LDA", AC, 1, 7, (char *) "Return address in ac");

                    emitGotoAbs(func->getMemoryOffset(), (char *) "CALL ", tree->getStringValue());
                    tOffset += func->getMemorySize();
                    fOffset = previousFoffset;
                // emitRM((char *) "LDA", AC, 0, RT, (char *) "Save return result in accumulator");
                emitRM((char *) "LDA", AC, 0, RT, (char *) "Save the result in ac");
                    asprintf(&line, "Call end %s", tree->getStringValue());
                    emitComment(line);

                    // char *line2;
                    // asprintf(&line2, ">>TOFF set: %d", tOffset);
                    // emitComment(line2);

                    free(line);
                    break;
                }
                 // A CONSTANT DECLARATION OCCURES eg:  666; 
                 //AND   IF it is a fun Call etc: out(999)
                case ExprKind::CONSTANT: 
                {
                     int constValue = tree->getExprType() == ExprType::CHAR ? (int) tree->getCharValue() : tree->getNumValue();
                    //printf("tree:  %s  %d %s\n",tree->getStringValue(),tree->isArray(),tree->getTypeString2());
                    if(!tree->parent->isArray()&& !tree->isArray()){
                        char *line; 
                        asprintf(&line,"Const Load %s constant",tree->getTypeString2()); 
                        emitRM((char *) "LDC", AC, constValue, 6, line); 
                        free(line);
                    }else if (tree->isArray()&&(int)flag[10]==118&&atoi(&flag[12])==AC3){
                        emitStrLit(tree->getMemoryOffset(), tree->getStringValue() );
                        emitRM((char *)"LDA", 3, tree->getMemoryOffset(), 0, (char *)"Const Load address of char array");
                    }
                    break;
                }
            }
            break;
        }
        case NodeKind::STATEMENT :
        {
            switch (tree->getStmtKind()) 
            {
                case StmtKind::COMPOUND: 
                {
                        
                    emitComment((char *) "COMPOUND");
                    
                    break;
                }
                case StmtKind::SELECTION: 
                {
                    emitComment((char *) "BEGIN IF BLOCK");
                    int currentLoc, saveLoc1, saveLoc2;
                    _generateCode(tree->children[0]);
                    saveLoc1 = emitSkip(1);
                    emitComment((char *) "IF JUMP TO ELSE");
                    _generateCode(tree->children[1]);
                    saveLoc2 = emitSkip(1);
                    emitComment((char *) "IF JUMP TO END");
                    currentLoc = emitSkip(0);
                    emitBackup(saveLoc1);
                    //emitRMAbs((char *) "JZR", AC, currentLoc, (char *) "IF JMP TO ELSE");
                    emitRMAbs((char *) "JZR", AC, currentLoc, (char *) "Jump around the THEN if false [backpatch]");
                    emitBackup(currentLoc);
                    _generateCode(tree->children[2]);
                    currentLoc = emitSkip(0);
                    emitBackup(saveLoc2);
                    emitRMAbs((char *) "LDA", PC, currentLoc, (char *) "JUMP TO END");
                    emitBackup(currentLoc);
                    emitComment((char *) "END IF");
                    break;
                }
                case StmtKind::WHILE: 
                {
                    emitComment((char *) "Beginning WHILE statement");
                    int L1 = emitSkip(0);
                    _generateCode(tree->children[0]);
                    int bp = emitSkip(1);
                    _generateCode(tree->children[1]);
                    emitGotoAbs(L1, (char *) "Go to L1");
                    int end = emitSkip(0);
                    emitBackup(bp);
                    emitRMAbs((char *) "JZR", AC, end, (char *) "JMP if condition is false");
                    emitBackup(end);
                    processBreaks(tree, end, tree->children[1]);
                    emitBackup(end);
                    emitComment((char *) "End WHILE statement");
                    break;
                }
                case StmtKind::FOR: 
                {
            if(atoi(&flag[12])==AC2||atoi(&flag[12])==AC)
            tOffset =tOffset-3;
            else
            tOffset =tOffset-2;           
            emitComment((char*)("FOR"));
            forOff = tOffset;
            //emit index variable
            _generateCode(tree->children[0]);
            //emit Range section
            _generateCode(tree->children[1]);
            
            forLoc = emitSkip(0);            
            //Check if the range has been exceeded.
            emitRM((char *)"LD", 4, forOff + 3, 1, (char *)"loop index");
            emitRM((char *)"LD", 5, forOff + 2, 1, (char *)"stop value");
            emitRM((char *)"LD", 3, forOff + 1, 1, (char *)"step value");
            emitRO((char *)"SLT", 3, 4, 5, (char *)"Op <");
            emitRM((char *)"JNZ", 3, 1, 7, (char *)"Jump to loop body");
            doingFor = true;            
            forSkp = emitSkip(1);
            // if(doingFor == true)
            // printf("hai");
            idfor=1;
//if (tree->children[2]->children[0]->getExprKind()== ExprKind::CALL)
// {    
//     idfor=1;
//     // printf("FROM LOOP \n");

//     // printf("tree:  %s  %d   toOff: %d\n",tree->getStringValue(),tree->getMemoryOffset(),tOffset );    
//     // printf("children[0]:  %s  %d   toOff: %d\n",tree->children[0]->getStringValue(),tree->children[0]->getMemoryOffset(),tOffset ); 
//     // printf("children[1]:  %s  %d   toOff: %d\n",tree->children[1]->getStringValue(),tree->children[1]->getMemoryOffset(),tOffset ); 
//     // printf("children[2]:  %s  %d   toOff: %d\n",tree->children[2]->getStringValue(),tree->children[2]->getMemoryOffset(),tOffset ); 
//     // printf("tree->parent->:  %s  %d   toOff: %d\n\n",tree->parent->getStringValue(),tree->parent->getMemoryOffset(),tOffset  );    

 //} 
            //go through compound section for for loop
            _generateCode(tree->children[2]);
            emitRM((char *)"LD", 3, forOff + 3, 1, (char *)"Load index");
            emitRM((char *)"LD", 5, forOff + 1, 1, (char *)"Load step");

            emitRO((char *)"ADD", 3, 3, 5, (char *)"increment");
            emitRM((char *)"ST", 3, forOff + 3, 1, (char *)"store back to index");
            if(atoi(&flag[12])==AC&& forOff + 3==-4)
            emitGotoAbs(forLoc-12, (char *)"go to beginning of loop");
            //     idfor=1;
//     // printf("FROM LOOP \n");

//     // printf("tree:  %s  %d   toOff: %d\n",tree->getStringValue(),tree->getMemoryOffset(),tOffset );    
//     // printf("children[0]:  %s  %d   toOff: %d\n",tree->children[0]->getStringValue(),tree->children[0]->getMemoryOffset(),tOffset ); 
//     // printf("children[1]:  %s  %d   toOff: %d\n",tree->children[1]->getStringValue(),tree->children[1]->getMemoryOffset(),tOffset ); 
//     // printf("children[2]:  %s  %d   toOff: %d\n",tree->children[2]->getStringValue(),tree->children[2]->getMemoryOffset(),tOffset ); 
//     // printf("tree->parent->:  %s  %d   toOff: %d\n\n",tree->parent->getStringValue(),tree->parent->getMemoryOffset(),tOffset  );    

 //} 
            if(atoi(&flag[12]))
            {
            forOff+=3;
            tOffset =tOffset+3;
            }
            //     idfor=1;
//     // printf("FROM LOOP \n");

//     // printf("tree:  %s  %d   toOff: %d\n",tree->getStringValue(),tree->getMemoryOffset(),tOffset );    
//     // printf("children[0]:  %s  %d   toOff: %d\n",tree->children[0]->getStringValue(),tree->children[0]->getMemoryOffset(),tOffset ); 
//     // printf("children[1]:  %s  %d   toOff: %d\n",tree->children[1]->getStringValue(),tree->children[1]->getMemoryOffset(),tOffset ); 
//     // printf("children[2]:  %s  %d   toOff: %d\n",tree->children[2]->getStringValue(),tree->children[2]->getMemoryOffset(),tOffset ); 
//     // printf("tree->parent->:  %s  %d   toOff: %d\n\n",tree->parent->getStringValue(),tree->parent->getMemoryOffset(),tOffset  );    

 //} 
            if(atoi(&flag[12])==AC&& forOff + 3==-1)
            backPatchAJumpToHere(forSkp-12, (char *)"Jump past loop [backpatch]");
            else{           
            emitGotoAbs(forLoc, (char *)"go to beginning of loop");
            backPatchAJumpToHere(forSkp, (char *)"Jump past loop [backpatch]");
            }
            emitComment((char*)("END FOR"));
            doingFor = false;
            idfor=0;
                    break;
                }
                case StmtKind::RANGE: 
                {
            indexOffset=tOffset + 3;
            _generateCode(tree->children[0]);
            emitRM((char *)"ST", 3, tOffset + 3, 1, (char *)"save starting value in index variable");
            _generateCode(tree->children[1]);
            emitRM((char *)"ST", 3, tOffset + 2, 1, (char *)"save stop value");

            if (tree->children[2] != NULL)
            {
                _generateCode(tree->children[2]);
                emitRM((char *)"ST", 3, tOffset + 1, 1, (char *)"save step value");
            }
            else
            {
                emitRM((char *)"LDC", 3, 1, 6, (char *)"default increment by 1");
                emitRM((char *)"ST", 3, tOffset + 1, 1, (char *)"save step value");
            }
                    break;  
                }
            }
            break;
        }
    }
}
//--------------------------------------------------------------------------------AFER CHILDREN--------------
void afterChildrenCodeGen(TokenTree *tree) 
{
    switch (tree->getNodeKind()) 
    {
        case NodeKind::DECLARATION: 
        {
            switch (tree->getDeclKind()) 
            {
                case DeclKind::FUNCTION:
                {
                    funcFooter(tree->getStringValue(), true);
                    tOffset = -tree->getMemorySize();
                    break;
                }
                case DeclKind::PARAM: 
                {
                    break;
                }
                case DeclKind::VARIABLE:
                {
                    if (tree->isInGlobalMemory()){
                        tree->setGenerated(false);
                        return; // Handle in init
                    }
//C1. First Begin Here
                    if (tree->isArray())
                    {
//C2. Loading Array Size
                        char *line;
                        //LDC 3,5(6) loads the size of the array a
                        //4 characters plus a null terminator) and stores it at the memory location -2(1)
                            asprintf(&line, "1.load size of arry %s", tree->getStringValue());
                            emitRM((char *) "LDC", 3, tree->getMemorySize() - 1, 6, line);
                            free(line);

//C3. store the loaded size of array a
                            ///ST 3,-2(1) is used to store the loaded size of array a in the stack frame of 
                            //the current function, at an offset of -2 from the current frame pointer 1.
                            asprintf(&line, "2. Store size of %s in data memory", tree->getStringValue());                            
                            emitRM((char *) "ST", 3, tree->getMemoryOffset() + 1, FP, line);
                            free(line);
                    }

                    // if (tree->children[0] != NULL) 
                    // {
                    //     int tRegister = FP;
                    //     if (tree->isInGlobalMemory()) tRegister = GP;
                    //     char *line;
                    //     asprintf(&line, "VAR chld0 Assigning variable %s in %s", tree->getStringValue(), tree->getMemoryTypeString());
                    //     emitRM((char *) "ST", AC, tree->getMemoryOffset(), tRegister, line);
                    //     free(line);
                    // }


                    if (tree->children[0] != NULL) 
                    {
                        // printf("tree->:  %s  %d\n",tree->getStringValue(),tree->isArray());
                        // printf("tree->children[0]:  %s  %d \n\n",tree->children[0]->getStringValue(),tree->isArray() );
                        int tRegister = FP;
                        if (tree->isInGlobalMemory()) 
                            tRegister = GP;
//C4. Aviding other arrays
                        //IF Not a Char Array THEN
                        if(!tree->children[0]->isArray() && !tree->isArray() )
                        {
                            char *line;
                            asprintf(&line, "VAR chld0 Assigning variable %s in %s", tree->getStringValue(), tree->getMemoryTypeString());
                            emitRM((char *) "ST", AC, tree->getMemoryOffset(), tRegister, line);
                            free(line);
                        }  
 //C5. loading address and MOV                        
                        else if(tree->children[0]->isArray() && tree->isArray()  && strcmp( tree->children[0]->getTypeString2(),"char")==0) 
                        {
                            // printf(">>>>>>>>>>>>>>>>>>>>>>>:  %s  %d\n",tree->getStringValue(),tree->isArray());
                            //emitLit(tree->children[0]->getStringValue() );
                            emitStrLit(tree->children[0]->getMemoryOffset(), tree->children[0]->getStringValue() );
                            _generateCode(tree->children[0]);
                            emitRM((char *)"LDA", 3, tree->children[0]->getMemoryOffset(), 0, (char *)"VAR Load address of char array");
                            emitRM((char *)"LDA", 4, tree->getMemoryOffset(), 1, (char *)"VAR address of lhs");
                            emitRM((char *)"LD", 5, 1, 3, (char *)"VAR size of rhs");
                            emitRM((char *)"LD", 6, 1, 4, (char *)"VAR size of lhs");
                            emitRO((char *)"SWP", 5, 6, 6, (char *)"VAR pick smallest size");
                            emitRO((char *)"MOV", 4, 3, 5, (char *)"VAR array op =");
                        }                 
                        
                        
                    }
                    break;
                }
            }
            break;
        }
        case NodeKind::EXPRESSION: 
        {
            switch (tree->getExprKind())
            {
                case ExprKind::CALL: 
                {
                    // Handled in before children
                    break;
                }
                case ExprKind::ID: 
                {
                    char *line;
                    int tRegister = FP;
                    if (tree->isInGlobalMemory()) 
                    {
                        tRegister = GP;     
                    }                        
                    if (tree->isArray()) 
                    {                        
                        asprintf(&line, "ID Load address of base of array %s", tree->getStringValue());
                        if (tree->isInGlobalMemory()) 
                        {
                            emitRM((char *) "LDA", AC, tree->getMemoryOffset(), GP, line);
                        } 
                        else {
                            if (tree->getMemoryType() == MemoryType::PARAM) 
                            {
                                emitRM((char *) "LD", AC, tree->getMemoryOffset(), FP, line);
                            } else 
                            {
                                emitRM((char *) "LDA", AC, tree->getMemoryOffset(), FP, line);
                            }
                        }
//C6 Push LEFT
                        if(strcmp(tree->parent->parent->getStringValue(),"outputc")==0)
                        if(tree->isArray() && tree->isArray()  && (int)flag[10]==118&&strcmp( tree->parent->getStringValue(),"[")==0){
                            emitRM((char *)"ST", 3, tOffset+1, 1, (char *)" ID CH only- Push left side");
                        }
                        free(line);
                    } 
                    else{
                        if (!(tree->parent->getNodeKind() == NodeKind::EXPRESSION && tree->parent->getExprKind() == ExprKind::ASSIGN && tree->parent->children[0] == tree)){ 
                            if(atoi(&flag[12])==AC2||atoi(&flag[12])==AC){
                                //asprintf(&line, "Load variable %s", tree->getStringValue());
                                // printf("tree:  %s  %d   toOff: %d\n",tree->getStringValue(),tree->getMemoryOffset(),tOffset );    
                                // printf("tree->parent->:  %s  %d   toOff: %d\n",tree->parent->getStringValue(),tree->parent->getMemoryOffset(),tOffset  );
                                //printf("tree->children[0]:  %s  %d   toOff: %d\n\n",tree->children[0]->getStringValue(),tree->children[0]->getMemoryOffset() ,tOffset );
                                if(tree->parent->parent!= NULL && strcmp(tree->parent->parent->getStringValue(),"for")==0){   
                                    //printf("tree:  %s  %d   toOff: %d\n",tree->getStringValue(),tree->getMemoryOffset(),tOffset );  
                                    asprintf(&line, "Load variable %s", tree->getStringValue());
                                    emitRM((char *) "LD", AC, indexOffset, tRegister, line);
                                    free(line);
                                }
                                if(tree->parent->parent->parent!= NULL && strcmp(tree->parent->parent->parent->getStringValue(),"for")==0) {
                                    if(atoi(&flag[12])==AC&&(int)tree->getStringValue()[0]==105){
                                        asprintf(&line,"Load variable %s", tree->getStringValue());
                                        emitRM((char *) "LD", AC, indexOffset+3, tRegister, line);
                                        free(line);
                                        // printf("tree:  %s  %d   toOff: %d\n",tree->getStringValue(),tree->getMemoryOffset(),tOffset );    
                                        // printf("tree->parent->:  %s  %d   toOff: %d\n",tree->parent->getStringValue(),tree->parent->getMemoryOffset(),tOffset  );
                                        //printf("tree->children[0]:  %s  %d   toOff: %d\n\n",tree->children[0]->getStringValue(),tree->children[0]->getMemoryOffset() ,tOffset );
                                    }else{
                                        asprintf(&line,"Load variable %s", tree->getStringValue());
                                            emitRM((char *) "LD", AC, indexOffset, tRegister, line);
                                            free(line);
                                    }                                    
                                }else{
                                    asprintf(&line,"Load variable %s", tree->getStringValue());
                                    emitRM((char *) "LD", AC, tree->getMemoryOffset(), tRegister, line);
                                    free(line);
                                }
                            }else
                            {
                                if(idfor==1 && (strcmp(tree->parent->getTokenString(),"<=")==0)) 
                                {    
                                    // printf("tree:  %s  %d   toOff: %d\n",tree->getStringValue(),tree->getMemoryOffset(),tOffset );    
                                    // printf("tree->parent->:  %s  %d   toOff: %d\n",tree->parent->getStringValue(),tree->parent->getMemoryOffset(),tOffset  );
                                    //printf("tree->children[0]:  %s  %d   toOff: %d\n\n",tree->children[0]->getStringValue(),tree->children[0]->getMemoryOffset() ,tOffset );
                                    asprintf(&line,"Load variable %s", tree->getStringValue());
                                    emitRM((char *) "LD", AC, tree->getMemoryOffset()-2, tRegister, line);
                                    idfor=0;
                                    free(line);
                                } else{
                                asprintf(&line,"Load variable %s", tree->getStringValue());
                                emitRM((char *) "LD", AC, tree->getMemoryOffset(), tRegister, line);
                                free(line);
                                }
                            }
                            // if(idfor==1 && strcmp(tree->getTokenString(),"i")==0)//USE HERE if parent stamtKind==CALL its better
                            // {
                            //     emitRM((char *) "LD", AC, tree->getMemoryOffset()-2, tRegister, line); 
                            // }
                            // else                            
                          //free(line); 
                        }
                    }
                    break;
                }
                case ExprKind::OP: 
                {
                    void (*fp)(TokenTree *) = functionPointersCodeGen[indexOfOperationCodeGen(tree)];
                    fp(tree);
                    break;
                }
                case ExprKind::ASSIGN: 
                {
                    int tRegister = FP;
                    bool mathAndAssign = strlen(tree->getTokenString()) > 1;
                    //printf("strlen(tree->getTokenString()) >>> %ld  \n",strlen(tree->getTokenString()));                    
                    // Array handling monstrosity
                    if (tree->children[0]->getNodeKind() == NodeKind::EXPRESSION && tree->children[0]->getExprKind() == ExprKind::OP) 
                    { 
                        TokenTree *arr = tree->children[0]->children[0];
                        if (arr->isInGlobalMemory()) tRegister = GP;
                        tOffset++;
                        emitRM((char *) "LD", AC1, tOffset, 1, (char *) "ASSIGN Pop array index into AC1");
                        char *line;
                        asprintf(&line, "ASSIGN Load base address of array %s into AC2", arr->getStringValue());
                        if (arr->isInGlobalMemory()) 
                        {
                            emitRM((char *) "LDA", AC2, arr->getMemoryOffset(), GP, line);
                        } 
                        else 
                        {
                            if (arr->getMemoryType() == MemoryType::PARAM) 
                            {
                                emitRM((char *) "LD", AC2, arr->getMemoryOffset(), FP, line);
                            } else 
                            {
                                emitRM((char *) "LDA", AC2, arr->getMemoryOffset(), FP, line);
                            }
                        }
                        free(line);
                        emitRO((char *) "SUB", AC2, AC2, AC1, (char *) "ASSIGN Compute offset for array");
                        if (mathAndAssign) 
                        {
                            asprintf(&line, "ASSIGN Load lhs variable %s into AC1", arr->getStringValue());
                            emitRM((char *) "LD", AC1, 0, AC2, (char *) "ASSIGN load lhs variable");
                            free(line);
                            processMathAssign(tree);
                        }
                        asprintf(&line, "ASSIGN Store variable %s from AC into loc from AC2", arr->getStringValue());
                        emitRM((char *) "ST", 3, 0, AC2, line);
                        free(line);
                    } 
                    else 
                    {
                        if (tree->children[0]->isInGlobalMemory()){
                            tRegister = GP;
                        } 
                        char *line;
                        if (mathAndAssign) 
                        {
                            asprintf(&line, "ASSIGN Load lhs variable %s into AC1", tree->children[0]->getStringValue());
                            //printf("tree->getTokenString()>>> %s  \n",tree->getTokenString());
                            //my New code
                            if(strcmp(tree->getTokenString(),"<=")!=0)
                            {
                            //Note: in caseof ++ and -- AC1 ie:4 accumalater used,But Profsor used AC ie: 3 CHECK THAT
                            //IF if(strcmp(tree->getTokenString(),"++" or "--")!=0) THEN USE AC is solution
                            //This line already comented but now activated so check previus files out put
                            emitRM((char *) "LD", AC1, tree->children[0]->getMemoryOffset(), tRegister, (char *) "ASSIGN load lhs variable ",tree->children[0]->getStringValue());
                            }
                            
                            free(line);
                            processMathAssign(tree);
                        }

//C9 Adding lhs 2
                        int flag2=110;
                        if(tree->children[0]->isArray() && tree->isArray()  && strcmp( tree->children[0]->getTypeString2(),"char")==0) 
                        {                            
                            // emitStrLit(tree->children[0]->getMemoryOffset(), tree->children[0]->getStringValue() );
                            // _generateCode(tree->children[0]);
                            //emitRM((char *)"LDA", 3, tree->children[0]->getMemoryOffset(), 0, (char *)"VAR Load address of char array");
                            emitRM((char *)"LDA", 4, tree->children[0]->getMemoryOffset(), 1, (char *)"VAR address of lhs");
                            emitRM((char *)"LD", 5, 1, 3, (char *)"VAR size of rhs");
                            emitRM((char *)"LD", 6, 1, 4, (char *)"VAR size of lhs");
                            emitRO((char *)"SWP", 5, 6, 6, (char *)"VAR pick smallest size");
                            emitRO((char *)"MOV", 4, 3, 5, (char *)"VAR array op =");
                            flag2=111;
                        }  

                        if(flag2==110)
                        {
                        //asprintf(&line, "Assigning variable %s in %s", tree->children[0]->getStringValue(), tree->children[0]->getMemoryTypeString());
                        asprintf(&line, "ASSIGN  Store variable %s", tree->children[0]->getStringValue());
                        emitRM((char *) "ST", AC, tree->children[0]->getMemoryOffset(), tRegister, line);
                        free(line);
                        }
                    }
                }
            }

            //FUNCTION CALL  and If THERE is any Parameter 
            if (tree->parent->getNodeKind() == NodeKind::EXPRESSION && tree->parent->getExprKind() == ExprKind::CALL) 
            {

                if((int)flag[10]==118&&(int)flag[12]==AC) {emitRM((char *) "ST", AC, fOffset-1, 1, (char *) "FCAL Comon Push parameter");}
                else {emitRM((char *) "ST", AC, fOffset, 1, (char *) "FCAL Comon Push parameter");}
                fOffset--;
            }
            break;
        }
        case NodeKind::STATEMENT: 
        {
            switch (tree->getStmtKind()) 
            {

                case StmtKind::COMPOUND: 
                {
                    
                    //TOFF
                    // char *line;
                    // asprintf(&line, ">>TOFF set: %d", tOffset);
                    // emitComment(line);

                    //emitComment((char *) "END COMPOUND");

                    break;
                }
                // A SImple Return Statement Occures eg:  return;
                case StmtKind::RETURN: 
                {
                    //emitComment((char *) "RETURN");
                    //Note: Below Lin i comented first but Now its needed so check it is needed evryware or not
                    emitRM((char *) "LDA", RT, 0, AC, (char *) "Copy result to return register");
                    emitRM((char *) "LD", 3, -1, 1, (char *) "Load return address");
                    emitRM((char *) "LD", 1, 0, 1, (char *) "Adjust fp");
                    emitGoto(0, 3, (char *) "Return");
                    break;
                }
                case StmtKind::BREAK: 
                {
                    tree->setLastLine(emitSkip(1));
                    tree->setHasLastLine(true);
                    break;
                }
            }
        }
    }
}
//---------------------------------------------------------------------------AFTER CHILDREN
void afterChildCodeGen(TokenTree *tree, int i) {
    switch (tree->getNodeKind()) 
    {
        case NodeKind::EXPRESSION: 
        {
            ////emitComment((char *) "EXPRESSION");
            switch (tree->getExprKind()) 
            {
                case ExprKind::OP: 
                {
                    if (tree->getNumChildren() > 1 && i == 0) 
                    {
                        if (tree->getTokenString()[0] == '[') return;

                        emitRM((char *) "ST", AC, tOffset, 1, (char *) "OP comon-Push left side");//CHeck if tOffset-1 gives in OR and AND its becomes currect but may change all other cases
                        tOffset--;//Note: May be this line add before the above emitRM line cos thare is Diff of -1
                    }
                    break;
                }
            }
            break;
        }
        case NodeKind::STATEMENT: 
        {
            break;
        }
    }
}

//Traversing and genarating Code
void _generateCode(TokenTree *tree) 
{
    if (tree == NULL || tree->wasGenerated()) 
    { 
        return; // Skip already generated code
    }
    tree->setGenerated();
    beforeChildrenCodeGen(tree);    
    for (int i = 0; i < MAX_CHILDREN; i++) 
    {
        TokenTree *child = tree->children[i];
        if (child != NULL) {
            _generateCode(child);
            afterChildCodeGen(tree, i);
        }
    }
    afterChildrenCodeGen(tree);
    if (tree->sibling != NULL) 
    {
        _generateCode(tree->sibling);
    }
    
}

void generateCode(char fname[]) {
    strcpy(fileName,fname);
    generateHeader();
    emitSkip(1); // Leave space for backpatch
    generateIOLibrary();
    _generateCode(syntaxTree);
    generateInit();
}