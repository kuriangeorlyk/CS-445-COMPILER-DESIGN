#include "string.h"
#include "symbolTable.h"
#include "semantic.h"
#include "TokenTree.h"


#include <iostream>
#include <string>
#include <vector>
#include <algorithm>



#define MAX_ERRORS 100
// global variable to store errors
char* errors[MAX_ERRORS];
int num_errors = 0;

#define NUM_OPS 19

extern int numErrors;
extern int numWarnings;
extern int localOffset;
extern int globalOffset;
extern TokenTree *syntaxTree;
extern SymbolTable *symbolTable;
//  string errors = "";
//Printing ERROR Messages
void err(TokenTree *node) 
{
    printf("ERROR(%d): ", node->getLineNum());
    numErrors++;
}

//Printing WARNING Messages
void warn(TokenTree *node) 
{
    printf("WARNING(%d): ", node->getLineNum());
    numWarnings++;
}

//Checks LHS and RHS are EQUAL and return True if Both are same EXPTYPE
bool sameType(TokenTree *lhs, TokenTree *rhs) 
{
    return lhs->getExprType() == rhs->getExprType();
}

// AND OR 
// OP type changed to BOOL
//Checks Both Child are Boolean 
//Checks Both side is array or not
void handleBooleanComparison(TokenTree *tree)
{
    tree->setExprType(ExprType::BOOL);
    TokenTree *lhs = tree->children[0];
    TokenTree *rhs = tree->children[1];
    if (!lhs->isExprTypeUndefined() && lhs->getExprType() != ExprType::BOOL) {
        err(tree);
        printf("'%s' requires operands of %s but lhs is of %s.\n", tree->getTokenString(), tree->getTypeString(), lhs->getTypeString());
    }
    if (!rhs->isExprTypeUndefined() && rhs->getExprType() != ExprType::BOOL) {
        err(tree);
        printf("'%s' requires operands of %s but rhs is of %s.\n", tree->getTokenString(), tree->getTypeString(), rhs->getTypeString());
    }
    
    if (lhs->isArray() || rhs->isArray()) {
        err(tree);
        printf("The operation '%s' does not work with arrays.\n", tree->getTokenString());
    }
}

//NOT
//THE variable or EXP used with NOT must be BOOL else it Shows ERROR
// NOT is not work with Arrays. SO also shows error
void handleNot(TokenTree *tree)
{
    tree->setExprType(ExprType::BOOL);
    TokenTree *lhs = tree->children[0];
    if (tree->checkCascade() && lhs->getExprType() != ExprType::BOOL) 
    {
        err(tree);
        printf("Unary '%s' requires an operand of %s but was given %s.\n", tree->getTokenString(), tree->getTypeString(), lhs->getTypeString());
    
    }
    if (lhs->isArray()) 
    {
            err(tree);
            printf("The operation '%s' does not work with arrays.\n", tree->getTokenString());           
    }
}

//   + - * / % 
//op type changed to INT
//checks Both side are int Type
//this function also called in unery  op checking function
void handleMath(TokenTree *tree) 
{
    tree->setExprType(ExprType::INT);
    TokenTree *lhs = tree->children[0];
    TokenTree *rhs = tree->children[1];
    //printf(">>>>>>>TREE %s  %s",    tree->getTokenString(),rhs->getTypeString());  
    //IF LHS not INT type or UNDEFF then Shows ERROR
    if (!lhs->isExprTypeUndefined() && lhs->getExprType() != ExprType::INT) 
    {
        err(tree);
        printf("'%s' requires operands of %s but lhs is of %s.\n", tree->getTokenString(), tree->getTypeString(), lhs->getTypeString());
    }
    //IF RHS not INT type or UNDEFF then Shows ERROR
    if (!rhs->isExprTypeUndefined() && rhs->getExprType() != ExprType::INT) 
    {
        err(tree);
        printf("'%s' requires operands of %s but rhs is of %s.\n", tree->getTokenString(), tree->getTypeString(), rhs->getTypeString());
    }
    //BOTH SIDES are not ARRAY then also shows Error
    //Is it working in C-.  Cos not Seen in (C- Array Operators in C1 rule)
    if (lhs->isArray() || rhs->isArray()) 
    {
        err(tree);
        printf("The operation '%s' does not work with arrays.\n", tree->getTokenString());
    }
}
//Checks Unary  - 
//also checks sub - too
//unary - becomes exptype::INT 
//cascade- all child are not undeff check
void handleChSignOrMath(TokenTree *tree) 
{
    if (tree->children[1] != NULL) //it means this - is a substraction
    {
        handleMath(tree); //Check both side are int or Not
    } 
    else 
    {
        tree->setExprType(ExprType::INT);//DIRECT USING OF TREE
        TokenTree *lhs = tree->children[0];
        //if oparand variable is not an INT then Error        
        if (tree->checkCascade() && lhs->getExprType() != ExprType::INT) 
        {
            err(tree);
            printf("Unary '%s' requires an operand of %s but was given %s.\n", tree->getStringValue(), tree->getTypeString(), lhs->getTypeString());
        }
        //THe UNARY - or Negative sign not working with arrays
        if (lhs->isArray()) {
            err(tree);
            printf("The operation '%s' does not work with arrays.\n", tree->getStringValue());
        }
    }
}
//Checks Unary * 
// also checks mul * If there is 2 oparends then it goes to handleMath(tree) function to check
//unary OP becoms expType INT
void handleSizeOfOrMath(TokenTree *tree) 
{          
    if (tree->children[1] != NULL) 
    {
        handleMath(tree);
    } 
    //Else means it is a unary * pointer oparator
    else 
    { 
        TokenTree *lhs = tree->children[0];
        //The * op Become INT type
        tree->setExprType(ExprType::INT);
        if (tree->checkCascade()) 
        {
            //IF VARIABLE LHS is not an Array then Error Emits
            if (!lhs->isArray()) {
                err(tree);
                printf("The operation '%s' only works with arrays.\n", tree->getStringValue());
            }
        }
    }
}

//Checks Unary ++ --
//OP becomes exp type INT
//BUT now desabled
//child 0 not INT type then error shows 
//and child 0 is an array then also shows array
void handleUnaryInt(TokenTree *tree) 
{
    //++ or -- becomes INT type
    tree->setExprType(ExprType::INT);
    TokenTree *lhs = tree->children[0];
    //LHS variable is not an INT then Error
    if (lhs->getExprType() != ExprType::INT) 
    {
        err(tree);
        printf("Unary '%s' requires an operand of %s but was given %s.\n", tree->getTokenString(), tree->getTypeString(), lhs->getTypeString());
    }
    //++ and -- not working with arrys
    if (lhs->isArray()) {
        err(tree);
        printf("The operation '%s' does not work with arrays.\n", tree->getStringValue());
    }
}

// ? -------- ?-5 produces an integer in the range [-4..0]. an arry maker
// OP '?' become exptype of child_0 (LHS)exptype
//child 0 not INT then error shows
// child 0 is an array then error shows 
void handleRandom(TokenTree *tree) 
{
    TokenTree *rhs = tree->children[0];

    //C- RUle says OP wants be INT type
    tree->setExprType(ExprType::INT);

    //According to C- Rule Thre is no LHS, only RHS for this oparator
    //SO is this Code Currect or not
    if (rhs->getExprType() != ExprType::INT)
    {
        err(tree);
        printf("Unary '%s' requires an operand of %s but was given %s.\n", tree->getTokenString(), "type int", rhs->getTypeString());
    }

    //According to C- Rule Thre is no LHS, only RHS for this oparator
     if (rhs->isArray()) // is this code is currect
    {
        err(tree);
        printf("The operation '%s' does not work with arrays.\n", tree->getStringValue());
    }
}

//< > >= = != !< !> checks
//OP exp kind changed to Bool
//Checks  OP is cascade- ALL CHILD nodes are UNDEFINED  or not.
//Checks Both side is array or not
// sameType(lhs, rhs) checks both side is same ExpType or not
void handleComparison(TokenTree *tree) //LHS
{
    //Symbol Sign Tyoe changed To BOOL 
    tree->setExprType(ExprType::BOOL);
    TokenTree *lhs = tree->children[0];
    TokenTree *rhs = tree->children[1];
    //Checkin ALl child are not UNDEFINED
    if (tree->checkCascade()) 
    {
        //Checks LHS and RHS are same EXPTYPE, Else error
        if (!sameType(lhs, rhs)) 
        {
            err(tree);
            printf("'%s' requires operands of the same type but lhs is %s and rhs is %s.\n", tree->getTokenString(), lhs->getTypeString(), rhs->getTypeString());
        }
    }
    //Both side variables must be array else error
    if (lhs->isArray() ^ rhs->isArray()) 
    {
        char *lhsStr = (char*) "";
        char *rhsStr = (char*) "";
        if (!lhs->isArray()) lhsStr = (char*) " not";
        if (!rhs->isArray()) rhsStr = (char*) " not";
        err(tree);
        printf("'%s' requires both operands be arrays or not but lhs is%s an array and rhs is%s an array.\n", tree->getTokenString(), lhsStr, rhsStr);

    }
}

// [ ] and its child mus is isArray TRUE
//OP exp type becomed childs exptype
// child o must be INT and it is not UNDEFF
//index number not to be an array
void handleArrayAccess(TokenTree *tree) 
{
    //Acording to C- rule type wants to becom LHS type
    TokenTree *array = tree->children[0];
    tree->setExprType(array->getExprType());
    TokenTree *index = tree->children[1];

    if (array == NULL) //if child empy it is an empty array error
    {
        err(tree);
        printf("Cannot index nonarray.\n");
        return;
    }
    if (!array->isArray()) //childs isArray must be defined in parser
    {
        err(tree);
        printf("Cannot index nonarray '%s'.\n", array->getStringValue());
    }
    //Index number must be an INT type
    if (!index->isExprTypeUndefined() && index->getExprType() != ExprType::INT) 
    {
        err(tree);
        printf("Array '%s' should be indexed by type int but got %s.\n", array->getStringValue(), index->getTypeString());
    }
    //Index number is an array  then shows this error
    if (index->isArray())
    {
        err(tree);
        printf("Array index is the unindexed array '%s'.\n", index->getStringValue());
    }
}

const char *operations[NUM_OPS] = {
    
    "<",
    ">=",
    ">",

    "and",
    "or",   

    "not",
    "+",
    "-",
    "*",

    "/",
    "%",

    "++",
    "--",
    "?",

    "=",
    "!=",
    "!>",
    "!<",

    "[" 
};

//If OP then it works and start checking depend on op types
void (*functionPointers[NUM_OPS])(TokenTree *) = {


    handleComparison, // LESS THAN
    handleComparison, // GEQ
    handleComparison, // GREATHER THAN

    handleBooleanComparison, // AND
    handleBooleanComparison, // OR

    handleNot, // NOT
    handleMath, // PLUS
    handleChSignOrMath, // CHANGE SIGN OR MINUS
    handleSizeOfOrMath, // SIZEOF OR TIMES

    handleMath, // DIVISION
    handleMath, // MOD

    handleUnaryInt, // INC
    handleUnaryInt, // DEC
    handleRandom, // RANDOM ?

    handleComparison, // EQUALS
    handleComparison, // NOT EQUALS
    handleComparison, // NOT GREATERTHAN
    handleComparison, // NOT LEESTHAN
    handleArrayAccess, // ARRAY ACCESSOR []
};

//Checks op type and cooses currect function  to invoke
int indexOfOperation(TokenTree *tree) 
{
    for (int i = 0; i < NUM_OPS; i++) 
    {
        if (strcmp(tree->getTokenString(), operations[i]) == 0) 
        {
            return i;
        }
    }
    return -1;
}
// checks the argument node is a compund or not
bool compoundShouldEnterScope(TokenTree *parent) 
{
    if (parent == NULL) 
    {
        return true;
    }
    if (parent->getNodeKind() == NodeKind::DECLARATION && parent->getDeclKind() == DeclKind::FUNCTION)
    {
        return false;
    }
    if (parent->getNodeKind() == NodeKind::STATEMENT && parent->getStmtKind() == StmtKind::FOR) 
    {
        return false;
    }
    return true;
}

//--------------------B4 CHILDREN-----------------

void beforeChildren(TokenTree *tree, bool *enteredScope, int &previousLocalOffset) 
{
    if (tree->parent != NULL && tree->parent->getNodeKind() == NodeKind::EXPRESSION && tree->parent->getExprKind() == ExprKind::CALL) {
        TokenTree *res = (TokenTree *) symbolTable->lookup(tree->parent->getStringValue());
        if (res != NULL) {
            int counter = 1;
            TokenTree *param = res->children[0];
            TokenTree *input = tree->parent->children[0]; // Start back over in tree so we can tell the position
            while (input != tree && param != NULL) { // Travel accross siblings until we reach our desired input
                param = param->sibling; // Param is moved along with input to ensure matching
                input = input->sibling;
                counter++;
            }
            // if (param == NULL && input == tree) { // param == null means we had more inputs than allowed. input == tree prevents duplicate errors
            //     err(tree);
            //     printf("Too many parameters passed for function '%s' declared on line %d.\n", res->getStringValue(), res->getLineNum());
            // }
        }
    }

    //checks All DECLARATION, EXPRESSION, STATEMENT    
    switch (tree->getNodeKind()) 
    {
        //>>>>>>>>>>>>PARAM & FUNCTION REDECLARATION ERROR<<<<<<<<<<<<<<<
        //checks all declarations of FUNCTION, VARIABLE, PARAM
        case NodeKind::DECLARATION: 
        {
            //If FUNCTION, PARAM 
            if (tree->getDeclKind() != DeclKind::VARIABLE) 
             {
                //THis defined Determines a parameter is already declared or not    
                //Insert function inserts the value and return true              
                bool defined = !symbolTable->insert(tree->getStringValue(), tree);
                //Checks FUNCTION= accessin all functions including main
                if (tree->getDeclKind() == DeclKind::FUNCTION) 
                {
                    tree->setMemoryType(MemoryType::GLOBAL); //NEW
                    //tree->calculateMemoryOffset(); //NEW   This line shows compount size but lot of size changes happens 
                    //prints all function name
                    //printf("FUNCTION>>  [ Line %d ] tree %s   \n",tree->getLineNum(),tree->getTokenString());        
                    symbolTable->enter("Function: " + std::string(tree->getStringValue()));
                    *enteredScope = true;
                    localOffset = -2;
                }
                 //Checks PARAM
                else
                {  
                    tree->setMemoryType(MemoryType::PARAM);
                    tree->calculateMemoryOffset();
                    //prints all PARAM names
                    //printf("PARAM>>  [ Line %d ] tree %s   \n",tree->getLineNum(),tree->getTokenString()); 
                    tree->setIsInitialized(true); 
                }
                
                //SO defined is true then already declared error comes
                //GLOBAL FUNCTION AND PARAM only cheks
                if (defined) 
                {                             
                    TokenTree *res = (TokenTree *) symbolTable->lookup(tree->getStringValue());
                    //prints all Param and Function names comes WHICH IS ALREADY DECLARED   
                    //printf("defined FUN and PARAM>>  [ Line %d ]  %s   \n",res->getLineNum(),res->getTokenString()); 
                    res->alreadyDeclared=1;
                    tree->alreadyDeclared=1;
                    //Global Function NAmes are set as is Used
                    err(tree);
                    printf("Symbol '%s' is already declared at line %d.\n", res->getStringValue(), res->getLineNum());
                }
            }
            //Checks All LOCAL and GLOBAL VARIABLES is Initialized or not
            else 
            {    
                //Prints all global and Local and Param Variables
                //printf("TREE  [ Line %d ]  %s   \n",tree->getLineNum(),tree->getTokenString()); 
                //GLOBAL VARIABLES
                if (tree->parent == NULL) 
                { 
                    tree->setMemoryType(MemoryType::GLOBAL);
                } 
                //STATIC LOCAL VARIABLES
                else if (tree->isStatic()) 
                {
                    tree->setMemoryType(MemoryType::LOCAL_STATIC);
                } 
                //Only LOCAL VAR Comes PARENT must "Begin"
                else 
                {
                    tree->setMemoryType(MemoryType::LOCAL);
                    // printf("TREE PARENT %s \n",tree->parent->getTokenString());  //TREE PARENT begin
                     //printf("TREE %s  Tree->children[0] ]\n",tree->getTokenString() );            
                }
                
                //All LOCAL and GLOABAL initialzations Only using : or any Expression  
                //Tree have Child 0- Which means a Initialization of variable Look below Example                
                if (tree->children[0] != NULL) 
                {
                    //char X:3;       TREE X  Tree->children[0] 3  [ Line 24 ]  Here Tree==X  tree->children[0]=3 
                    //char Y:K+6;     TREE Y  Tree->children[0] +  [ Line 25 ]  Here  children[0]= +      
                    //printf("TREE %s  Tree->children[0] %s  [ Line %d ]\n",tree->getTokenString() ,tree->children[0]->getTokenString(), tree->children[0]->getLineNum()); 
                    tree->setIsInitialized(true); 
                }
            }            
            break;
        }

        // <<<<<<<<case ExprKind::CALL: >>>>>>>>>>
        //Variable used as Function Call the error
        //Un declared function Call then Error
        // <<<<<<<<case ExprKind::ID: >>>>>>>>>>
        //Variable not declared error
        //Variable may be uninitialized when used  Error
        //Cannot use function 'Name as a variable Name Error
        case NodeKind::EXPRESSION: 
        {           
            switch (tree->getExprKind()) 
            {
                //ASSIGN only for oparator '<=' In assign  Already done in Down                
                case ExprKind::ASSIGN: 
                { 
                    // printf(">>[ Line %d ] TREE %s\n",tree->getLineNum(),tree->getTokenString());
                    break;
                }
                case ExprKind::CALL: 
                {
                    // all function call in the program
                    //printf("B4 CHLD CALL >> TREE %s   [ Line %d ]\n",tree->getStringValue() , tree->getLineNum());            
                    
                    TokenTree *res = (TokenTree *) symbolTable->lookup(tree->getStringValue()); 

                    //Checks the fun call Name is stored in Symbol Table, RES is taken from symbol table.
                    // iF the name is already in Syb then means already DEClared. 
                    // abve case DECLARATION- already added all the var and names in Symbol Table
                    //res==NULL meas the searcher fun call name not present in the SyB table. ie.. its not declared
                    if (res == NULL) 
                    {                        
                        err(tree);
                        printf("Symbol '%s' is not declared.\n", tree->getStringValue());
                    }                  
                    else 
                    {   
                         tree->setIsUsed(true); 
                         res->setIsUsed(true);                     
                        //if Variable used as Function Call then res is not NULL and error occures
                        //All variable such as parameters and global and local are checking
                        //in all  functions there is a call (name of variable) is occure then error comes
                        //UN DECAERED functions call NOT handles
                        //Sets the Exp Type same as RES
                        //RES is taken from Symbol Table by using lookup (ALL all variable name and Fun name already stored in Symbol Table)
                        tree->setExprType(res->getExprType()); 
                        if (res->getDeclKind() != DeclKind::FUNCTION) 
                        {
                            //printf("RES %s   [ Line %d ]\n",res->getStringValue() , res->getLineNum()); 
                            err(tree);
                            printf("'%s' is a simple variable and cannot be called.\n", tree->getStringValue());
                        }                        
                    }
                    break;
                }
                case ExprKind::CONSTANT: 
                {
                    //printf("RES %s   [ Line %d ]  %s \n",tree->getStringValue() , tree->getLineNum() , tree->getTypeString() ); 
                    if (tree->isArray()) 
                    {
                        tree->setMemoryType(MemoryType::GLOBAL);
                        tree->calculateMemoryOffset();
                    }
                    break;
                }
                //Only Checks Variable Names
                case ExprKind::ID: 
                {
                    //Looking for ID is in SYB Table
                    TokenTree *res = (TokenTree *) symbolTable->lookup(tree->getStringValue());
                   // printf("RES & PARENT %s  %s [ Line %d ]\n",res->getStringValue() ,tree->parent->getStringValue() , res->getLineNum() );    
                        
                    //res NULL -Then the Identifier not Found in SYMB. THEN NO AND CHECK it GOES TO ERROR
                    // res not null then then checks it  a Variable or not AND then Checks ID have any parent. a+b then + is the Parent. 
                    //If parent is Null.. Which means The ID is not used in any previous Expressions. 
                    //Also checks for the FUN CALL PARAMETERS too. if undeclared variable used then error shows
                    //After all checks it SHows Error Message 
                     if (res == NULL || (res->getDeclKind() == DeclKind::VARIABLE && tree->hasParent(res, true))) 
                    {
                        //printf("RES & PARENT %s  %s [ Line %d ]\n",res->getStringValue() ,tree->parent->getStringValue() , res->getLineNum() );    
                        if(tree->getExprType()!=ExprType::INT )
                        {  
                            err(tree);
                            printf("Symbol '%s' is not declared.\n", tree->getStringValue());
                        }
                    } 

                    //the Variable name ID already exist in SYMB then. ie Declared Vars
                    //and its not a Function
                    //ONLY DECLARED VARS BECOMES (IS_USED)
                    //Sets EXp type same as RES also isArray ans isStatic too
                    else if (res->getDeclKind() != DeclKind::FUNCTION) 
                    {
                        //it shows the declared variables
                        //printf("ReS  '%s' \n", res->getStringValue());
                        res->setIsUsed(true); 
                        tree->copyMemoryInfo(res);
                        tree->setExprType(res->getExprType());
                        tree->setIsArray(res->isArray());
                        tree->setIsStatic(res->isStatic());    
                        tree->setMemoryType(res->getMemoryType());
                        if (tree->shouldCheckInit() && res->shouldCheckInit() && !res->isInitialized() && res->parent != NULL  )  
                        {
                            warn(tree);                                            
                            printf("Variable '%s' may be uninitialized when used here.\n", tree->getStringValue());
                            res->cancelCheckInit(false); 
                        }
                    } 
                    //Here checks the Function names         
                    else 
                    {                       
                        err(tree);
                        printf("Cannot use function '%s' as a variable.\n", tree->getStringValue());                       
                        res->setIsUsed(true); 
                    }
                    break;
                }
            }
            break;
        }

        case NodeKind::STATEMENT: 
        {
            switch (tree->getStmtKind()) 
            {
                case StmtKind::COMPOUND: 
                {

                    tree->setMemoryType(MemoryType::NONE);            
                    if (compoundShouldEnterScope(tree->parent))
                    {  
                        *enteredScope = true;
                        symbolTable->enter("Compound Statement"); 
                        previousLocalOffset = localOffset;
                        break;
                    }

                    break;
                }

                case StmtKind::FOR: 
                {
                    *enteredScope = true;
                    symbolTable->enter("For Statement");
                    previousLocalOffset = localOffset;
                    tree->setMemoryType(MemoryType::NONE); 
                    //printf("tree *********** '%s'\n", tree->getStringValue());
                    TokenTree *child = tree->children[0];
                    //printf("child 00*********** '%s'\n", child->getStringValue());
                    TokenTree *array = tree->children[1];
                    //printf("array*********** '%s'\n", array->getStringValue());
                    TokenTree *res = (TokenTree *) symbolTable->lookup(array->getStringValue());
                    if (res != NULL) 
                    {
                        child->setExprType(res->getExprType());
                    }  
                    child->setIsInitialized(true);
                    break;
                }

                case StmtKind::RANGE: 
                {           
                *enteredScope = true;
                symbolTable->enter("Range");
                previousLocalOffset = localOffset;

                    TokenTree *res1 = (TokenTree *) symbolTable->lookup(tree->children[0]->getStringValue());
                    if (res1 != NULL&& res1->getExprType()!=ExprType::UNDEFINED ) 
                    {
                        //Cheking Variables used in Range are Array or Not. If it is array then Arroe Emits
                        if(res1->isArray())
                        {
                            err(tree);
                            printf("Cannot use array in position 1 in range of for statement.\n");                      
                        }
                        //Checking RANGE variables are INT else ERROR
                        if(res1->getExprType()!=ExprType::INT)
                        {
                            err(tree);
                            printf("Expecting type int in position 1 in range of for statement but got %s.\n",res1->getTypeString());                      
                        }
                    }
                    else if (tree->children[0] != NULL && tree->children[0] ->getExprType()!=ExprType::INT && tree->children[0]->getExprType()!=ExprType::UNDEFINED ) 
                    {
                            err(tree);
                            printf("Expecting type int in position 1 in range of for statement but got %s.\n",tree->children[0]->getTypeString());                      
                    }
                    
                    TokenTree *res2 = (TokenTree *) symbolTable->lookup(tree->children[1]->getStringValue()); 
                    if (res2 != NULL && res2->getExprType()!=ExprType::UNDEFINED ) 
                    {
                        if(res2->isArray())
                        { 
                            err(tree);
                            printf("Cannot use array in position 2 in range of for statement.\n");                      
                        }
                        if(res2->getExprType()!=ExprType::INT  )
                        {
                            err(tree);
                            printf("Expecting type int in position 2 in range of for statement but got %s.\n",res2->getTypeString());                      
                        }
                    }
                    else if (tree->children[1] != NULL && tree->children[1] ->getExprType()!=ExprType::INT && tree->children[1]->getExprType()!=ExprType::UNDEFINED ) 
                    {
                            err(tree);
                            printf("Expecting type int in position 2 in range of for statement but got %s.\n",tree->children[1]->getTypeString());                      
                    }

                    //IF there is STEp in For loop NUmber of child is 3
                    if(tree->getNumChildren()>2)
                    {
                        TokenTree *res3 = (TokenTree *) symbolTable->lookup(tree->children[2]->getStringValue());  
                        if (res3 != NULL && res3->getExprType()!=ExprType::UNDEFINED )  
                        {
                            if(res3->isArray())
                            {  
                                err(tree);
                                printf("Cannot use array in position 3 in range of for statement.\n");                      
                            }
                            if(res3->getExprType()!=ExprType::INT && strcmp(res3->getStringValue(),"main")!=0)
                            {
                                err(tree);
                                printf("Expecting type int in position 3 in range of for statement but got %s.\n",res3->getTypeString());                      
                            }
                        }
                        else if (tree->children[2] != NULL && tree->children[2] ->getExprType()!=ExprType::INT && tree->children[2]->getExprType()!=ExprType::UNDEFINED ) 
                        {
                                err(tree);
                                printf("Expecting type int in position 3 in range of for statement but got %s.\n",tree->children[2]->getTypeString());                      
                        }
                    }               
                    break;
                }

                case StmtKind::BREAK:
                {
                    TokenTree *visitor = tree;
                    bool foundLoop = false;
                    while (visitor->parent != NULL) {
                        TokenTree *parent = visitor->parent;
                        if (parent->getNodeKind() == NodeKind::STATEMENT && (parent->getStmtKind() == StmtKind::WHILE || parent->getStmtKind() == StmtKind::FOR)) {
                            foundLoop = true;
                            break;
                        }
                        visitor = parent;
                    }
                        
                    if (!foundLoop) {
                        err(tree);
                        printf("Cannot have a break statement outside of loop.\n");
                    }
                    break;
                }
            }
            break;
        }
    }
}


//-----------------------------------------------------AFTER CHILD----------------------------------------------------------->>
void afterChild(TokenTree *tree, int childNo) 
{
    switch (tree->getNodeKind()) 
    {
        case NodeKind::STATEMENT: 
        {
            switch (tree->getStmtKind()) 
            {
                case StmtKind::FOR: 
                {
                    if (childNo == 1) 
                    {
                        TokenTree *array = tree->children[1];
                        TokenTree *res = (TokenTree *) symbolTable->lookup(array->getStringValue());
                        if (res != NULL) 
                        {
                            res->setIsInitialized(true);
                        }                        
                    }
                    break;
                }
                case StmtKind::SELECTION: 
                {
                    if (childNo == 0) 
                    {
                       TokenTree *condition = tree->children[0];
                        if (!condition->isExprTypeUndefined()) {
                            if (condition->getExprType() != ExprType::BOOL) {
                                err(tree);
                                printf("Expecting Boolean test condition in %s statement but got %s.\n", tree->getTokenString(), condition->getTypeString());
                            }
                            if (condition->isArray()) {
                                err(tree);
                                printf("Cannot use array as test condition in %s statement.\n", tree->getTokenString());
                            }
                        }
                    }
                    break;
                }
                case StmtKind::WHILE: 
                {
                    if (childNo == 0) 
                    {
                        TokenTree *condition = tree->children[0];
                        if (!condition->isExprTypeUndefined()) 
                        {
                            if (condition->getExprType() != ExprType::BOOL) 
                            {
                                err(tree);
                                printf("Expecting Boolean test condition in %s statement but got %s.\n", tree->getTokenString(), condition->getTypeString());
                            }
                            if (condition->isArray()) 
                            {
                                err(tree);
                                printf("Cannot use array as test condition in %s statement.\n", tree->getTokenString());
                            }
                        }
                    }
                    break;
                }
            }
            break;
        }
    }
}


//-------------------------------------------------------------------ATER CHILD------------------------------------>>
void afterChildren(TokenTree *tree) 
{
    switch (tree->getNodeKind()) 
    {
        //<<<<<<<<<<<<<<VARIABLE>>>>>>>>>>>>>>>
        //Variable is already declared at line Error
        //<<<<<<<<<<<<<<EXPRESSION>>>>>>>>>>>>>>>
        // Unary Variable requires an operand of %s but was given Error
        // While assigning>> The operation '%s' does not work with arrays Error
        case NodeKind::DECLARATION: 
        {
            switch (tree->getDeclKind()) 
            {
                case DeclKind::FUNCTION: 
                {    
                    if (tree->getExprType() != ExprType::VOID && !tree->hasReturn()) 
                    {
                        warn(tree);
                        printf("Expecting to return %s but function '%s' has no return statement.\n", tree->getTypeString(), tree->getStringValue());
                    }
                    tree->calculateMemoryOfChildren(); 
                    break;
                }
                //This Section handles all the ID variables adnd Declaraion variables
                case DeclKind::VARIABLE: 
                {
                    bool defined = !symbolTable->insert(tree->getStringValue(), tree);                    
                    tree->calculateMemoryOffset();
                    TokenTree *child = tree->children[0]; 

                    //Ptints all the variables and initialized values
                    // printf("[ Line %d ] TREE %s   %d \n",tree->getLineNum(),tree->getTokenString(),tree->isArray() );    
                    // if (tree->children[0] != NULL )
                    //  printf("[ Line %d ] CHILD %s   %d \n",child->getLineNum(),child->getTokenString(),child->isArray() );    
                    //  printf("[ Line %d ] TREE %s   %d \n",tree->getLineNum(),tree->getTokenString(),tree->isArray() );    
                    //May be we need to check that was a constant type
                    //tree->children[0] != NULL meand the var X:25 ie. Initialized with somthing
                    if (tree->children[0] != NULL && tree->isArray()&& !child->isArray()) 
                    {
                        err(tree);
                        //Initializer for variable 'bb' requires both operands be arrays or not but variable is an array and r
                        printf("Initializer for variable '%s' requires both operands be arrays or not but variable is an array and rhs is not an array.\n", tree->getStringValue());
                    }

                    if (tree->children[0] != NULL && !tree->isArray()&& child->isArray()) 
                    {
                        err(tree);
                        //Initializer for variable 'bb' requires both operands be arrays or not but variable is an array and r
                        printf("Initializer for variable '%s' requires both operands be arrays or not but variable is not an array and rhs is an array.\n", tree->getStringValue());
                       //ERROR(7): Initializer for variable 'y' requires both operands be arrays or not but variable is not an array an
                    }

                    //Only COnstat Assign is posible 
                    if (tree->children[0] != NULL && !tree->children[0]->isConstantExpression()) 
                    {
                        err(tree);
                        printf("Initializer for variable '%s' is not a constant expression.\n", tree->getStringValue());
                    }
                    //Else Check ExpType of Both side of ASGN : oparator is same or not //QQQ
                    if (tree->children[0] != NULL && tree->children[0]-> getExprType() != tree->getExprType() && tree->children[0]-> getExprType()!=ExprType::UNDEFINED)
                    {
                        err(tree);
                        printf("Initializer for variable '%s' of %s is of %s\n", tree->getStringValue(),tree->getTypeString(),tree->children[0]->getTypeString());
                    }

                    // The variable Cant Insert then means, Its alredy Inserted                    
                    if (defined) 
                    {
                        TokenTree *res = (TokenTree *) symbolTable->lookup(tree->getStringValue());
                        tree->alreadyDeclared=100;
                        err(tree);
                        printf("Symbol '%s' is already declared at line %d.\n", res->getStringValue(), res->getLineNum());
                    }   
                    break;
                }
            }
            break;
        }
        case NodeKind::EXPRESSION: 
        {
            switch (tree->getExprKind()) 
            {
                // In ++ and -- oparator uses varable other than INT then error 
                // in + -- Array cant use as Variable then Error

                //In == both side are not same teen Error
                //In == both sides are not Array Then Error

                //Bothe Side of ADDASS,SUBASS,MULASS,DIVASS, <= Oparators are not array then Error
                //
                case ExprKind::ASSIGN: 
                {
                    TokenTree *lhs = tree->children[0];
                    TokenTree *rhs = tree->children[1];
                    //IF LHS is NUll then means its a Unary Assignment OParator ++ --
                    //Sets RHS as INT exp Type
                    if (rhs == NULL) //inc dec ++ --
                    { 
                        tree->setExprType(ExprType::INT);
                        if (tree->checkCascade()) 
                        {
                            // The varaiable not an INT then Error Comes
                            if (lhs->getExprType() != ExprType::INT) 
                            {
                                err(tree);
                                printf("Unary '%s' requires an operand of %s but was given %s.\n", tree->getTokenString(), tree->getTypeString(), lhs->getTypeString());
                            }
                        }
                        
                        //in + -- Array cant use so LHS is array then error comes
                        if (lhs->isArray()) 
                        {
                            err(tree);
                            printf("The operation '%s' does not work with arrays.\n", tree->getTokenString());
                        }
                    } 
                    else // the tree node is  == ,ADDASS,SUBASS,MULASS,DIVASS, <=
                    { 
                        //checks its a EQULEQUALTO oparator or not == 
                        bool isAssign = (strcmp(tree->getStringValue(), "=") == 0);
                        
                        // the Tre node is == Then
                        if (isAssign) 
                        {
                            // The Exp type of == s set as type of LHS and                         
                            tree->setExprType(lhs->getExprType());

                            //IF LHS is an array then == set as an Array
                            tree->setIsArray(lhs->isArray());
                            
                            // checkCascade() if any child is UNDEFIND then retuns false
                            if (tree->checkCascade()) 
                            { 
                                //Checks Both side are same type of Exp Kind
                                if (!sameType(lhs, rhs))
                                {
                                    err(tree);
                                    printf("'%s' requires operands of the same type but lhs is %s and rhs is %s.\n", tree->getTokenString(), lhs->getTypeString(), rhs->getTypeString());
                                }
                            }

                            //Checks In == both sides are Array or not
                            if (lhs->isArray() ^ rhs->isArray())
                            {
                                char *lhsStr = (char*) "";
                                char *rhsStr = (char*) "";
                                if (!lhs->isArray()) lhsStr = (char*) " not";
                                if (!rhs->isArray()) rhsStr = (char*) " not";
                                //X
                                err(tree);
                                printf("'%s' requires both operands be arrays or not but lhs is%s an array and rhs is%s an array.\n", tree->getTokenString(), lhsStr, rhsStr);
                            }
                        } 

                        //ADDASS,SUBASS,MULASS,DIVASS, <= Oparators checking
                        else 
                        {
                            //Expression Type Of <=,+=,-=,/=,*=,%= Set as INT Here
                            tree->setExprType(ExprType::INT);                            

                            //His only For +=, -=, *=,/=,%=
                            if(strcmp(tree->getTokenString(),"<=")!=0)
                            {
                                if (lhs->isArray() || rhs->isArray())
                                {
                                        err(tree);
                                        printf("The operation '%s' does not work with arrays.\n", tree->getTokenString());
                                }
                                if (!lhs->isExprTypeUndefined() && lhs->getExprType() != ExprType::INT) 
                                {
                                    err(tree);
                                    printf("'%s' requires operands of %s but lhs is of %s.\n", tree->getTokenString(), tree->getTypeString(), lhs->getTypeString());
                                }

                                if (!rhs->isExprTypeUndefined() && rhs->getExprType() != ExprType::INT) 
                                {
                                    err(tree);
                                    printf("'%s' requires operands of %s but rhs is of %s.\n", tree->getTokenString(), tree->getTypeString(), rhs->getTypeString());
                                }
                            }

                            //THis is for <=
                            else if(strcmp(tree->getTokenString(),"<=")==0)
                            {
                                //if oparator is <= then changes EXp TYpe to BOOL
                                //tree->setExprType(ExprType::BOOL);
                                tree->setExprType(lhs->getExprType());
                                if(lhs->isArray() && rhs->isArray())
                                {
                                    tree->setIsArray(true);
                                }
                                // printf("LHS Is ARRAY : %s\n",lhs->getTokenString());

                                // if(rhs->isArray())
                                // printf("RHS Is ARRAY : %s\n",rhs->getTokenString());

                                //Setting Is used For Avoidigng error of forb. NOT WORKING
                                tree->children[0]->setIsUsed(true);    
                                //tree->children[1]->setIsUsed(true);  
                                //lhs->setIsUsed(true);  
                                lhs->setIsUsed(true);  

                                //printf("[ Line %d ] TREE %s        LHS %s  %s (%d)        RHS %s %s (%d).\n",tree->getLineNum(),tree->getTokenString(),     lhs->getTokenString(),lhs->getTypeString(),lhs->isArray(),     rhs->getTokenString(),rhs->getTypeString(),rhs->isArray());    

                                //IF both side are not UNDEFF
                                if ( !lhs->isExprTypeUndefined() && !rhs->isExprTypeUndefined() )//NEW added for DOnt check undefined kind var
                                if (lhs->getTypeString() != rhs->getTypeString())
                                {
                                    //printf("[ Line %d ] TREE %s        LHS %s  %s (%d)        RHS %s %s (%d).\n",tree->getLineNum(),tree->getTokenString(),     lhs->getTokenString(),lhs->getTypeString(),lhs->isArray(),     rhs->getTokenString(),rhs->getTypeString(),rhs->isArray());    
                                    err(tree);
                                    printf("'%s' requires operands of the same type but lhs is %s and rhs is %s.\n", tree->getTokenString(), lhs->getTypeString(),rhs->getTypeString());
                                    
                                }
                                // Bothe Side of ADDASS,SUBASS,MULASS,DIVASS, <= Oparators are not array then Error 
                                if (lhs->isArray() ^ rhs->isArray()) 
                                {
                                    char *lhsStr = (char*) "";
                                    char *rhsStr = (char*) "";
                                    if (!lhs->isArray()) lhsStr = (char*) " not";
                                    if (!rhs->isArray()) rhsStr = (char*) " not";
                                    err(tree);
                                    printf("'%s' requires both operands be arrays or not but lhs is%s an array and rhs is%s an array.\n", tree->getTokenString(), lhsStr, rhsStr);
                                }
                            }
                        }
                        TokenTree *res;
                        if (lhs->getExprKind() == ExprKind::ID) 
                        {
                            res = (TokenTree *) symbolTable->lookup(lhs->getStringValue());
                        } 
                        else 
                        {
                            res = (TokenTree *) symbolTable->lookup(lhs->children[0]->getStringValue());
                        }
                        if (res == NULL || res->getDeclKind() == DeclKind::FUNCTION) 
                        {
                            break;
                        }
                        res->setIsInitialized(true);
                    }
                    break;
                }
                //in 4th asgnment This is not  treated as an error
                case ExprKind::CALL: 
                {
                    TokenTree *res = (TokenTree *) symbolTable->lookupGlobal(tree->getStringValue());                 
                    if (res != NULL) 
                    {
                        //printf("Function DeFF [ Line %d ] res %s  \n",res->getLineNum(),res->getTokenString()); 
                    
                        TokenTree *param = res->children[0];
                        TokenTree *input = tree->children[0];

                        int numParams, numInputs;
                        if (param == NULL) 
                            numParams = 0; 
                        //Takeing NUmber of Parameters 
                        else 
                        {
                            numParams = param->getNumSiblings(true);
                            //printf("Numnber of parameters  %d \n",numParams); 
                        }
                        if (input == NULL) 
                            numInputs = 0; 
                        else 
                        {
                            numInputs = input->getNumSiblings(true);   
                            //printf("Numnber of numInputs  %d \n",numInputs); 
                        }                           

                        if (numParams < numInputs && strcmp(res->getStringValue(),"main")!=0 ) 
                        {
                            //printf(">>>>>>>%s  %d\n", res->getStringValue(),res->alreadyDeclared);
                            err(tree);
                            printf("Too many parameters passed for function '%s' declared on line %d.\n", res->getStringValue(), res->getLineNum());
                        }
                        //Extra check for main(0 function)
                        if (numParams < numInputs && strcmp(res->getStringValue(),"main")==0 && res->alreadyDeclared==0) 
                        {
                            //printf(">>>>>>>%s  %d\n", res->getStringValue(),res->alreadyDeclared);
                            err(tree);
                            printf("Too many parameters passed for function '%s' declared on line %d.\n", res->getStringValue(), res->getLineNum());
                        }
                        if (numParams > numInputs) 
                        {
                            err(tree);
                            printf("Too few parameters passed for function '%s' declared on line %d.\n", res->getStringValue(), res->getLineNum());
                        }
                        //ASn 4 Not need This Checking
                        if(res->getLineNum()==-1)
                        {
                        //    err(tree);                            
                        //    printf("Symbol '%s' is not declared.\n", tree->getStringValue());
                        }  
                    }
                    break;
                }               
                case ExprKind::OP: 
                {                    
                    if(tree->getExprType()!=ExprType::BOOL);
                    {
                        void (*fp)(TokenTree *) = functionPointers[indexOfOperation(tree)];
                        fp(tree);
                    }
                    break;
                }
                case ExprKind::ID: 
                {                    
                    break;
                }
            }
            break;
        }
        case NodeKind::STATEMENT: 
        {
            switch (tree->getStmtKind()) 
            {
                case StmtKind::RETURN:
                 {
                    //Sets the functio have Return Value
                    tree->function->setHasReturn(true); 
                    //printf(">>>>Function Name  %s \n", tree->function->getStringValue());
                    
                    //Taking child Tree It must be the return value Normally
                    //But in case of <= assignment happens in for loop he return value is '<=' coming
                    //Also if a retun is an Expression, Then return value is the 'op' such s + or * 
                    TokenTree *returnValue = tree->children[0];                
                    //printf(">>>>returnValue  %s \n", returnValue->getStringValue());

                    //if return exists then returnNodeExists becomes true
                    bool returnNodeExists = returnValue != NULL;

                    //if return exixt and its NOT VOID then True stored to expectingReturn
                    bool expectingReturn = tree->function->getExprType() != ExprType::VOID;

                    //if return is there
                    if (returnNodeExists) 
                    {
                        //and return is not VOID then
                        if (expectingReturn) 
                        {
                            if (!returnValue->isExprTypeUndefined() && returnValue->getExprType() != tree->function->getExprType()) {
                               //printf(">>>>returnValue  %s \n", returnValue->getTypeString());                             
                                err(tree);
                                printf("Function '%s' at line %d is expecting to return %s but returns %s.\n", tree->function->getStringValue(), tree->function->getLineNum(), tree->function->getTypeString(), returnValue->getTypeString());
                            }
                        } 
                        // If there is a void type retun and Function returns some othe value then error
                        else 
                        { 
                            err(tree);
                            printf("Function '%s' at line %d is expecting no return value, but return has a value.\n", tree->function->getStringValue(), tree->function->getLineNum());
                        }

                        // ID and CONT case-If function Returns an array then it Show Error 
                        //BUT first Cheks the return value is direct Constant or Variable value 
                        if ( returnValue->getExprKind() == ExprKind::ID || returnValue->getExprKind() == ExprKind::CONSTANT )
                        {
                            if (returnValue->isArray()) 
                            {
                                err(tree);
                                printf("Cannot return an array.\n");
                            }
                        }
                        //OP >= case-  If function Returns an array then it Show Error
                        //BUT first Cheks the return value is direct Constant or Variable value 
                        //ASN7 this is not needed
                        // else
                        // {
                        //         //Takes the child of the OP <= or * then checks it an array or not also checks there is any child
                        //         //Also its Number of child must be 0 cos else it may array element eg.x[5]. if its an array ement it mus have childrens.  
                        //         if ( returnValue->children[0]!= NULL && returnValue->children[0]->isArray() && returnValue->children[0]->getNumChildren()==0) 
                        //         {

                        //             printf("returnValue  %s  %d\n", returnValue->getStringValue(),returnValue->children[0]->getNumChildren());
                        //             //We can Also done this by checking the number Childrens 
                        //             if (strcmp(returnValue->getStringValue(),"[")!=0 && strcmp(returnValue->getStringValue(),"sizeof")!=0  )
                        //             {
                        //                 err(tree);
                        //                 printf("44Cannot return an array.\n"); //>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>
                        //             }
                        //         }
                        // }
                    } 
                    //There is no return statement in the function BUT found a return statement in function body then Eroor shows
                    else 
                    { 
                        //and it check it not a VOID
                        if (expectingReturn) 
                        {
                            err(tree);
                            printf("Function '%s' at line %d is expecting to return %s but return has no value.\n", tree->function->getStringValue(), tree->function->getLineNum(), tree->function->getTypeString());
                        }
                    }
                    break;
                }
            }
            break;
        }
    }
   
    if (tree->parent != NULL && tree->parent->getNodeKind() == NodeKind::EXPRESSION && tree->parent->getExprKind() == ExprKind::CALL)
    {
        TokenTree *res = (TokenTree *) symbolTable->lookup(tree->parent->getStringValue());
        //printf(">>>>>res is Null then>>>>>>RES'%s.\n", tree->getStringValue());

        if (res != NULL) 
        {
            int counter = 1;
            TokenTree *param = res->children[0];
            TokenTree *input = tree->parent->children[0]; 
            while (input != tree && param != NULL) 
            { 
                param = param->sibling; 
                input = input->sibling;
                counter++;
            }  

            if (param != NULL) 
            { // If param is null, then we had more inputs than function allowed
                //printf(">>>param  %s  %d \n", res->getStringValue(), res->getLineNum());

                if(res->getLineNum()!=-1)
                {
                    if (!input->isExprTypeUndefined() && param->getExprType() != input->getExprType()) 
                    {
                        err(tree);
                        printf("Expecting %s in parameter %i of call to '%s' declared on line %d but got %s.\n", param->getTypeString(), counter, res->getStringValue(), res->getLineNum(), input->getTypeString());
                    }
                }
                if (param->isArray() && !input->isArray()) {
                    err(tree);
                    printf("Expecting array in parameter %i of call to '%s' declared on line %d.\n", counter, res->getStringValue(), res->getLineNum());
                }
                 else if (!param->isArray() && input->isArray()) {
                    err(tree);
                    printf("Not expecting array in parameter %i of call to '%s' declared on line %d.\n", counter, res->getStringValue(), res->getLineNum());
                }
            }
        }
    }
}




struct Warning 
{
    int lineNum;
    std::string name;
    std::string type;

    bool operator<(const Warning& other) const 
    {
        return lineNum < other.lineNum;
    }
};

std::vector<Warning> warnings;

void addWarning(int lineNum, const std::string& name, const std::string& type) 
{
    warnings.push_back({lineNum, name, type});
}
void printWarnings() 
{
    //std::sort(warnings.begin(), warnings.end());
    for (auto it = warnings.rbegin(); it != warnings.rend(); ++it) 
    {
        std::cout << "WARNING(" << it->lineNum << "): The " << it->type << " '" << it->name << "' seems not to be used.\n";
    }
    
    //std::cout << "Total warnings: " << warnings.size() << "\n";
}



void globalCheckUsage(TokenTree *tree) 
{
    
    if(tree->getLineNum()!=-1)   
    {
        if ( tree->getDeclKind() == DeclKind::VARIABLE) 
        {
            if (tree->parent == NULL) 
            if(strcmp(tree->getStringValue(),"main")!=0)
            {
                if (!tree->isUsed()&& tree->alreadyDeclared!=100) 
                {
                    addWarning(tree->getLineNum(),  tree->getStringValue(), "variable");
                    numWarnings++;                 
                }
            }
        }
    }   
    if(tree->getLineNum()!=-1)   
    {
        if ( tree->getDeclKind() == DeclKind::FUNCTION) 
        {
            if (tree->parent == NULL) 
            if(strcmp(tree->getStringValue(),"main")!=0)
            {
                if (!tree->isUsed()&& tree->alreadyDeclared!=1) 
                {
                    addWarning(tree->getLineNum(),  tree->getStringValue(), "function");
                    numWarnings++;                 
                }
            }
        }
    }
}


//checks argument node is isUsed or not
//if node's isUsed is false then error shows
//DBT-Only in EXPRESSION can make a variable used or not
//DB- Only CALL can make a function used or not
//DB-ASSIGN can make isused
//DB-CONSTANS are always is used 
void checkUsage(std::string, void *node) 
{
    //creates a new treanode as same as argument node.
    TokenTree *tree = (TokenTree *) node;
    //argument node's knd copied to nk
    NodeKind nk = tree->getNodeKind(); 

   //printf(">>>>>>>>> %s\n", tree->getStringValue());
    //Which means only works in  VARIABLE, PARAM and must be DECLARATION
    if (nk == NodeKind::DECLARATION && tree->getDeclKind() == DeclKind::VARIABLE) 
    {
        if (!tree->isUsed()) 
        {
             {                               
                warn(tree);
                printf("The variable '%s' seems not to be used.\n", tree->getStringValue());
             }             
        }
    }
    if (nk == NodeKind::DECLARATION && tree->getDeclKind() == DeclKind::PARAM) 
    {
        if (!tree->isUsed()) 
        {
             {                               
                warn(tree);
                printf("The parameter '%s' seems not to be used.\n", tree->getStringValue());
             }             
        }
    }
    //globalCheckUsage(tree); 
}

   
//traversing the TokenTree in a depth-first manner, visiting all the nodes in the tree.
//First Calls beforeChildren
//Then afterChild
//then afterChildren
void buildSymbolTable(TokenTree *tree) 
{
    bool enteredScope = false;
    int previousLocalOffset = -2;
   // globalCheckUsage(tree); 
    beforeChildren(tree, &enteredScope, previousLocalOffset);  
    //globalCheckUsage(tree); 
    for (int i = 0; i < MAX_CHILDREN; i++) 
    {
        TokenTree *child = tree->children[i];
        //globalCheckUsage(tree); 
        if (child != NULL) 
        {
            //globalCheckUsage(tree); 
            buildSymbolTable(child);
           // globalCheckUsage(tree); 
        }
        //globalCheckUsage(tree); 
        afterChild(tree, i);    
       // globalCheckUsage(tree); 
    }    
    //globalCheckUsage(tree); 
    afterChildren(tree);
    //globalCheckUsage(tree); 
    if (enteredScope) 
    {     
        //globalCheckUsage(tree); 
        symbolTable->applyToAll(checkUsage);
        //globalCheckUsage(tree); 
        symbolTable->leave();
        localOffset = previousLocalOffset;
        //globalCheckUsage(tree); 
    }
    //globalCheckUsage(tree); 
    if (tree->sibling != NULL) {
        //globalCheckUsage(tree); 
        buildSymbolTable(tree->sibling);
       // globalCheckUsage(tree); 
    }
    globalCheckUsage(tree); 
    
}

void buildIORoutines() //The buildIORoutines() function builds the symbol table for input/output (I/O) routines.
{
    TokenTree *outnl = new TokenTree();
    outnl->setDeclKind(DeclKind::FUNCTION);
    outnl->setLineNum(-1);
    outnl->setTokenString((char *) "outnl");
    outnl->setStringValue((char *) "outnl");
    outnl->setExprType(ExprType::VOID);

    TokenTree *inputc = new TokenTree();
    inputc->setDeclKind(DeclKind::FUNCTION);
    inputc->setLineNum(-1);
    inputc->setTokenString((char *) "inputc");
    inputc->setStringValue((char *) "inputc");
    inputc->setExprType(ExprType::CHAR);
    inputc->setHasReturn(true);
    inputc->addSibling(outnl);

    TokenTree *inputb = new TokenTree();
    inputb->setDeclKind(DeclKind::FUNCTION);
    inputb->setLineNum(-1);
    inputb->setTokenString((char *) "inputb");
    inputb->setStringValue((char *) "inputb");
    inputb->setExprType(ExprType::BOOL);
    inputb->setHasReturn(true);
    inputb->addSibling(inputc);

    TokenTree *input = new TokenTree();
    input->setDeclKind(DeclKind::FUNCTION);
    input->setLineNum(-1);
    input->setTokenString((char *) "input");
    input->setStringValue((char *) "input");
    input->setExprType(ExprType::INT);
    input->setHasReturn(true);
    input->addSibling(inputb);

    TokenTree *charDummy = new TokenTree();
    charDummy->setDeclKind(DeclKind::PARAM);
    charDummy->setLineNum(-1);
    charDummy->setTokenString((char *) "*dummy*");
    charDummy->setStringValue((char *) "*dummy*");
    charDummy->setExprType(ExprType::CHAR);
    charDummy->cancelCheckInit(false);
    charDummy->setIsUsed(true);

    TokenTree *outputc = new TokenTree();
    outputc->setDeclKind(DeclKind::FUNCTION);
    outputc->setLineNum(-1);
    outputc->setTokenString((char *) "outputc");
    outputc->setStringValue((char *) "outputc");
    outputc->setExprType(ExprType::VOID);
    outputc->children[0] = charDummy;
    outputc->addSibling(input);

    TokenTree *boolDummy = new TokenTree();
    boolDummy->setDeclKind(DeclKind::PARAM);
    boolDummy->setLineNum(-1);
    boolDummy->setTokenString((char *) "*dummy*");
    boolDummy->setStringValue((char *) "*dummy*");
    boolDummy->setExprType(ExprType::BOOL);
    boolDummy->cancelCheckInit(false);
    boolDummy->setIsUsed(true);

    TokenTree *outputb = new TokenTree();
    outputb->setDeclKind(DeclKind::FUNCTION);
    outputb->setLineNum(-1);
    outputb->setTokenString((char *) "outputb");
    outputb->setStringValue((char *) "outputb");
    outputb->setExprType(ExprType::VOID);
    outputb->children[0] = boolDummy;
    outputb->addSibling(outputc);

    TokenTree *intDummy = new TokenTree();
    intDummy->setDeclKind(DeclKind::PARAM);
    intDummy->setLineNum(-1);
    intDummy->setTokenString((char *) "*dummy*");
    intDummy->setStringValue((char *) "*dummy*");
    intDummy->setExprType(ExprType::INT);
    intDummy->cancelCheckInit(false);
    intDummy->setIsUsed(true);

    TokenTree *output = new TokenTree();
    output->setDeclKind(DeclKind::FUNCTION);
    output->setLineNum(-1);
    output->setTokenString((char *) "output");
    output->setStringValue((char *) "output");
    output->setExprType(ExprType::VOID);
    output->children[0] = intDummy;
    output->addSibling(outputb);

    buildSymbolTable(output);
}

//Building IORoutines and Building Symbol Table
//Checks there is main function declared or not -ERROR shows
//checks main have parameters or not -ERROR shows
void buildSymbolTable() 
{
    buildIORoutines();
    //this call checks for erros
    buildSymbolTable(syntaxTree);  
    printWarnings();
    TokenTree *main = (TokenTree *) symbolTable->lookupGlobal("main"); 
    if (main == NULL || main->getNumChildren()>1 ||main->getDeclKind() != DeclKind::FUNCTION  )  
    {        
        printf("ERROR(LINKER): A function named 'main' with no parameters must be defined.\n");
        numErrors++;
    }
}


