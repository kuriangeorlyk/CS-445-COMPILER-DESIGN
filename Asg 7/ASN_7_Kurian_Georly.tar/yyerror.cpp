
#include <string.h>
#include <stdio.h>
#include <stdlib.h>
#include <map>
#include <string>
#include "yyerror.h"

// sentinal marker. The sentinel symbol is used to identify the point at which a particular structure ends and another begins. 
static int split(char *s, char *strs[], char breakchar)
{
    //printf(">> strs: %s\n ",s);
    int num;
    //argument s is the error Message
    strs[0] = s;
    num = 1;
    //for loop Which travers at the String array
    for (char *p = s; *p; p++) 
    {
        if (*p==breakchar) //When Founds Space It Works
        {           
            strs[num++] = p+1;
            *p = '\0';          
        }
         
    }
    //The strs Contains Spllited Error Message.strs[0]="syntax"
    strs[num] = NULL;
    //The Num is the count of words in Error message 
    return num;
}


// trim off the last character
static void trim(char *s)
{
    //The Length -1 Charecter becomes NULL, So last charecter is Removed and filled with NULL Char
    s[strlen(s)-1] = '\0';
    //strs: NUMCONST-> here s is what got unexpectly
    //printf(">> strs: %s\n ",s);
}

// map from string to char * for storing nice translation of
// internal names for tokens.  Preserves (char *) used bybison.
static std::map<std::string , char *> niceTokenNameMap;    // use an ordered map (not as fast as unordered)

// WARNING: this routine must be called to initialize mapping of
// (strings returned as error message) --> (human readable strings)
//
void initErrorProcessing() {
    niceTokenNameMap["ADDASS"] = (char *)"\"+=\"";
    niceTokenNameMap["AND"] = (char *)"\"and\"";
    niceTokenNameMap["ASGN"] = (char *)"\':\'";
    niceTokenNameMap["LEQ"] = (char *)"\"<=\"";
    niceTokenNameMap["BGN"] = (char *)"\"begin\"";
    niceTokenNameMap["BOOL"] = (char *)"\"bool\"";
    niceTokenNameMap["BOOLCONST"] = (char *)"Boolean constant";
    niceTokenNameMap["BREAK"] = (char *)"\"break\"";
    niceTokenNameMap["STEP"] = (char *)"\"step\"";
    niceTokenNameMap["CHAR"] = (char *)"\"char\"";
    niceTokenNameMap["CHARCONST"] = (char *)"character constant";
    niceTokenNameMap["CHSIGN"] = (char *)"-";
    niceTokenNameMap["DEC"] = (char *)"\"--\"";
    niceTokenNameMap["DIVASS"] = (char *)"\"/=\"";
    niceTokenNameMap["DO"] = (char *)"\"do\"";
    niceTokenNameMap["ELSE"] = (char *)"\"else\"";
    niceTokenNameMap["END"] = (char *)"\"end\"";
    niceTokenNameMap["EQ"] = (char *)"\'=\'"; 
    niceTokenNameMap["FOR"] = (char *)"\"for\"";
    niceTokenNameMap["NOTLESSTHAN"] = (char *)"\"!<\"";
    niceTokenNameMap["ID"] = (char *)"identifier";
    niceTokenNameMap["IF"] = (char *)"\"if\"";
    niceTokenNameMap["INC"] = (char *)"\"++\"";
    niceTokenNameMap["INT"] = (char *)"\"int\"";
    niceTokenNameMap["NOTGRTRTHAN"] = (char *)"\"!>\"";
    niceTokenNameMap["MULASS"] = (char *)"\"*=\"";
    niceTokenNameMap["NEQ"] = (char *)"\"!=\"";
    niceTokenNameMap["NOT"] = (char *)"\"not\"";
    niceTokenNameMap["NUMCONST"] = (char *)"numeric constant";
    niceTokenNameMap["OR"] = (char *)"\"or\"";
    niceTokenNameMap["RETURN"] = (char *)"\"return\"";
    niceTokenNameMap["SIZEOF"] = (char *)"\"*\"";
    niceTokenNameMap["STATIC"] = (char *)"\"static\"";
    niceTokenNameMap["STRINGCONST"] = (char *)"string constant";
    niceTokenNameMap["SUBASS"] = (char *)"\"-=\"";
    niceTokenNameMap["THEN"] = (char *)"\"then\"";
    niceTokenNameMap["TO"] = (char *)"\"..\"";
    niceTokenNameMap["WHILE"] = (char *)"\"while\"";
    niceTokenNameMap["en"] = (char *)"end of input";
    niceTokenNameMap["file,"] = (char *)"end of input";
    niceTokenNameMap["$end"] = (char *)"end of input";
}

// looks of pretty printed words for tokens that are
// not already in single quotes.  It uses the niceTokenNameMap table.
static char *niceTokenStr(char *tokenName ) 
{
    //printf(">> tokenName: %s\n ",tokenName);
    //printf(">> tokenName [0]: %d\n ",tokenName[0]);    
    if (tokenName[0] == '\'') 
        return tokenName;
    if (niceTokenNameMap.find(tokenName) == niceTokenNameMap.end()) 
    {
        printf("ERROR(SYSTEM): niceTokenStr fails to find string '%s'\n", tokenName); 
        fflush(stdout);
        exit(1);
    }
    //If token name finds then the sutable Nice Token Name returns eg: niceTokenNameMap["NUMCONST"] = (char *)"numeric constant";
    //Eg: if unexpected NUMCONST Found then the "numeric constant" returns alternatively for NUMCONST
    return niceTokenNameMap[tokenName];
}

// Is this a message that we need to elaborate with the current parsed token.
// This elaboration is some what of a crap shoot since the token could
// be already overwritten with a look ahead token.   But probably not.
static bool elaborate(char *s)
{
    return (strstr(s, "constant") || strstr(s, "identifier"));
}

// A tiny sort routine for SMALL NUMBERS of
// of char * elements.  num is the total length
// of the array but only every step elements will
// be sorted.  The "up" flag is direction of sort.
// For example:
//    tinySort(str, i, 2, direction);      // sorts even number elements in array
//    tinySort(str+1, i-1, 2, direction);  // sorts odd number elements in array
//    tinySort(str, i, 1, direction);      // sorts all elements in array
//
static void tinySort(char *base[], int num, int step, bool up)
{
    for (int i=step; i<num; i+=step) {
        for (int j=0; j<i; j+=step) {
            if (up ^ (strcmp(base[i], base[j])>0)) {
                char *tmp;
                tmp = base[i]; base[i] = base[j]; base[j] = tmp;
            }
        }
    }
}

// This is the yyerror called by the bison parser for errors.
// It only does errors and not warnings.   
void yyerror(const char *msg)
{
    char *space;
    char *strs[100];
    int numstrs;
    // make a copy of msg string
    space = strdup(msg);

    // split out components
    numstrs = split(space, strs, ' ');
    if (numstrs>4) 
        trim(strs[3]);

    // translate components
    for (int i=3; i<numstrs; i+=2) 
    {
        strs[i] = niceTokenStr(strs[i]);
    }

    printf("ERROR(%d): Syntax error, unexpected %s", lineNum, strs[3]);
    if (elaborate(strs[3])) 
    {
        if (lastToken[0]=='\'' || lastToken[0]=='"') 
            printf(" %s", lastToken); 
        else 
            printf(" \"%s\"", lastToken);//unexpected identifier1111 "y",
    }

    if (numstrs>4) printf(",");

    // print sorted list of expected
    tinySort(strs+5, numstrs-5, 2, true); 
    for (int i=4; i<numstrs; i++) 
    {
        printf(" %s", strs[i]);//identifier1111 "k",22222 expecting22222 ']'.
    }
    printf(".\n");
    fflush(stdout);   // force a dump of the error

    numErrors++;

    free(space);
}

