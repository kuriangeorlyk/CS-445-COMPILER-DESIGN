#ifndef CODEGEN_H
#define CODEGEN_H

void generateCode(char []);

#endif