#ifndef _OURGETOPT_H_
#define _OURGETOPT_H_
int ourGetopt( int, char **, char*);
extern char *optarg;  
extern int optopt;                     
#endif