#ifndef TOKEN_TREE_H
#define TOKEN_TREE_H
#define MAX_CHILDREN 3
#include <stddef.h>
// enums class creation to store Main Kind of Token
enum class NodeKind { DECLARATION, EXPRESSION, STATEMENT };

// enums class creation to store  subkind of Token
enum class DeclKind { FUNCTION, VARIABLE, PARAM };
enum class ExprKind { CALL, CONSTANT, ID, UID, OP, ASSIGN };
enum class StmtKind { COMPOUND, SELECTION, FOR, WHILE, RETURN, BREAK, RANGE };

// enums class creation to store KInd and Type of Token
enum class ExprType { INT, BOOL, CHAR, VOID, STRING, UNDEFINED };

class TokenTree {
    private:
    public:
        // Token Information
        int tokenClass;         //ClassID
        int lineNum;            //Linenumber
        char *tokenStr;         // what string was actually read
        char cvalue;            // any character value
        int  nvalue;            // any numeric value or Boolean value
        char *svalue;           // any string value e.g. an id

        // Expression Information MAIN KIND
        NodeKind nodeKind; //Enum Object nodeKind-determine kind of nodes { DECLARATION, EXPRESSION, STATEMENT }
        union {
            DeclKind declKind;  
            ExprKind exprKind; //SUBKINDS
            StmtKind stmtKind;
        } subKind;   //Object of Objects   subKind.declKind = dk;  OR subKind.exprKind   
        ExprType exprType = ExprType::UNDEFINED;  //Data Types expr types  {INT, BOOL, CHAR, VOID, UNDEFINED}
        
        char *exprName;        
        int lastLine;
        void _printTree(int level, bool isChild, bool isSibling, int num);

    public:
        TokenTree();
        void setTokenClass(int tc);
        int getTokenClass();
        void setLineNum(int line);
        int getLineNum();
        void setTokenString(char *str);
        char *getTokenString();
        void setCharValue(char c);
        char getCharValue();
        void setNumValue(int n);
        int getNumValue();    
        void setStringValue(char *str);       
        void setStringValue(char *str, bool duplicate);
        char *getStringValue();  

        TokenTree *children[3] = {NULL};
        TokenTree *parent = NULL;
        TokenTree *sibling = NULL;
        TokenTree *function = NULL;

   
        void setNodeKind(NodeKind nk);
        NodeKind getNodeKind();
        void setDeclKind(DeclKind dk);
        DeclKind getDeclKind();
        void setExprKind(ExprKind ek);
        ExprKind getExprKind();
        void setStmtKind(StmtKind sk);
        StmtKind getStmtKind();
        void setExprType(ExprType et); 
        ExprType getExprType();
        const char *getTypeString();

        void setExprName(char *name); 
        char *getExprName();
        void setIsArray(bool b);
        bool isArray();
        void setIsStatic(bool b);
        bool isStatic();
        bool _isArray = false;
        bool _isStatic = false;

        void addSibling(TokenTree *sibl);        
        void typeSiblings(ExprType type);          
        void printTree();
        void printNode();
        void printLine();
};

#endif