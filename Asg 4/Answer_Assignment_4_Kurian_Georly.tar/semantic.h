#ifndef SEMANTIC_H
#define SEMANTIC_H
#include "TokenTree.h"
void buildSymbolTable();
#endif