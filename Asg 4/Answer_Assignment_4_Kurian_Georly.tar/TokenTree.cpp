#include <stdexcept>
#include <stdio.h>
#include <string.h>
#include "TokenTree.h"

extern int globalOffset;
extern int localOffset;

TokenTree::TokenTree() {
    // Cunstructor - Initializer for class
}

void TokenTree::setTokenClass(int tc) {
    this->tokenClass = tc;
}

int TokenTree::getTokenClass() {
    return this->tokenClass;
}

void TokenTree::setLineNum(int line) {
    this->lineNum = line;
}

int TokenTree::getLineNum() {
    return this->lineNum;
}

void TokenTree::setTokenString(char *str) {
    this->tokenStr = strdup(str);
}

char *TokenTree::getTokenString() {
    return this->tokenStr;
}

void TokenTree::setCharValue(char c) {
    this->cvalue = c;
}

char TokenTree::getCharValue() {
    return this->cvalue;
}

void TokenTree::setNumValue(int n) {
    this->nvalue = n;
}

int TokenTree::getNumValue() {
    return this->nvalue;
}

void TokenTree::setStringValue(char *str) {
    setStringValue(str, true);
}

void TokenTree::setStringValue(char *str, bool duplicate) {
    if (duplicate) {
        this->svalue = strdup(str);
    } else {
        this->svalue = str;
    }
}

char *TokenTree::getStringValue() {
    return this->svalue;
}

void TokenTree::setParentAndFunction() 
{
    _setParent();
    _setFunction();
}

void TokenTree::_setParent() 
{
    for (int i = 0; i < MAX_CHILDREN; i++)
    {
        TokenTree *child = children[i];
        if (child != NULL) 
        {
            child->parent = this; //takes each child and sets its parent as curent node
            child->_setParent(); // recursive to trravers to down to set child's child parent(it is ti child)
        }
    }

    if (this->sibling != NULL) //current called node bcoms all the siblings paraent
    {
        sibling->parent = parent;
        sibling->_setParent();//recursive to travrse throuh siblings
    }
}

//A calls then A->funtion = A if there is no parent for called node
//and all sibling node's function object is also sets A
//and all child node's function object is also sets A
//Current nodes function object is the key to identify its a function or not
void TokenTree::_setFunction() 
{
    TokenTree *topParent = getTopParent(); //getting Top Most Node by calling getTopParent()
    //top node's Decl kind is FUNC then it stred to "function" also an object of TOKTRE
    if (topParent->getDeclKind() == DeclKind::FUNCTION) 
    { 
        function = topParent;//Now function is the top most node //TokenTree *function = NULL;
    }

    for (int i = 0; i < MAX_CHILDREN; i++) //start traversing
    {
        TokenTree *child = children[i];
        if (child != NULL) //if there is a child for the current node then 
            child->_setFunction(); //recurcive call 
    }

    if (sibling != NULL)  
    {
        sibling->_setFunction();
    }
}

//Travers through the Tree and Returns the top Most Node
TokenTree *TokenTree::getTopParent() 
{
    TokenTree *visitor = this; //visitor initialize with argument node
    while (visitor->parent != NULL) 
    {
        visitor = visitor->parent; //Traversing -> moves to its parent
    }
    return visitor; //after While loop the Topmost node (visitor) Returns
}

//Retuns the number of sibling nodes. It may be any nmber of sibling
int TokenTree::getNumSiblings(bool includeSelf)
{
    int count = includeSelf ? 1 : 0; // current node is not NULL then count becomes 1 and returns 1
    TokenTree *visitor = this; //visitor initialize with argument node
    while (visitor->sibling != NULL)
    {
        visitor = visitor->sibling; //Traversing and increments the counts
        count++;
    }
    return count; //returns count includeing the argument node too
}

//Returns the child node count
int TokenTree::getNumChildren()// Max node count is 2
{
    int counter = 0;
    for (int i = 0; i < MAX_CHILDREN; i++)// Traverse and checks for child Node     
    {
        if (children[i] != NULL) 
            counter++;
    }
    return counter; //returns th count of child nodes of the argument Node
}

//Checks there is any parent n ode for the argument Node
bool TokenTree::hasParent(TokenTree *possibleParent, bool checkAllParents)
{
    //printf("ARgument Node possibleParent  %s \n",possibleParent->getStringValue() );   
    if (possibleParent == NULL) //Argument node is empty then also returns False
        return false;

    TokenTree *visitor = this->parent; //takes current nodes Parent Nede
                                        //if no parent then While loop not wors and returns False
    //printf("visitor  %s \n",visitor->getStringValue() );    
    while (visitor != NULL) //if parent node is null then stops
    {
        if (visitor == possibleParent)  //argument Node reached then returns TRUE
            return true;                //ie. The nade have a Parent
                                        // it continues to the top most Node
        visitor = visitor->parent;//Traversing to parent node while reach the top
        //printf("in LOOP visitor  %s \n",visitor->getStringValue() );    
    }
    return false; //Returns there is no parent Node for the argument Node
}

//sets NodeKinds DECLARATION, EXPRESSION, STATEMENT
//this may unuse cose the kinds sets while kalling declaration kinds below
void TokenTree::setNodeKind(NodeKind nk) 
{
    this->nodeKind = nk;
}

//returns DECLARATION, EXPRESSION, STATEMENT 
NodeKind TokenTree::getNodeKind() 
{
    return this->nodeKind;
}

//First sets the NodeKind::DECLARATION
//Second sets the kinds FUNCTION, VARIABLE, PARAM
void TokenTree::setDeclKind(DeclKind dk) 
{
    this->nodeKind = NodeKind::DECLARATION;
    this->subKind.declKind = dk;
}

//only works inNodeKind::DECLARATION
//Returns the kinds FUNCTION, VARIABLE, PARAM
DeclKind TokenTree::getDeclKind() 
{
    // if (this->nodeKind != NodeKind::DECLARATION) {
    //     throw std::runtime_error("subKind is not NodeKind::DECLARATION!");
    // }
    return subKind.declKind;
}

//First sets the NodeKind::EXPRESSION
//Second sets the kinds CONSTANT, CALL, ID, UID, OP, ASSIGN
void TokenTree::setExprKind(ExprKind ek) 
{
    this->nodeKind = NodeKind::EXPRESSION;
    this->subKind.exprKind = ek;
}

//only works in NodeKind::EXPRESSION -> CONSTANT, CALL, ID, UID, OP, ASSIGN
//Returns INT, BOOL, CHAR, STRING, UNDEFINED
ExprKind TokenTree::getExprKind() 
{
    if (this->nodeKind != NodeKind::EXPRESSION) {
        throw std::runtime_error("subKind is not NodeKind::EXPRESSION!");
    }
    return subKind.exprKind;
}

//First sets the NodeKind::STATEMENT
//Second sets the kinds COMPOUND, SELECTION, FOR, WHILE, RANGE, RETURN, BREAK
void TokenTree::setStmtKind(StmtKind sk) 
{
    this->nodeKind = NodeKind::STATEMENT;
    this->subKind.stmtKind = sk;
}

//retuns the NodeKind if it is a STATEMENT
//only Works in COMPOUND, SELECTION, FOR, WHILE, RANGE, RETURN, BREAK kinds
StmtKind TokenTree::getStmtKind() {
    if (this->nodeKind != NodeKind::STATEMENT) {
        throw std::runtime_error("subKind is not NodeKind::STATEMENT!");
    }
    return subKind.stmtKind;
}
//Sets the Exp::Type { INT, BOOL, CHAR, STRING, UNDEFINED }
void TokenTree::setExprType(ExprType et) {
    this->exprType = et;
}

//retuns EXP::TYPE { INT, BOOL, CHAR, STRING, UNDEFINED }
ExprType TokenTree::getExprType() {
    return this->exprType;
}
//Exp::tpe name as a string used to print
//retuns EXP::TYPE { INT, BOOL, CHAR, STRING, UNDEFINED }
const char *TokenTree::getTypeString() 
{
    switch (getExprType()) {
        case ExprType::BOOL:
            return "type bool";
        case ExprType::CHAR:
            return "type char";
        case ExprType::INT:
            return "type int";
        case ExprType::VOID:
            return "type void";
        case ExprType::STRING:
            return "type string";    
        case ExprType::UNDEFINED:
            return "undefined type";
    }
    return "error";
}

//returns ture if an Exprssion's Exp:type is ExprType::UNDEFINED
bool TokenTree::isExprTypeUndefined() {
    return exprType == ExprType::UNDEFINED;
}

//returs True if all child are not ExprType::UNDEFINED
//if any child is UNDEFIND then retuns false
bool TokenTree::checkCascade() {
    bool b = true;
    for (int i = 0; i < MAX_CHILDREN; i++) {
        TokenTree *child = children[i];
        if (child != NULL && child->isExprTypeUndefined()) {
            b = false;
        }
    }
    return b;
}

//sets the Expession name (The parameter becomes the Exp::name)
//char *exprName; this is the variable
void TokenTree::setExprName(char *name) {
    this->exprName = strdup(name);
}

//returns the expession name(it may anythis previus fun: sets)
char *TokenTree::getExprName() {
    return this->exprName;
}

///sets current node ia an ARRAY if parameter is TRUE
void TokenTree::setIsArray(bool b) {
    this->_isArray = b;
}

bool TokenTree::isArray() {
    return this->_isArray;
}

//sets current node STATIC if parameter is TRUE
void TokenTree::setIsStatic(bool b) {
    this->_isStatic = b;
}

bool TokenTree::isStatic() {
    return this->_isStatic;
}

//IF  parameter false  unInitialize current node Only
//if parameter true then Current Node and ALL CHILD unInitialized
void TokenTree::cancelCheckInit(bool applyToChildren) 
{
    this->checkInitialized = false;
    if (applyToChildren) 
    {
        for (int i = 0; i < MAX_CHILDREN; i++) 
        {
            TokenTree *child = children[i];
            if (child != NULL) 
                child->cancelCheckInit(applyToChildren);
        }
    }
}

//Returs TRUE if it is not static and is Initialized
bool TokenTree::shouldCheckInit() //Returns Initilization Status
{
    return !_isStatic && this->checkInitialized;
}

//ONLY works in DECLARATION  NOT in EXPRESSION, STATEMENT
//checks DECLARATION of UNCTION, VARIABLE, PARAM
void TokenTree::setIsUsed(bool b) 
{
    
    // if (this->getNodeKind() != NodeKind::DECLARATION) {
    //     throw std::runtime_error("Cannot set isUsed on node that is not a DECLARATION kind .");
    // }

    _isUsed = b;
}

//depends void TokenTree::setIsUsed(bool b)  Method above
//retuns _isUsed
bool TokenTree::isUsed() {
    return _isUsed;
}

//Only Works in DECLARATION Declaration Kind NOT in EXPRESSION, STATEMENT
//Only works in VARIABLE, PARAM NodeKind NOT in FUNCTION 
// and it sets TRUE in _isInitialized if the argument is true
//cheks DECLARATION of VARIABLE, PARAM 
void TokenTree::setIsInitialized(bool b) 
{
    if (this->getNodeKind() != NodeKind::DECLARATION) {
        throw std::runtime_error("Cannot set isInitialized on node that is not DECLARATION kind .");
    }
    if (this->getDeclKind() == DeclKind::FUNCTION) {
        throw std::runtime_error("Cannot set isInitialized on node that is a FUNCTION kind.");
    }
    _isInitialized = b;
}
//depends void TokenTree::setIsInitialized(bool b)  Method above
//return _isInitialized variable (True or False)
bool TokenTree::isInitialized() 
{
    return _isInitialized;
}

void TokenTree::setHasReturn(bool b) {
    if (this->getNodeKind() != NodeKind::DECLARATION || this->getDeclKind() != DeclKind::FUNCTION) {
        throw std::runtime_error("Can only set 'hasReturn' on function declaration.");
    }
    _hasReturn = b;
}

bool TokenTree::hasReturn() {
    
    if (this->getNodeKind() != NodeKind::DECLARATION || this->getDeclKind() != DeclKind::FUNCTION) {
        throw std::runtime_error("Value of 'hasReturn' is only valid on function declaration.");
    }
    return _hasReturn;
}

//It returns tru if it is a CONSTANT exp kind
//else it checks EP kind ID CALL ASSIGN the returns false
//else it checks all the child nodes and checks any one is not aconstant
//if find any child isnot constant then return flase
//all child (if exists) are const then returns true 
bool TokenTree::isConstantExpression() 
{
    if (this->getNodeKind() != NodeKind::EXPRESSION) {
        throw std::runtime_error("Cannot only call 'isConstantExpression' on an expression.");
    }
    if (this->getExprKind() == ExprKind::CONSTANT) {
        return true;
    }
    
    else if (this->getExprKind() == ExprKind::ID || this->getExprKind() == ExprKind::CALL || this->getExprKind() == ExprKind::ASSIGN)
    {
        return false;
    } 

    else // ExprKind::OP
    { 
        bool allChildrenAreConst = true;
        for (int i = 0; i < MAX_CHILDREN; i++) 
        {
            TokenTree *child = this->children[i];

// if (this != NULL) 
// printf("[ Line %d ] THIS %s  \n",this->getLineNum(),this->getTokenString());  

if(strcmp(this->getTokenString(),"?")==0)
{
    allChildrenAreConst = false;
    break;
}

            if (child != NULL && !child->isConstantExpression()) 
            {
                //printf("[ Line %d ] CHILD %s  \n",child->getLineNum(),child->getTokenString());  
                allChildrenAreConst = false;
                break;
            }
        }
        return allChildrenAreConst;
    }    
}

void TokenTree::addSibling(TokenTree *sibl) {
    if (sibl == NULL) return;
    TokenTree *visitor = this;
    while (visitor->sibling != NULL) {
        visitor = visitor->sibling;
    }
    visitor->sibling = sibl;
}

void TokenTree::typeSiblings(ExprType type) 
{
    TokenTree *node = this;
    while (node != NULL) {
        node->setExprType(type);
        node = node->sibling;
    }
}

void TokenTree::staticSiblings() 
{
    TokenTree *node = this;
    while (node != NULL) {
        node->setIsStatic(true);
        node = node->sibling;
    }
}


void TokenTree::printTree(bool printWithoutType) //It called in main 
{
    this->_printTree(0, false, false, 0, printWithoutType);//cals _printTree()
}

//For first call level=0 num=0 and ischild False issibling false
void TokenTree::_printTree(int level, bool isChild, bool isSibling, int num, bool printWithoutType) 
{
    // Prints the dots. Fisrst level =0, so no .
    for (int i = 0; i < level; i++) 
    {
        printf(".   ");
    }
    if (isChild || isSibling) //first both false so not printing
    {
        if (isChild) {
            printf("Child: ");
        } else {
            printf("Sibling: ");
        }
        printf("%d  ", num);
    }
    if(printWithoutType)
        printNode();  //calles printNode(), 
    else
    {
        printNodeWithoutType();
    }
 
    // Print children
    for (int i = 0; i < MAX_CHILDREN; i++) //if in root node object MAX_CHILDREN>0 then have childs
    {

        TokenTree *child = children[i]; //accessing child nodes and recurcive call invokes to print . and "child"
        if (child != NULL) 
        {
            child->_printTree(level + 1, true, false, i, printWithoutType );// recur Call and comes from top and prints ". child"
        }
    }

    // Print sibling
    if (sibling != NULL) 
    {
        if (isChild) 
        {
            sibling->_printTree(level, false, true, 1, printWithoutType); //child inside sibling prints
        } else 
        {
            sibling->_printTree(level, false, true, num + 1, printWithoutType); //prints ". sibling"
        }
    }
}

void TokenTree::printNode() 
{    
    switch (nodeKind) {
        case NodeKind::DECLARATION:
            switch (getDeclKind()) {
                case DeclKind::VARIABLE:
                    printf("Var: %s ", getStringValue());  
                    // if (isStatic()) 
                    //     printf("static ");
                    if (isArray()) 
                        printf("is array ");    
                    printf("of %s ", getTypeString());   
                    break;
                case DeclKind::FUNCTION:
                    printf("Func: %s returns %s ", getStringValue(), getTypeString());
                    break;
                case DeclKind::PARAM:                    
                    if (isArray()){
                         printf("Parm: %s is ", getStringValue());
                         printf("array of ");
                         printf("%s ", getTypeString());
                    }
                    else{
                        printf("Parm: %s of ", getStringValue());
                        printf("%s ", getTypeString());
                    }
                default:
                    break;
            }
            break;
        case NodeKind::EXPRESSION:
            switch (getExprKind()) {
                case ExprKind::ASSIGN: 
                {
                    char *arrayStr = (char *) "";
                    if (isArray()) arrayStr = (char *) "array of ";
                    printf("Assign: %s of %s%s ", getTokenString(), arrayStr, getTypeString());
                    break;
                }
                case ExprKind::CALL:
                    printf("Call: %s of %s ", getExprName(), getTypeString());
                    break;

                case ExprKind::CONSTANT: {   
                    printf("Const");
                    if (getExprType() == ExprType::CHAR) {
                        if (isArray()) {
                            printf(" is array ");
                            printf("\"%s\" of %s ", getStringValue(),getTypeString());
                        } else {
                            printf(" \'%c\'  of %s ",getCharValue() ,getTypeString());
                        }                        
                    } 
                    else if((getExprType() == ExprType::INT))  
                    {
                        printf(" %d of %s ", getNumValue(),getTypeString());
                    }
                    else if (getExprType() == ExprType::BOOL)//ExprType::BOOL
                    {
                        printf(" %s of %s ", getStringValue(),getTypeString());
                    }
                    break;
                }
                case ExprKind::ID: {
                    char *staticStr = (char *) "";
                    char *arrayStr = (char *) "";
                    if (isStatic()) 
                        //staticStr = (char *) "static ";
                        staticStr = (char *) "";
                    if (isArray()) 
                       //arrayStr = (char *) "array of ";
                        arrayStr = (char *) "";
                    printf("Id: %s of %s%s%s ", getStringValue(), staticStr, arrayStr, getTypeString());
                    break;
                }
                case ExprKind::OP:
                    if(getNumChildren()==1 && strcmp(getTokenString(), "-")==0)
                        printf("Op: chsign of %s ", getTypeString());  
                    else if(getNumChildren()==1 && strcmp(getTokenString(), "*")==0)
                        printf("Op: sizeof of %s ", getTypeString());  
                    else if(getNumChildren()==1 && strcmp(getTokenString(), "not")==0)
                        printf("Op: not of %s ", getTypeString());
                    else                   
                        printf("Op: %s of %s ", getTokenString(),getTypeString()); 
                    break;
                default:
                 printf(" NULL"); 
                    break;
            }
            break;
        case NodeKind::STATEMENT:
            switch (getStmtKind()) {
                case StmtKind::BREAK:
                    printf("Break ");
                    break;
                case StmtKind::COMPOUND:
                    printf("Compound ");
                    break;
                case StmtKind::FOR:
                    printf("For ");
                    break;
                case StmtKind::WHILE:
                    printf("While ");
                    break;
                case StmtKind::RETURN:
                    printf("Return ");
                    break;
                case StmtKind::SELECTION:
                    printf("If ");
                    break;
                case StmtKind::RANGE:
                    printf("Range ");
                    break;    
            }
            break;
        default:
            break;
    }
    printLine();
    printf("\n");
}

void TokenTree::printLine() //printng the linenumber at the end 
{
    printf("[line: %d]", getLineNum());
}

void TokenTree::printNodeWithoutType() 
{    
    switch (nodeKind) {
        case NodeKind::DECLARATION:
            switch (getDeclKind()) {
                case DeclKind::VARIABLE:
                    printf("Var: %s ", getStringValue()); 
                    break;
                case DeclKind::FUNCTION:
                    printf("Func: %s returns %s ", getStringValue(), getTypeString());
                    break;
                case DeclKind::PARAM:
                      printf("Parm: %s is ", getStringValue());
                      break;                   
                default:
                    break;
            }
            break;
        case NodeKind::EXPRESSION:
            switch (getExprKind()) {
                case ExprKind::ASSIGN: 
                    printf("Assign: %s ", getTokenString());
                    break;
                case ExprKind::CALL:
                    printf("Call: %s ", getExprName());
                    break;
                case ExprKind::CONSTANT:
                    printf("Const");
                    if (getExprType() == ExprType::CHAR)
                        printf(" \'%c\'",getCharValue());
                    else if((getExprType() == ExprType::INT))
                        printf(" %d ", getNumValue());
                    else if (getExprType() == ExprType::BOOL)
                        printf(" %s ", getStringValue());
                    break;
                case ExprKind::ID:
                    printf("Id: %s ", getStringValue());
                    break;
                case ExprKind::OP:
                    printf("Op: %s", getTokenString()); 
                    break;
                case ExprKind::UID:
                    if(strcmp(getStringValue(), "-")==0)
                        printf("Op: chsign "); 
                    else if(strcmp(getStringValue(), "*")==0)
                        printf("Op: sizeof "); 
                    else if(strcmp(getStringValue(), "?")==0)
                        printf("Op: ? ");  
                    else if(strcmp(getStringValue(), "!")==0)
                        printf("Op: not "); 
                    break;    
                default:
                 printf(" NULL"); 
                    break;
            }
            break;
        case NodeKind::STATEMENT:
            switch (getStmtKind()) {
                case StmtKind::BREAK: printf("Break "); break;
                case StmtKind::COMPOUND:printf("Compound ");break;
                case StmtKind::FOR:printf("For ");break;
                case StmtKind::WHILE:printf("While ");break;
                case StmtKind::RETURN:printf("Return ");break;
                case StmtKind::SELECTION:printf("If ");break;
                case StmtKind::RANGE:printf("Range ");break;    
            }
            break;
        default:
            break;
    }
    printLine();
    printf("\n");
}