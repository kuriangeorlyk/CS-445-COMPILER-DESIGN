#include <string.h>
#include <stdio.h>
#include <stdlib.h>
#include <map>
#include <string>
#include "yyerror.h"

static int split(char *s, char *strs[], char breakchar)
{
    int num;
    
    strs[0] = s;
    num = 1;
    for (char *p = s; *p; p++) {
        if (*p==breakchar) {
            strs[num++] = p+1;
            *p = '\0';
        }
    }
    strs[num] = NULL;
    
    return num;
}


// trim off the last character
static void trim(char *s)
{
    s[strlen(s)-1] = '\0';
}

static std::map<std::string , char *> niceTokenNameMap;    // use an ordered map (not as fast as unordered)

void initErrorProcessing() {

    niceTokenNameMap["ADDASS"] = (char *)"\"+=\"";
    niceTokenNameMap["BOOL"] = (char *)"\"bool\"";
    niceTokenNameMap["BOOLCONST"] = (char *)"Boolean constant";
    niceTokenNameMap["BREAK"] = (char *)"\"break\"";
    niceTokenNameMap["CHAR"] = (char *)"\"char\"";
    niceTokenNameMap["CHARCONST"] = (char *)"character constant";
    niceTokenNameMap["CHSIGN"] = (char *)"-";
    niceTokenNameMap["DEC"] = (char *)"\"--\"";
    niceTokenNameMap["DIVASS"] = (char *)"\"/=\"";
    niceTokenNameMap["ELSE"] = (char *)"\"else\"";
    niceTokenNameMap["EQ"] = (char *)"\"==\"";
    niceTokenNameMap["FOR"] = (char *)"\"forever\"";
    niceTokenNameMap["GEQ"] = (char *)"\">=\"";
    niceTokenNameMap["ID"] = (char *)"identifier";
    niceTokenNameMap["IF"] = (char *)"\"if\"";
    niceTokenNameMap["IN"] = (char *)"\"in\"";
    niceTokenNameMap["INC"] = (char *)"\"++\"";
    niceTokenNameMap["INT"] = (char *)"\"int\"";
    niceTokenNameMap["LEQ"] = (char *)"\"<=\"";
    niceTokenNameMap["MULASS"] = (char *)"\"*=\"";
    niceTokenNameMap["NEQ"] = (char *)"\"!=\"";
    niceTokenNameMap["NUMCONST"] = (char *)"numeric constant";
    niceTokenNameMap["OR"] = (char *)"\"or\"";
    niceTokenNameMap["RETURN"] = (char *)"\"return\"";
    niceTokenNameMap["SIZEOF"] = (char *)"\"*\"";
    niceTokenNameMap["STATIC"] = (char *)"\"static\"";
    niceTokenNameMap["STRINGCONST"] = (char *)"string constant";
    niceTokenNameMap["SUBASS"] = (char *)"\"-=\"";
    niceTokenNameMap["WHILE"] = (char *)"\"while\"";
    niceTokenNameMap["$end"] = (char *)"end of input";
}

static char *niceTokenStr(char *tokenName ) {
    if (tokenName[0] == '\'') return tokenName;
    if (niceTokenNameMap.find(tokenName) == niceTokenNameMap.end()) {
        printf("ERROR(SYSTEM): niceTokenStr fails to find string '%s'\n", tokenName); 
        fflush(stdout);
        exit(1);
    }
    return niceTokenNameMap[tokenName];
}

static bool elaborate(char *s)
{
    return (strstr(s, "constant") || strstr(s, "identifier"));
}



static void tinySort(char *base[], int num, int step, bool up)
{
    for (int i=step; i<num; i+=step) {
        for (int j=0; j<i; j+=step) {
            if (up ^ (strcmp(base[i], base[j])>0)) {
                char *tmp;
                tmp = base[i]; base[i] = base[j]; base[j] = tmp;
            }
        }
    }
}

  
void yyerror(const char *msg)
{
    char *space;
    char *strs[100];
    int numstrs;

    // make a copy of msg string
    space = strdup(msg);

    // split out components
    numstrs = split(space, strs, ' ');
    if (numstrs>4) trim(strs[3]);

    // translate components
    for (int i=3; i<numstrs; i+=2) {
        strs[i] = niceTokenStr(strs[i]);
    }

    // print components
   // printf("ERROR(ARGLIST): source file \"%s\" \"%s\"could not be opened.",strs[1],msg);
    //printf("ERROR(%d): Syntax error, unexpected %s", lineNum, strs[3]);
    if (elaborate(strs[3])) {
        if (lastToken[0]=='\'' || lastToken[0]=='"') printf(" %s", lastToken); 
        else printf(" \"%s\"", lastToken);
    }

    if (numstrs>4) printf(",");

    // print sorted list of expected
    tinySort(strs+5, numstrs-5, 2, true); 
    for (int i=4; i<numstrs; i++) {
        printf(" %s", strs[i]);
    }
    printf(".\n");
    fflush(stdout);   // force a dump of the error

    numErrors++;

    free(space);
}