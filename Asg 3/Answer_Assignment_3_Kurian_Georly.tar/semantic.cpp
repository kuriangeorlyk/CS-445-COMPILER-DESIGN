//printf("handleComparison [ Line %d ] TREE %s        LHS %s  %s (%d)        RHS %s %s (%d).\n",tree->getLineNum(),tree->getTokenString(),     lhs->getTokenString(),lhs->getTypeString(),lhs->isArray(),     rhs->getTokenString(),rhs->getTypeString(),rhs->isArray());    
//printf("IsInitialized [ %d ] \n", lhs->isInitialized() );   
#include "string.h"
#include "symbolTable.h"
#include "semantic.h"
#include "TokenTree.h"

#define NUM_OPS 17

extern int numErrors;
extern int numWarnings;
extern int localOffset;
extern int globalOffset;
extern TokenTree *syntaxTree;
extern SymbolTable *symbolTable;

void err(TokenTree *node) //PRinting ERRORS
{
    printf("ERROR(%d): ", node->getLineNum());
    numErrors++;
}

void warn(TokenTree *node) //Printing WARNING
{
    printf("WARNING(%d): ", node->getLineNum());
    numWarnings++;
}

bool sameType(TokenTree *lhs, TokenTree *rhs) //checks LHS and RHS are EQUAL
{
    return lhs->getExprType() == rhs->getExprType();//return True if same
}

//Checks Both Child are Boolean and if any child is an array and produce error..
void handleBooleanComparison(TokenTree *tree)
{
    tree->setExprType(ExprType::BOOL);
    TokenTree *lhs = tree->children[0];
    TokenTree *rhs = tree->children[1];
    if (!lhs->isExprTypeUndefined() && lhs->getExprType() != ExprType::BOOL)
    {
        err(tree);
        printf("'%s' requires operands of %s but lhs is of %s.\n", tree->getTokenString(), tree->getTypeString(), lhs->getTypeString());
    }
    if (!rhs->isExprTypeUndefined() && rhs->getExprType() != ExprType::BOOL) 
    {
        err(tree);
        printf("'%s' requires operands of %s but rhs is of %s.\n", tree->getTokenString(), tree->getTypeString(), rhs->getTypeString());
    }    
    if (lhs->isArray() || rhs->isArray()) 
    {
        err(tree);
        printf("The operation '%s' does not work with arrays.\n", tree->getTokenString());
    }
}

void handleNot(TokenTree *tree)
{
    tree->setExprType(ExprType::BOOL);
    TokenTree *lhs = tree->children[0];
    if (tree->checkCascade() && lhs->getExprType() != ExprType::BOOL) 
    {
        err(tree);
        printf("Unary '%s' requires an operand of %s but was given %s.\n", tree->getTokenString(), tree->getTypeString(), lhs->getTypeString());
    
    }
    if (lhs->isArray()) 
    {
            err(tree);
            printf("The operation '%s' does not work with arrays.\n", tree->getTokenString());           
    }
}
//checks Both side are int Type
void handleMath(TokenTree *tree) 
{
    tree->setExprType(ExprType::INT);
    TokenTree *lhs = tree->children[0];
    TokenTree *rhs = tree->children[1];
    //printf(">>>>>>>TREE %s  %s",    tree->getTokenString(),rhs->getTypeString());  

    if (!lhs->isExprTypeUndefined() && lhs->getExprType() != ExprType::INT) 
    {
        err(tree);
        printf("'%s' requires operands of %s but lhs is of %s.\n", tree->getTokenString(), tree->getTypeString(), lhs->getTypeString());
    }
    if (!rhs->isExprTypeUndefined() && rhs->getExprType() != ExprType::INT) 
    {
        err(tree);
        printf("'%s' requires operands of %s but rhs is of %s.\n", tree->getTokenString(), tree->getTypeString(), rhs->getTypeString());
    }
    if (lhs->isArray() || rhs->isArray()) 
    {
        err(tree);
        printf("The operation '%s' does not work with arrays.\n", tree->getTokenString());
    }
}
//Checks Unary   
void handleChSignOrMath(TokenTree *tree) 
{
    if (tree->children[1] != NULL) 
    {
        handleMath(tree); //Check both side are int or Not
    } 
    else 
    {
        tree->setExprType(ExprType::INT);
        TokenTree *lhs = tree->children[0];
        if (tree->checkCascade() && lhs->getExprType() != ExprType::INT) 
        {
            err(tree);
            printf("Unary '%s' requires an operand of %s but was given %s.\n", tree->getStringValue(), tree->getTypeString(), lhs->getTypeString());
        }
        if (lhs->isArray()) {
            err(tree);
            printf("The operation '%s' does not work with arrays.\n", tree->getStringValue());
        }
    }
}
//Checks Unary *
void handleSizeOfOrMath(TokenTree *tree) 
{
   // printf("[ Line %d ] TREE %s        LHS %s  %s (%d)        RHS %s %s (%d).\n",tree->getLineNum(),tree->getTokenString(),     lhs->getTokenString(),lhs->getTypeString(),lhs->isArray(),     rhs->getTokenString(),rhs->getTypeString(),rhs->isArray());    
           
    if (tree->children[1] != NULL) 
    {
        handleMath(tree);
    } 
    else 
    { // Unary Deref
        TokenTree *lhs = tree->children[0];
        tree->setExprType(ExprType::INT);
        if (tree->checkCascade()) {
            if (!lhs->isArray()) {
                err(tree);
                printf("The operation '%s' only works with arrays.\n", tree->getStringValue());
            }
        }
    }
}
//Checks Unary 
void handleUnaryInt(TokenTree *tree) {
    tree->setExprType(ExprType::INT);
    TokenTree *lhs = tree->children[0];
    if (lhs->getExprType() != ExprType::INT) {
        err(tree);
        printf("Unary '%s' requires an operand of %s but was given %s.\n", tree->getTokenString(), tree->getTypeString(), lhs->getTypeString());
    }
    if (lhs->isArray()) {
        err(tree);
        printf("The operation '%s' does not work with arrays.\n", tree->getStringValue());
    }
}
//DBT
void handleRandom(TokenTree *tree) {
    TokenTree *lhs = tree->children[0];
    tree->setExprType(lhs->getExprType());
    if (lhs->getExprType() != ExprType::INT) {
        err(tree);
        printf("Unary '%s' requires an operand of %s but was given %s.\n", tree->getTokenString(), "type int", lhs->getTypeString());
    }
    if (lhs->isArray()) {
        err(tree);
        printf("The operation '%s' does not work with arrays.\n", tree->getStringValue());
    }
}
void handleComparison(TokenTree *tree) //4630
 {
    tree->setExprType(ExprType::BOOL);
    TokenTree *lhs = tree->children[0];
    TokenTree *rhs = tree->children[1];

    if (tree->checkCascade()) 
    {
        if (!sameType(lhs, rhs)) 
        { 
              //if(lhs->getExprKind()!=ExprKind::OP)//PLEASE CHECK LATER================================= CHECK LATER =================================
            if(strcmp(lhs->getTokenString(),"<=")!=0)//PLEASE CHECK LATER================================= CHECK LATER =================================
            //printf("handleComparison [ Line %d ] TREE %s        LHS %s  %s (%d)        RHS %s %s (%d).\n",tree->getLineNum(),tree->getTokenString(),     lhs->getTokenString(),lhs->getTypeString(),lhs->isArray(),     rhs->getTokenString(),rhs->getTypeString(),rhs->isArray());    
           
            {
                err(tree);
                printf("'%s' requires operands of the same type but lhs is %s and rhs is %s.\n", tree->getTokenString(), lhs->getTypeString(), rhs->getTypeString());
            }
        }
    }
    if (lhs->isArray() ^ rhs->isArray()) {
        char *lhsStr = (char*) "";
        char *rhsStr = (char*) "";
        if (!lhs->isArray())
            lhsStr = (char*) " not";
        if (!rhs->isArray()) 
            rhsStr = (char*) " not";
        err(tree);
        printf("'%s' requires both operands be arrays or not but lhs is%s an array and rhs is%s an array.\n", tree->getTokenString(), lhsStr, rhsStr);
    }
}
void handleArrayAccess(TokenTree *tree) 
{
    TokenTree *array = tree->children[0];
    tree->setExprType(array->getExprType());
    TokenTree *index = tree->children[1];
    if (array == NULL) 
    {
        err(tree);
        printf("Cannot index nonarray.\n");
        return;
    }
    if (!array->isArray()) 
    {
        err(tree);
        printf("Cannot index nonarray '%s'.\n", array->getStringValue());
    }
    if (!index->isExprTypeUndefined() && index->getExprType() != ExprType::INT) 
    {
        err(tree);
        printf("Array '%s' should be indexed by type int but got %s.\n", array->getStringValue(), index->getTypeString());
    }
    if (index->isArray())
    {
        err(tree);
        printf("Array index is the unindexed array '%s'.\n", index->getStringValue());
    }
}

const char *operations[NUM_OPS] = {
    //"<=",
    "<",
    ">=",
    ">",

    "and",
    "or",   

    "not",
    "+",
    "-",
    "*",

    "/",
    "%",

    "?",
    "=",
    "!=",
    "!>",
    "!<",

    "["
    
    
        
};

void (*functionPointers[NUM_OPS])(TokenTree *) = {
    //handleComparison, // LEQ
    handleComparison, // LESS THAN
    handleComparison, // GEQ
    handleComparison, // GREATHER THAN

    handleBooleanComparison, // AND
    handleBooleanComparison, // OR

    handleNot, // NOT
    handleMath, // PLUS
    handleChSignOrMath, // CHANGE SIGN OR MINUS
    handleSizeOfOrMath, // SIZEOF OR TIMES

    handleMath, // DIVISION
    handleMath, // MOD
    // handleUnaryInt, // INC
    // handleUnaryInt, // DEC

    handleRandom, // RANDOM ?

    handleComparison, // EQUALS
    handleComparison, // NOT EQUALS
    handleComparison, // NOT GREATERTHAN
    handleComparison, // NOT LEESTHAN
    handleArrayAccess, // ARRAY ACCESSOR []
};
//DBT
int indexOfOperation(TokenTree *tree) 
{
    for (int i = 0; i < NUM_OPS; i++) 
    {
        if (strcmp(tree->getTokenString(), operations[i]) == 0) 
        {
            return i;
        }
    }
    return -1;
}

bool compoundShouldEnterScope(TokenTree *parent) 
{
    if (parent == NULL) 
    {
        return true;
    }
    if (parent->getNodeKind() == NodeKind::DECLARATION && parent->getDeclKind() == DeclKind::FUNCTION)
    {
        return false;
    }
    if (parent->getNodeKind() == NodeKind::STATEMENT && parent->getStmtKind() == StmtKind::FOR) 
    {
        return false;
    }
    return true;
}

void beforeChildren(TokenTree *tree, bool *enteredScope, int &previousLocalOffset) 
{
    if (tree->parent != NULL && tree->parent->getNodeKind() == NodeKind::EXPRESSION && tree->parent->getExprKind() == ExprKind::CALL) 
    {
        TokenTree *res = (TokenTree *) symbolTable->lookup(tree->parent->getStringValue());
        if (res != NULL) 
        {
            int counter = 1;
            TokenTree *param = res->children[0];
            TokenTree *input = tree->parent->children[0]; 
            while (input != tree && param != NULL) { 
                param = param->sibling; 
                input = input->sibling;
                counter++;
            }           
        }
    }

    switch (tree->getNodeKind()) 
    {
        case NodeKind::DECLARATION: 
        {
            if (tree->getDeclKind() != DeclKind::VARIABLE) //If FUNCTION, PARAMM 
             {                
                bool defined = !symbolTable->insert(tree->getStringValue(), tree);
                if (tree->getDeclKind() == DeclKind::FUNCTION) 
                {
                    symbolTable->enter("Function: " + std::string(tree->getStringValue()));
                    *enteredScope = true;
                    localOffset = -2;
                }
                else //PARAMM
                {   
                    tree->setIsInitialized(true); 
                }
                if (defined) 
                {    
                    //tree->ec=1;                
                    TokenTree *res = (TokenTree *) symbolTable->lookup(tree->getStringValue());
                    res->ec=1;
                    err(tree);
                    printf("Symbol '%s' is already declared at line %d.\n", res->getStringValue(), res->getLineNum());
                    
                }
            }
            else // If DeclKind::VARIABLE then
            {                
                if (tree->parent == NULL) {                   
                } else if (tree->isStatic()) {                   
                } else {                    
                }
                if (tree->children[0] != NULL) {
                    tree->setIsInitialized(true);
                }
            }            
            break;
        }
        case NodeKind::EXPRESSION: {           
            switch (tree->getExprKind()) 
            {
                case ExprKind::ASSIGN: 
                {
                    
                    break;
                }
                case ExprKind::CALL: 
                {
                    TokenTree *res = (TokenTree *) symbolTable->lookup(tree->getStringValue());     
                    if (res == NULL) 
                    {
                        err(tree);
                        printf("Symbol '%s' is not declared.\n", tree->getStringValue());
                    }                  
                    else 
                    {
                        tree->setExprType(res->getExprType()); 
                        if (res->getDeclKind() != DeclKind::FUNCTION) 
                        {
                            err(tree);
                            printf("'%s' is a simple variable and cannot be called.\n", tree->getStringValue());
                            tree->setExprType(ExprType::UNDEFINED);
                        }
                    }
                    break;
                }
                case ExprKind::CONSTANT: 
                {
                    if (tree->isArray()) 
                    {

                    }
                    break;
                }
                case ExprKind::ID: 
                {
                    TokenTree *res = (TokenTree *) symbolTable->lookup(tree->getStringValue());
                     if (res == NULL || (res->getDeclKind() == DeclKind::VARIABLE && tree->hasParent(res, true))) 
                    {
                        if(tree->getExprType()!=ExprType::INT )
                        {  
                            //printf("PARENT '%s' \n", tree->parent->getStringValue());
                            if(strcmp(tree->parent->getStringValue(),"..")!=0)//2024
                            {
                            err(tree);
                            printf("Symbol '%s' is not declared.\n", tree->getStringValue());//2024
                            }
                        }
                    } 
                    else if (res->getDeclKind() != DeclKind::FUNCTION) 
                    {
                        //printf("VAL '%s' \n", tree->getStringValue());
                        // printf("PARENT '%s' \n", tree->parent->getStringValue());
                        res->setIsUsed(true);  

                        if(strcmp(tree->parent->getStringValue(),"..")==0)
                        {
                            //if(res->getExprKind()!=ExprKind::CONSTANT)
                            {
                                    res->setIsUsed(false);  
                            }   
                        }

                        if(strcmp(tree->parent->getStringValue(),"..")==0)
                        if(strcmp(tree->getStringValue(),"values")==0)
                        if(res->isArray())
                        {
                            res->setIsUsed(true);  
                        }

    
                        //printf("RES>>>>>>>> '%s'     %d    \n", res->getStringValue() , res->isArray());
                        tree->setExprType(res->getExprType());
                        tree->setIsArray(res->isArray());
                        tree->setIsStatic(res->isStatic());    
                        if (tree->shouldCheckInit() && res->shouldCheckInit() && !res->isInitialized() && res->parent != NULL  )  
                        {
                            if(strcmp(tree->parent->getStringValue(),"..")!=0)//2024
                            {
                            warn(tree);                                            
                            printf("Variable '%s' may be uninitialized when used here.\n", tree->getStringValue());
                            res->cancelCheckInit(false);
                            }
                        }
                    }          
                    else 
                    {
                        tree->setExprType(ExprType::INT);
                        err(tree);
                        printf("Cannot use function '%s' as a variable.\n", tree->getStringValue());                       
                        res->cancelCheckInit(true);
                    }
                    break;
                }
            }
            break;
        }
        case NodeKind::STATEMENT: 
        {
            switch (tree->getStmtKind()) {
                case StmtKind::COMPOUND: {
                    if (compoundShouldEnterScope(tree->parent)) {
                        *enteredScope = true;
                        symbolTable->enter("Compound Statement");
                        previousLocalOffset = localOffset;
                        break;
                    }
                    break;
                }
                case StmtKind::FOR: {
                    *enteredScope = true;
                    symbolTable->enter("For Statement");
                    previousLocalOffset = localOffset;
                    TokenTree *child = tree->children[0];
                    TokenTree *array = tree->children[1];
                    TokenTree *res = (TokenTree *) symbolTable->lookup(array->getStringValue());
                    if (res != NULL) {
                        child->setExprType(res->getExprType());
                    }
                    child->setIsInitialized(true);
                    break;
                }
                case StmtKind::BREAK: {
                    TokenTree *visitor = tree;
                    bool foundLoop = false;
                    while (visitor->parent != NULL) {
                        TokenTree *parent = visitor->parent;
                        if (parent->getNodeKind() == NodeKind::STATEMENT && (parent->getStmtKind() == StmtKind::WHILE || parent->getStmtKind() == StmtKind::FOR)) {
                            foundLoop = true;
                            break;
                        }
                        visitor = parent;
                    }                   
                    break;
                }
            }
            break;
        }
    }
}

void afterChild(TokenTree *tree, int childNo) 
{
    switch (tree->getNodeKind()) {
        case NodeKind::STATEMENT: {
            switch (tree->getStmtKind()) {
                case StmtKind::FOR: {
                    if (childNo == 1) {
                        TokenTree *array = tree->children[1];
                        TokenTree *res = (TokenTree *) symbolTable->lookup(array->getStringValue());
                        if (res != NULL) {
                            res->setIsInitialized(true);
                        }                        
                    }
                    break;
                }
                case StmtKind::SELECTION: {
                    if (childNo == 0) {
                        TokenTree *condition = tree->children[0];                        
                    }
                    break;
                }
                case StmtKind::WHILE: {
                    if (childNo == 0) {
                        TokenTree *condition = tree->children[0];                       
                    }
                    break;
                }
            }
            break;
        }
    }
}

void afterChildren(TokenTree *tree) 
{
    switch (tree->getNodeKind()) {
        case NodeKind::DECLARATION: {
            switch (tree->getDeclKind()) {
                case DeclKind::FUNCTION: {                    
                    break;
                }
                case DeclKind::VARIABLE: {//4630
                    bool defined = !symbolTable->insert(tree->getStringValue(), tree);                    
                    TokenTree *child = tree->children[0];                    
                    if (defined) {
                        TokenTree *res = (TokenTree *) symbolTable->lookup(tree->getStringValue());
                        err(tree);
                        printf("Symbol '%s' is already declared at line %d.\n", res->getStringValue(), res->getLineNum());
                    }                    
                    break;
                }
            }
            break;
        }
        case NodeKind::EXPRESSION: 
        {
            switch (tree->getExprKind()) 
            {
                case ExprKind::ASSIGN: 
                {
                    TokenTree *lhs = tree->children[0];
                    TokenTree *rhs = tree->children[1];
                    if (rhs == NULL) 
                    { // INC/DEC
                        tree->setExprType(ExprType::INT);
                        if (tree->checkCascade()) {
                            if (lhs->getExprType() != ExprType::INT) {
                                err(tree);
                                printf("Unary '%s' requires an operand of %s but was given %s.\n", tree->getTokenString(), tree->getTypeString(), lhs->getTypeString());
                            }
                        }                        
                        if (lhs->isArray()) {
                            err(tree);
                            printf("The operation '%s' does not work with arrays.\n", tree->getTokenString());
                        }
                    } 
                    else // ASSIGN,ADDASS,SUBASS,MULASS,DIVASS <=  Also
                    { 
                        bool isAssign = (strcmp(tree->getStringValue(), ":") == 0);                        
                        if (isAssign) //Only For :  
                        {
                            tree->setExprType(lhs->getExprType());
                            tree->setIsArray(lhs->isArray());
                            if (tree->checkCascade()) { // Prevent cascading errors
                                if (!sameType(lhs, rhs)) {
                                    err(tree);
                                    printf("33'%s' requires operands of the same type but lhs is %s and rhs is %s.\n", tree->getTokenString(), lhs->getTypeString(), rhs->getTypeString());
                                }
                            }
                            //Array Oparation in :  
                            if (lhs->isArray() ^ rhs->isArray()) {
                                char *lhsStr = (char*) "";
                                char *rhsStr = (char*) "";
                                if (!lhs->isArray()) lhsStr = (char*) " not";
                                if (!rhs->isArray()) rhsStr = (char*) " not";
                                err(tree);
                                printf("'%s' requires both operands be arrays or not but lhs is%s an array and rhs is%s an array.\n", tree->getTokenString(), lhsStr, rhsStr);
                            }
                        } 
                        else //4630
                        {
                          tree->setExprType(ExprType::INT);
                            //printf("[ Line %d ] TREE %s        LHS %s  %s (%d)        RHS %s %s (%d).\n",tree->getLineNum(),tree->getTokenString(),     lhs->getTokenString(),lhs->getTypeString(),lhs->isArray(),     rhs->getTokenString(),rhs->getTypeString(),rhs->isArray());    
                             if (lhs->isArray() ^ rhs->isArray()) 
                             {
                                char *lhsStr = (char*) "";
                                char *rhsStr = (char*) "";
                                if (!lhs->isArray()) lhsStr = (char*) " not";
                                if (!rhs->isArray()) rhsStr = (char*) " not";
                                err(tree);
                                printf("'%s' requires both operands be arrays or not but lhs is%s an array and rhs is%s an array.\n", tree->getTokenString(), lhsStr, rhsStr);
                            }
                            //------------------NEW-------------
                            //if (!rhs->isExprTypeUndefined() && rhs->getExprType() != ExprType::INT)
                            tree->setExprType(lhs->getExprType());
                            //printf("[ Line %d ] TREE %s        LHS %s  %s (%d)        RHS %s %s (%d).\n",tree->getLineNum(),tree->getTokenString(),     lhs->getTokenString(),lhs->getTypeString(),lhs->isArray(),     rhs->getTokenString(),rhs->getTypeString(),rhs->isArray());    
 
                            if ( !lhs->isExprTypeUndefined() && !rhs->isExprTypeUndefined() )//NEW added for DOnt check undefined kind var
                                if (lhs->getTypeString() != rhs->getTypeString())
                                {
                                    //printf("[ Line %d ] TREE %s        LHS %s  %s (%d)        RHS %s %s (%d).\n",tree->getLineNum(),tree->getTokenString(),     lhs->getTokenString(),lhs->getTypeString(),lhs->isArray(),     rhs->getTokenString(),rhs->getTypeString(),rhs->isArray());    
 
                                    if(strcmp(tree->getTokenString(),"+=")==0||strcmp(tree->getTokenString(),"-=")==0||strcmp(tree->getTokenString(),"*=")==0||strcmp(tree->getTokenString(),"/=")==0||strcmp(tree->getTokenString(),"%=")==0 )
                                    {
                                        err(tree);                                    
                                        printf("'%s' requires operands of %s but lhs is of %s.\n", tree->getTokenString(), rhs->getTypeString(),lhs->getTypeString());
                                    }
                                    else 
                                    //if(strcmp(tree->getTokenString(),"[" )==0) //Checks(relop) only This line adde to avoid only one error assign.c- NEW CHK
                                    {
                                        err(tree);
                                        printf("'%s' requires operands of the same type but lhs is %s and rhs is %s.\n", tree->getTokenString(), lhs->getTypeString(),rhs->getTypeString());
                                    }
                                }                          
                           
                        }
                        TokenTree *res;
                        if (lhs->getExprKind() == ExprKind::ID) {
                            res = (TokenTree *) symbolTable->lookup(lhs->getStringValue());
                        } else {
                            res = (TokenTree *) symbolTable->lookup(lhs->children[0]->getStringValue());
                        }
                        if (res == NULL || res->getDeclKind() == DeclKind::FUNCTION) break;
                        res->setIsInitialized(true);
                    }
                    break;
                }
                case ExprKind::CALL: {
                    TokenTree *res = (TokenTree *) symbolTable->lookupGlobal(tree->getStringValue());                 
                    
                    if (res != NULL) 
                    {
                        TokenTree *param = res->children[0];
                        TokenTree *input = tree->children[0];
                        int numParams, numInputs;
                        if (param == NULL) 
                            numParams = 0; 
                        else 
                            numParams = param->getNumSiblings(true);
                        if (input == NULL) 
                            numInputs = 0; 
                        else 
                            numInputs = input->getNumSiblings(true);                       
                        if(res->getLineNum()==-1)
                        {
                            err(tree);                            
                            printf("Symbol '%s' is not declared.\n", tree->getStringValue());
                        }                        
                    }
                    break;
                }
                
                case ExprKind::UID: //Handles UN - chsign UN + etc...
                {
                    void (*fp)(TokenTree *) = functionPointers[indexOfOperation(tree)];
                    fp(tree);
                    break;

                }
                case ExprKind::OP: {
                    // if(tree->getExprType()!=ExprType::BOOL);
                    // {
                    //     printf(">>>>.'%s' requires\n", tree->getTokenString());  
                    // }
                    // if(strcmp(tree->getTokenString(),"+")==0 || strcmp(tree->getTokenString(),"-")==0 ||strcmp(tree->getTokenString(),"*")==0 ||strcmp(tree->getTokenString(),"/")==0 || strcmp(tree->getTokenString(),"%")==0)
                    // {                
                    //     //printf(">>>>.'%s' requires\n", tree->getTokenString());  
                    //     tree->setExprType(ExprType::INT);
                    //     TokenTree *lhs = tree->children[0];
                    //     TokenTree *rhs = tree->children[1];
                    //     if (!lhs->isExprTypeUndefined() && lhs->getExprType() != ExprType::INT) 
                    //     {
                    //         err(tree);
                    //         printf("'%s' requires operands of %s but lhs is of %s.\n", tree->getTokenString(), tree->getTypeString(), lhs->getTypeString());
                    //     }
                    //     if (!rhs->isExprTypeUndefined() && rhs->getExprType() != ExprType::INT) 
                    //     {
                    //         err(tree);
                    //         printf("'%s' requires operands of %s but rhs is of %s.\n", tree->getTokenString(), tree->getTypeString(), rhs->getTypeString());
                    //     }
                    //     if (lhs->isArray() || rhs->isArray()) 
                    //     {
                    //         err(tree);
                    //         printf("The operation '%s' does not work with arrays.\n", tree->getTokenString());
                    //     }
                    // }


if(tree->getExprType()!=ExprType::BOOL);//4630
{
                    void (*fp)(TokenTree *) = functionPointers[indexOfOperation(tree)];
                    fp(tree);
}
                    break;
                }
                case ExprKind::ID: {                    
                    break;
                }
            }
            break;
        }
        case NodeKind::STATEMENT: {
            switch (tree->getStmtKind()) {
                case StmtKind::RETURN: {
                    tree->function->setHasReturn(true);
                    TokenTree *returnValue = tree->children[0];
                    bool returnNodeExists = returnValue != NULL;
                    bool expectingReturn = tree->function->getExprType() != ExprType::VOID;
                    if (returnNodeExists) {                        
                        if (returnValue->isArray()) {
                            err(tree);
                            printf("Cannot return an array.\n");
                        }
                    } 
                    break;
                }
            }
            break;
        }
    }
   
    if (tree->parent != NULL && tree->parent->getNodeKind() == NodeKind::EXPRESSION && tree->parent->getExprKind() == ExprKind::CALL)
    {
        TokenTree *res = (TokenTree *) symbolTable->lookup(tree->parent->getStringValue());
        if (res != NULL) {
            int counter = 1;
            TokenTree *param = res->children[0];
            TokenTree *input = tree->parent->children[0]; 
            while (input != tree && param != NULL) { 
                param = param->sibling; 
                input = input->sibling;
                counter++;
            }            
        }
    }
}

void checkUsage(std::string, void *node) 
{
    TokenTree *tree = (TokenTree *) node;
    NodeKind nk = tree->getNodeKind();
    if (nk == NodeKind::DECLARATION && tree->getDeclKind() != DeclKind::FUNCTION) //Which means only variables
    {
        //if (tree->getDeclKind() == DeclKind::VARIABLE||tree->getDeclKind() == DeclKind::PARAM && !tree->isInitialized()) 
        if (!tree->isUsed()) 
        {
             if (tree->ec==0)
             {               
                warn(tree);
                printf("The variable '%s' seems not to be used.\n", tree->getStringValue());
             }             
        }
    }
}

void buildSymbolTable(TokenTree *tree) //traversing the TokenTree in a depth-first manner, visiting all the nodes in the tree.
{
    bool enteredScope = false;
    int previousLocalOffset = -2;
    beforeChildren(tree, &enteredScope, previousLocalOffset);        
    for (int i = 0; i < MAX_CHILDREN; i++) 
    {
        TokenTree *child = tree->children[i];
        if (child != NULL) {
            buildSymbolTable(child);
        }
        afterChild(tree, i);
    }    
    afterChildren(tree);
    if (enteredScope) {     
        symbolTable->applyToAll(checkUsage);
        symbolTable->leave();
        localOffset = previousLocalOffset;
    }
    if (tree->sibling != NULL) {
        buildSymbolTable(tree->sibling);
    }
}

void buildIORoutines() //The buildIORoutines() function builds the symbol table for input/output (I/O) routines.
{
    TokenTree *outnl = new TokenTree();
    outnl->setDeclKind(DeclKind::FUNCTION);
    outnl->setLineNum(-1);
    outnl->setTokenString((char *) "outnl");
    outnl->setStringValue((char *) "outnl");
    outnl->setExprType(ExprType::VOID);

    TokenTree *inputc = new TokenTree();
    inputc->setDeclKind(DeclKind::FUNCTION);
    inputc->setLineNum(-1);
    inputc->setTokenString((char *) "inputc");
    inputc->setStringValue((char *) "inputc");
    inputc->setExprType(ExprType::CHAR);
    inputc->setHasReturn(true);
    inputc->addSibling(outnl);

    TokenTree *inputb = new TokenTree();
    inputb->setDeclKind(DeclKind::FUNCTION);
    inputb->setLineNum(-1);
    inputb->setTokenString((char *) "inputb");
    inputb->setStringValue((char *) "inputb");
    inputb->setExprType(ExprType::BOOL);
    inputb->setHasReturn(true);
    inputb->addSibling(inputc);

    TokenTree *input = new TokenTree();
    input->setDeclKind(DeclKind::FUNCTION);
    input->setLineNum(-1);
    input->setTokenString((char *) "input");
    input->setStringValue((char *) "input");
    input->setExprType(ExprType::INT);
    input->setHasReturn(true);
    input->addSibling(inputb);

    TokenTree *charDummy = new TokenTree();
    charDummy->setDeclKind(DeclKind::PARAM);
    charDummy->setLineNum(-1);
    charDummy->setTokenString((char *) "*dummy*");
    charDummy->setStringValue((char *) "*dummy*");
    charDummy->setExprType(ExprType::CHAR);
    charDummy->cancelCheckInit(false);
    charDummy->setIsUsed(true);

    TokenTree *outputc = new TokenTree();
    outputc->setDeclKind(DeclKind::FUNCTION);
    outputc->setLineNum(-1);
    outputc->setTokenString((char *) "outputc");
    outputc->setStringValue((char *) "outputc");
    outputc->setExprType(ExprType::VOID);
    outputc->children[0] = charDummy;
    outputc->addSibling(input);

    TokenTree *boolDummy = new TokenTree();
    boolDummy->setDeclKind(DeclKind::PARAM);
    boolDummy->setLineNum(-1);
    boolDummy->setTokenString((char *) "*dummy*");
    boolDummy->setStringValue((char *) "*dummy*");
    boolDummy->setExprType(ExprType::BOOL);
    boolDummy->cancelCheckInit(false);
    boolDummy->setIsUsed(true);

    TokenTree *outputb = new TokenTree();
    outputb->setDeclKind(DeclKind::FUNCTION);
    outputb->setLineNum(-1);
    outputb->setTokenString((char *) "outputb");
    outputb->setStringValue((char *) "outputb");
    outputb->setExprType(ExprType::VOID);
    outputb->children[0] = boolDummy;
    outputb->addSibling(outputc);

    TokenTree *intDummy = new TokenTree();
    intDummy->setDeclKind(DeclKind::PARAM);
    intDummy->setLineNum(-1);
    intDummy->setTokenString((char *) "*dummy*");
    intDummy->setStringValue((char *) "*dummy*");
    intDummy->setExprType(ExprType::INT);
    intDummy->cancelCheckInit(false);
    intDummy->setIsUsed(true);

    TokenTree *output = new TokenTree();
    output->setDeclKind(DeclKind::FUNCTION);
    output->setLineNum(-1);
    output->setTokenString((char *) "output");
    output->setStringValue((char *) "output");
    output->setExprType(ExprType::VOID);
    output->children[0] = intDummy;
    output->addSibling(outputb);

    buildSymbolTable(output);
}

void buildSymbolTable() 
{
    buildIORoutines();
    buildSymbolTable(syntaxTree);  
    TokenTree *main = (TokenTree *) symbolTable->lookupGlobal("main"); 
    if (main == NULL || main->getDeclKind() != DeclKind::FUNCTION  )  
    {        
        printf("ERROR(LINKER): A function named 'main()' must be defined.\n");
        numErrors++;
    }
    else if(main->getNumChildren()>1)
    {
        printf("ERROR(LINKER): A function named 'main()' must be defined.\n");
        numErrors++;
    }
}


