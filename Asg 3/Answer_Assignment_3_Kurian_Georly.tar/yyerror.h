#ifndef _YYERROR_H_
#define _YYERROR_H_
extern int lineNum;        
extern char *lastToken; 
extern int numErrors;   
void initErrorProcessing();    
#define YYERROR_VERBOSE
void yyerror(const char *msg); 
#endif