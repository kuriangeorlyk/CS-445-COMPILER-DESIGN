#ifndef TOKEN_TREE_H
#define TOKEN_TREE_H

#define MAX_CHILDREN 3
#include <stddef.h>

enum class NodeKind { DECLARATION, EXPRESSION, STATEMENT };
enum class DeclKind { FUNCTION, VARIABLE, PARAM };
enum class ExprKind { CONSTANT, CALL, ID, UID, OP, ASSIGN };

enum class StmtKind { COMPOUND, SELECTION, FOR, WHILE, RANGE, RETURN, BREAK };
enum class ExprType { INT, BOOL, CHAR, STRING, VOID, UNDEFINED };

class TokenTree {
    private:
        int tokenClass;
        int lineNum;
        char *tokenStr;         
        char cvalue;            
        int  nvalue;            
        char *svalue;           

        NodeKind nodeKind; //DECLARATION, EXPRESSION, STATEMENT 
        union {
            DeclKind declKind; //FUNCTION, VARIABLE, PARAM
            ExprKind exprKind; //CONSTANT, CALL, ID, UID, OP, ASSIGN
            StmtKind stmtKind; //COMPOUND, SELECTION, FOR, WHILE, RANGE, RETURN, BREAK 
        } subKind; //pack of three Kinds

        ExprType exprType = ExprType::UNDEFINED;
        char *exprName;
        bool _isArray = false;
        bool _isStatic = false;

        bool checkInitialized = true;
        bool _isUsed = false; 
        bool _isInitialized = false; 
        bool _hasReturn = false; 

        unsigned int memorySize = 1;
        int memoryOffset;
        bool _wasGenerated = false;
        bool _hasLastLine = false;
        
        int lastLine;

        void _printTree(int level, bool isChild, bool isSibling, int num, bool printWithoutType);
        void _setParent();
        void _setFunction();
    public:
        int alreadyDeclared=0;//parameter already declared then dont show tha message  seems to be not used if    
        TokenTree();
        void setTokenClass(int tc);
        int getTokenClass();
        void setLineNum(int line);
        int getLineNum();
        void setTokenString(char *str);
        char *getTokenString();
        void setCharValue(char c);
        char getCharValue();
        void setNumValue(int n);
        int getNumValue();

        void setStringValue(char *str);

        void setStringValue(char *str, bool duplicate);
        char *getStringValue();

        TokenTree *children[3] = {NULL};
        TokenTree *parent = NULL;
        TokenTree *sibling = NULL;
        TokenTree *function = NULL;

        void setParentAndFunction();
        TokenTree *getTopParent();
       
        int getNumSiblings(bool includeSelf);
        int getNumChildren();       
        bool hasParent(TokenTree *possibleParent, bool checkAllParents);

        void setNodeKind(NodeKind nk);
        NodeKind getNodeKind();
        void setDeclKind(DeclKind dk);
        DeclKind getDeclKind();
        void setExprKind(ExprKind ek);
        ExprKind getExprKind();
        void setStmtKind(StmtKind sk);
        StmtKind getStmtKind();
        void setExprType(ExprType et);

        ExprType getExprType();
        const char *getTypeString();
        bool isExprTypeUndefined();

        bool checkCascade();
        void setExprName(char *name);
        char *getExprName();

        void setIsArray(bool b);
        bool isArray();
        void setIsStatic(bool b);
        bool isStatic();

        void cancelCheckInit(bool applyToChildren); 
       
        void setIsUsed(bool b);
        bool isUsed();
       
        void setHasReturn(bool b);
        bool hasReturn();

        bool isConstantExpression();
        void addSibling(TokenTree *sibl);        
        void typeSiblings(ExprType type);  
        void staticSiblings();

        void printTree(bool);
        void printNode();
        void printNodeWithoutType();
        void printLine();

        bool shouldCheckInit();
        void setIsInitialized(bool b);
        bool isInitialized();
};

#endif