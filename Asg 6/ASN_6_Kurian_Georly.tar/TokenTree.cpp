#include <stdexcept>
#include <stdio.h>
#include <string.h>
#include "TokenTree.h"

extern int globalOffset;
extern int localOffset;
extern bool printMem;



TokenTree::TokenTree() {
    // Cunstructor - Initializer for class
}

void TokenTree::setTokenClass(int tc) {
    this->tokenClass = tc;
}

int TokenTree::getTokenClass() {
    return this->tokenClass;
}

void TokenTree::setLineNum(int line) {
    this->lineNum = line;
}

int TokenTree::getLineNum() {
    return this->lineNum;
}

void TokenTree::setTokenString(char *str) {
    this->tokenStr = strdup(str);
}

char *TokenTree::getTokenString() {
    return this->tokenStr;
}

void TokenTree::setCharValue(char c) {
    this->cvalue = c;
}

char TokenTree::getCharValue() {
    return this->cvalue;
}

void TokenTree::setNumValue(int n) {
    this->nvalue = n;
}

int TokenTree::getNumValue() {
    return this->nvalue;
}

void TokenTree::setStringValue(char *str) {
    setStringValue(str, true);
}

void TokenTree::setStringValue(char *str, bool duplicate) {
    if (duplicate) {
        this->svalue = strdup(str);
    } else {
        this->svalue = str;
    }
}

char *TokenTree::getStringValue() {
    return this->svalue;
}

void TokenTree::setParentAndFunction() 
{
    _setParent();
    _setFunction();
}

void TokenTree::_setParent() 
{
    for (int i = 0; i < MAX_CHILDREN; i++)
    {
        TokenTree *child = children[i];
        if (child != NULL) 
        {
            child->parent = this; //takes each child and sets its parent as curent node
            child->_setParent(); // recursive to trravers to down to set child's child parent(it is ti child)
        }
    }

    if (this->sibling != NULL) //current called node bcoms all the siblings paraent
    {
        sibling->parent = parent;
        sibling->_setParent();//recursive to travrse throuh siblings
    }
}

//A calls then A->funtion = A if there is no parent for called node
//and all sibling node's function object is also sets A
//and all child node's function object is also sets A
//Current nodes function object is the key to identify its a function or not
void TokenTree::_setFunction() 
{
    TokenTree *topParent = getTopParent(); //getting Top Most Node by calling getTopParent()
    //top node's Decl kind is FUNC then it stred to "function" also an object of TOKTRE
    if (topParent->getDeclKind() == DeclKind::FUNCTION) 
    { 
        function = topParent;//Now function is the top most node //TokenTree *function = NULL;
    }

    for (int i = 0; i < MAX_CHILDREN; i++) //start traversing
    {
        TokenTree *child = children[i];
        if (child != NULL) //if there is a child for the current node then 
            child->_setFunction(); //recurcive call 
    }

    if (sibling != NULL)  
    {
        sibling->_setFunction();
    }
}

//Travers through the Tree and Returns the top Most Node
TokenTree *TokenTree::getTopParent() 
{
    TokenTree *visitor = this; //visitor initialize with argument node
    while (visitor->parent != NULL) 
    {
        visitor = visitor->parent; //Traversing -> moves to its parent
    }
    return visitor; //after While loop the Topmost node (visitor) Returns
}

//Retuns the number of sibling nodes. It may be any nmber of sibling
int TokenTree::getNumSiblings(bool includeSelf)
{
    int count = includeSelf ? 1 : 0; // current node is not NULL then count becomes 1 and returns 1
    TokenTree *visitor = this; //visitor initialize with argument node
    while (visitor->sibling != NULL)
    {
        visitor = visitor->sibling; //Traversing and increments the counts
        count++;
    }
    return count; //returns count includeing the argument node too
}

//Returns the child node count
int TokenTree::getNumChildren()// Max node count is 2
{
    int counter = 0;
    for (int i = 0; i < MAX_CHILDREN; i++)// Traverse and checks for child Node     
    {
        if (children[i] != NULL) 
            counter++;
    }
    return counter; //returns th count of child nodes of the argument Node
}

//Checks there is any parent n ode for the argument Node
bool TokenTree::hasParent(TokenTree *possibleParent, bool checkAllParents)
{
    //printf("ARgument Node possibleParent  %s \n",possibleParent->getStringValue() );   
    if (possibleParent == NULL) //Argument node is empty then also returns False
        return false;

    TokenTree *visitor = this->parent; //takes current nodes Parent Nede
                                        //if no parent then While loop not wors and returns False
    //printf("visitor  %s \n",visitor->getStringValue() );    
    while (visitor != NULL) //if parent node is null then stops
    {
        if (visitor == possibleParent)  //argument Node reached then returns TRUE
            return true;                //ie. The nade have a Parent
                                        // it continues to the top most Node
        visitor = visitor->parent;//Traversing to parent node while reach the top
        //printf("in LOOP visitor  %s \n",visitor->getStringValue() );    
    }
    return false; //Returns there is no parent Node for the argument Node
}

//sets NodeKinds DECLARATION, EXPRESSION, STATEMENT
//this may unuse cose the kinds sets while kalling declaration kinds below
void TokenTree::setNodeKind(NodeKind nk) 
{
    this->nodeKind = nk;
}

//returns DECLARATION, EXPRESSION, STATEMENT 
NodeKind TokenTree::getNodeKind() 
{
    return this->nodeKind;
}

//First sets the NodeKind::DECLARATION
//Second sets the kinds FUNCTION, VARIABLE, PARAM
void TokenTree::setDeclKind(DeclKind dk) 
{
    this->nodeKind = NodeKind::DECLARATION;
    this->subKind.declKind = dk;
}

//only works inNodeKind::DECLARATION
//Returns the kinds FUNCTION, VARIABLE, PARAM
DeclKind TokenTree::getDeclKind() 
{
    // if (this->nodeKind != NodeKind::DECLARATION) {
    //     throw std::runtime_error("subKind is not NodeKind::DECLARATION!");
    // }
    return subKind.declKind;
}

//First sets the NodeKind::EXPRESSION
//Second sets the kinds CONSTANT, CALL, ID, UID, OP, ASSIGN
void TokenTree::setExprKind(ExprKind ek) 
{
    this->nodeKind = NodeKind::EXPRESSION;
    this->subKind.exprKind = ek;
}

//only works in NodeKind::EXPRESSION -> CONSTANT, CALL, ID, UID, OP, ASSIGN
//Returns INT, BOOL, CHAR, STRING, UNDEFINED
ExprKind TokenTree::getExprKind() 
{
    if (this->nodeKind != NodeKind::EXPRESSION) {
        throw std::runtime_error("subKind is not NodeKind::EXPRESSION!");
    }
    return subKind.exprKind;
}

//First sets the NodeKind::STATEMENT
//Second sets the kinds COMPOUND, SELECTION, FOR, WHILE, RANGE, RETURN, BREAK
void TokenTree::setStmtKind(StmtKind sk) 
{
    this->nodeKind = NodeKind::STATEMENT;
    this->subKind.stmtKind = sk;
}

//retuns the NodeKind if it is a STATEMENT
//only Works in COMPOUND, SELECTION, FOR, WHILE, RANGE, RETURN, BREAK kinds
StmtKind TokenTree::getStmtKind() {
    if (this->nodeKind != NodeKind::STATEMENT) {
        throw std::runtime_error("subKind is not NodeKind::STATEMENT!");
    }
    return subKind.stmtKind;
}
//Sets the Exp::Type { INT, BOOL, CHAR, STRING, UNDEFINED }
void TokenTree::setExprType(ExprType et) {
    this->exprType = et;
}

//retuns EXP::TYPE { INT, BOOL, CHAR, STRING, UNDEFINED }
ExprType TokenTree::getExprType() {
    return this->exprType;
}
//Exp::tpe name as a string used to print
//retuns EXP::TYPE { INT, BOOL, CHAR, STRING, UNDEFINED }
const char *TokenTree::getTypeString() 
{
    switch (getExprType()) {
        case ExprType::BOOL:
            return "type bool";
        case ExprType::CHAR:
            return "type char";
        case ExprType::INT:
            return "type int";
        case ExprType::VOID:
            return "type void";
        case ExprType::STRING:
            return "type string";    
        case ExprType::UNDEFINED:
            return "undefined type";
    }
    return "error";
}

//returns ture if an Exprssion's Exp:type is ExprType::UNDEFINED
bool TokenTree::isExprTypeUndefined() {
    return exprType == ExprType::UNDEFINED;
}

//returs True if all child are not ExprType::UNDEFINED
//if any child is UNDEFIND then retuns false
bool TokenTree::checkCascade() {
    bool b = true;
    for (int i = 0; i < MAX_CHILDREN; i++) {
        TokenTree *child = children[i];
        if (child != NULL && child->isExprTypeUndefined()) {
            b = false;
        }
    }
    return b;
}

//sets the Expession name (The parameter becomes the Exp::name)
//char *exprName; this is the variable
void TokenTree::setExprName(char *name) {
    this->exprName = strdup(name);
}

//returns the expession name(it may anythis previus fun: sets)
char *TokenTree::getExprName() {
    return this->exprName;
}

///sets current node ia an ARRAY if parameter is TRUE
void TokenTree::setIsArray(bool b) {
    this->_isArray = b;
}

bool TokenTree::isArray() {
    return this->_isArray;
}

//sets current node STATIC if parameter is TRUE
void TokenTree::setIsStatic(bool b) {
    this->_isStatic = b;
}

bool TokenTree::isStatic() {
    return this->_isStatic;
}

//IF  parameter false  unInitialize current node Only
//if parameter true then Current Node and ALL CHILD unInitialized
void TokenTree::cancelCheckInit(bool applyToChildren) 
{
    this->checkInitialized = false;
    if (applyToChildren) 
    {
        for (int i = 0; i < MAX_CHILDREN; i++) 
        {
            TokenTree *child = children[i];
            if (child != NULL) 
                child->cancelCheckInit(applyToChildren);
        }
    }
}

//Returs TRUE if it is not static and is Initialized
bool TokenTree::shouldCheckInit() //Returns Initilization Status
{
    return !_isStatic && this->checkInitialized;
}

//ONLY works in DECLARATION  NOT in EXPRESSION, STATEMENT
//checks DECLARATION of UNCTION, VARIABLE, PARAM
void TokenTree::setIsUsed(bool b) 
{
    
    // if (this->getNodeKind() != NodeKind::DECLARATION) {
    //     throw std::runtime_error("Cannot set isUsed on node that is not a DECLARATION kind .");
    // }

    _isUsed = b;
}

//depends void TokenTree::setIsUsed(bool b)  Method above
//retuns _isUsed
bool TokenTree::isUsed() {
    return _isUsed;
}

//Only Works in DECLARATION Declaration Kind NOT in EXPRESSION, STATEMENT
//Only works in VARIABLE, PARAM NodeKind NOT in FUNCTION 
// and it sets TRUE in _isInitialized if the argument is true
//cheks DECLARATION of VARIABLE, PARAM 
void TokenTree::setIsInitialized(bool b) 
{
    if (this->getNodeKind() != NodeKind::DECLARATION) {
        throw std::runtime_error("Cannot set isInitialized on node that is not DECLARATION kind .");
    }
    if (this->getDeclKind() == DeclKind::FUNCTION) {
        throw std::runtime_error("Cannot set isInitialized on node that is a FUNCTION kind.");
    }
    _isInitialized = b;
}
//depends void TokenTree::setIsInitialized(bool b)  Method above
//return _isInitialized variable (True or False)
bool TokenTree::isInitialized() 
{
    return _isInitialized;
}

void TokenTree::setHasReturn(bool b) {
    if (this->getNodeKind() != NodeKind::DECLARATION || this->getDeclKind() != DeclKind::FUNCTION) {
        throw std::runtime_error("Can only set 'hasReturn' on function declaration.");
    }
    _hasReturn = b;
}

bool TokenTree::hasReturn() {
    
    if (this->getNodeKind() != NodeKind::DECLARATION || this->getDeclKind() != DeclKind::FUNCTION) {
        throw std::runtime_error("Value of 'hasReturn' is only valid on function declaration.");
    }
    return _hasReturn;
}

//It returns tru if it is a CONSTANT exp kind
//else it checks EP kind ID CALL ASSIGN the returns false
//else it checks all the child nodes and checks any one is not aconstant
//if find any child isnot constant then return flase
//all child (if exists) are const then returns true 
bool TokenTree::isConstantExpression() 
{
    if (this->getNodeKind() != NodeKind::EXPRESSION) {
        throw std::runtime_error("Cannot only call 'isConstantExpression' on an expression.");
    }
    if (this->getExprKind() == ExprKind::CONSTANT) {
        return true;
    }
    
    else if (this->getExprKind() == ExprKind::ID || this->getExprKind() == ExprKind::CALL || this->getExprKind() == ExprKind::ASSIGN)
    {
        return false;
    } 

    else // ExprKind::OP
    { 
        bool allChildrenAreConst = true;
        for (int i = 0; i < MAX_CHILDREN; i++) 
        {
            TokenTree *child = this->children[i];

// if (this != NULL) 
// printf("[ Line %d ] THIS %s  \n",this->getLineNum(),this->getTokenString());  

if(strcmp(this->getTokenString(),"?")==0)
{
    allChildrenAreConst = false;
    break;
}

            if (child != NULL && !child->isConstantExpression()) 
            {
                //printf("[ Line %d ] CHILD %s  \n",child->getLineNum(),child->getTokenString());  
                allChildrenAreConst = false;
                break;
            }
        }
        return allChildrenAreConst;
    }    
}

void TokenTree::addSibling(TokenTree *sibl) {
    if (sibl == NULL) return;
    TokenTree *visitor = this;
    while (visitor->sibling != NULL) {
        visitor = visitor->sibling;
    }
    visitor->sibling = sibl;
    
}

void TokenTree::typeSiblings(ExprType type) 
{
    TokenTree *node = this;
    while (node != NULL) {
        node->setExprType(type);
        node = node->sibling;
    }
}

void TokenTree::staticSiblings() 
{
    TokenTree *node = this;
    while (node != NULL) {
        node->setIsStatic(true);
        node = node->sibling;
    }
}


void TokenTree::printTree(bool printWithoutType) //It called in main 
{
    this->_printTree(0, false, false, 0, printWithoutType);//cals _printTree()
}

//For first call level=0 num=0 and ischild False issibling false
void TokenTree::_printTree(int level, bool isChild, bool isSibling, int num, bool printWithoutType) 
{
    // Prints the dots. Fisrst level =0, so no .
    for (int i = 0; i < level; i++) 
    {
        printf(".   ");
    }
    if (isChild || isSibling) //first both false so not printing
    {
        if (isChild) {
            printf("Child: ");
        } else {
            printf("Sibling: ");
        }
        printf("%d  ", num);
    }
    if(printWithoutType)
        printNode();  //calles printNode(), 
    else
    {
        printNodeWithoutType();
    }
 
    // Print children
    for (int i = 0; i < MAX_CHILDREN; i++) //if in root node object MAX_CHILDREN>0 then have childs
    {

        TokenTree *child = children[i]; //accessing child nodes and recurcive call invokes to print . and "child"
        if (child != NULL) 
        {
            child->_printTree(level + 1, true, false, i, printWithoutType );// recur Call and comes from top and prints ". child"
        }
    }

    // Print sibling

    if (sibling != NULL) 
    {
        sibling->_isSibl=true; //I added to ientify siblings NEW
        if (isChild) 
        {
            sibling->_printTree(level, false, true, 1, printWithoutType); //child inside sibling prints
        } else 
        {
            sibling->_printTree(level, false, true, num + 1, printWithoutType); //prints ". sibling"
        }
    }
}

void TokenTree::printNode() 
{    
    switch (nodeKind) {
        case NodeKind::DECLARATION:
            switch (getDeclKind()) {
                case DeclKind::VARIABLE:
                    printf("Var: %s of ", getStringValue());  
                    if (isStatic()) 
                         printf("static ");
                    if (isArray()) 
                        printf("array of ");    
                    printf("%s ", getTypeString());   
                    break;
                case DeclKind::FUNCTION:
                    printf("Func: %s returns %s ", getStringValue(), getTypeString());
                    break;
                case DeclKind::PARAM:                    
                    if (isArray()){
                         printf("Parm: %s of ", getStringValue());
                         printf("array of ");
                         printf("%s ", getTypeString());
                    }
                    else{
                        printf("Parm: %s of ", getStringValue());
                        printf("%s ", getTypeString());
                    }
                default:
                    break;
            }
            break;
        case NodeKind::EXPRESSION:
            switch (getExprKind()) {
                case ExprKind::ASSIGN: 
                {
                    char *arrayStr = (char *) "";
                    if (isArray()) //In Some files <= treated as an array in ASN 6
                        arrayStr = (char *) "array of ";
                    printf("Assign: %s of %s%s ", getTokenString(), arrayStr, getTypeString());
                    break;
                }
                case ExprKind::CALL:
                    printf("Call: %s of %s ", getExprName(), getTypeString());
                    break;

                // case ExprKind::CONSTANT: {   
                //     char *arrayStr = (char *) "";
                //     if (getExprType() == ExprType::CHAR)
                //         if (isArray()) 
                //             arrayStr = (char *) "array of ";
                    
                //     if (getExprType() == ExprType::CHAR)
                //         printf("Const \'%c\'",getCharValue());
                //     else if((getExprType() == ExprType::INT))
                //         printf("Const %d ", getNumValue());
                //     else if (getExprType() == ExprType::BOOL)
                //         printf("Const %s ", getStringValue());
                //     break;
                //     printf(" of %s%s ",  arrayStr, getTypeString());   
                //    // printf("Const %s of %s%s ", getTokenString(), arrayStr, getTypeString());                    
                //     break;
                // }
                case ExprKind::CONSTANT: {   
                    printf("Const");
                    if (getExprType() == ExprType::CHAR) {
                        if (isArray()) {
                            printf(" \"%s\" of array of %s ", getStringValue(),getTypeString());
                        } else {
                            printf(" \'%c\' of %s ",getCharValue() ,getTypeString());
                        }                        
                    } 
                    else if((getExprType() == ExprType::INT))  
                    {
                        printf(" %d of %s ", getNumValue(),getTypeString());
                    }
                    else if (getExprType() == ExprType::BOOL)
                    {
                        printf(" %s of %s ", getStringValue(),getTypeString());
                    }
                    break;
                }

                case ExprKind::ID: {
                    char *staticStr = (char *) "";
                    char *arrayStr = (char *) "";
                    if (isStatic()) 
                        staticStr = (char *) "static ";
                        //staticStr = (char *) "";
                    if (isArray()) 
                       arrayStr = (char *) "array of ";
                       // arrayStr = (char *) "";
                    printf("Id: %s of %s%s%s ", getStringValue(), staticStr, arrayStr, getTypeString());
                    break;
                }
                case ExprKind::OP:
                    if(getNumChildren()==1 && strcmp(getTokenString(), "-")==0)
                        printf("Op: chsign of %s ", getTypeString());  
                    else if(getNumChildren()==1 && strcmp(getTokenString(), "*")==0)
                        printf("Op: sizeof of %s ", getTypeString());  
                    else if(getNumChildren()==1 && strcmp(getTokenString(), "not")==0)
                        printf("Op: not of %s ", getTypeString());
                    else                   
                        printf("Op: %s of %s ", getTokenString(),getTypeString()); 
                    break;
                default:
                 printf(" NULL"); 
                    break;
            }
            break;
        case NodeKind::STATEMENT:
            switch (getStmtKind()) {
                case StmtKind::BREAK:
                    printf("Break ");
                    break;
                case StmtKind::COMPOUND:
                    printf("Compound ");
                    break;
                case StmtKind::FOR:
                    printf("For ");
                    break;
                case StmtKind::WHILE:
                    printf("While ");
                    break;
                case StmtKind::RETURN:
                    printf("Return ");
                    break;
                case StmtKind::SELECTION:
                    printf("If ");
                    break;
                case StmtKind::RANGE:
                    printf("Range ");
                    break;    
            }
            break;
        default:
            break;
    }
    if (printMem)
        printMemory();
    printLine();
    printf("\n");
}

void TokenTree::printLine() //printng the linenumber at the end 
{
    printf("[line: %d]", getLineNum());
}

void TokenTree::printNodeWithoutType() 
{    
    switch (nodeKind) {
        case NodeKind::DECLARATION:
            switch (getDeclKind()) {
                case DeclKind::VARIABLE:
                    printf("Var: %s ", getStringValue()); 
                    break;
                case DeclKind::FUNCTION:
                    printf("Func: %s returns %s ", getStringValue(), getTypeString());
                    break;
                case DeclKind::PARAM:
                      printf("Parm: %s is ", getStringValue());
                      break;                   
                default:
                    break;
            }
            break;
        case NodeKind::EXPRESSION:
            switch (getExprKind()) {
                case ExprKind::ASSIGN: 
                    printf("Assign: %s ", getTokenString());
                    break;
                case ExprKind::CALL:
                    printf("Call: %s ", getExprName());
                    break;
                case ExprKind::CONSTANT:
                    printf("Const");
                    if (getExprType() == ExprType::CHAR)
                        printf(" \'%c\'",getCharValue());
                    else if((getExprType() == ExprType::INT))
                        printf(" %d ", getNumValue());
                    else if (getExprType() == ExprType::BOOL)
                        printf(" %s ", getStringValue());
                    break;
                case ExprKind::ID:
                    printf("Id: %s ", getStringValue());
                    break;
                case ExprKind::OP:
                    printf("Op: %s", getTokenString()); 
                    break;
                default:
                 printf(" NULL"); 
                    break;
            }
            break;
        case NodeKind::STATEMENT:
            switch (getStmtKind()) {
                case StmtKind::BREAK: printf("Break "); break;
                case StmtKind::COMPOUND:printf("Compound ");break;
                case StmtKind::FOR:printf("For ");break;
                case StmtKind::WHILE:printf("While ");break;
                case StmtKind::RETURN:printf("Return ");break;
                case StmtKind::SELECTION:printf("If ");break;
                case StmtKind::RANGE:printf("Range ");break;    
            }
            break;
        default:
            break;
    }
    if (printMem)
        printMemory();
    printLine();
    printf("\n");
}

int findLastSiblingMemSize (TokenTree *tnode)
{
    int latSiblingOfsetPlusSize=0;
    if(tnode->children[0] !=NULL)
    {
        TokenTree *visitor = tnode->children[0]; //visitor initialize with argument node
        while (visitor->sibling != NULL)
        {
            visitor = visitor->sibling; //Traversing and increments the counts
            if( strcmp(visitor->getMemoryTypeString(),"Local")==0  && visitor->isArray() ) 
            {
                latSiblingOfsetPlusSize=  abs(visitor->getMemorySize())  + abs(visitor->getMemoryOffset())-1 ; 
            }
            else if ( strcmp(visitor->getMemoryTypeString(),"Local")==0)
            {
                latSiblingOfsetPlusSize=  abs(visitor->getMemorySize())  + abs(visitor->getMemoryOffset()) ; 
            }
        }    
    }
    return latSiblingOfsetPlusSize;
}

int findChild0OfsetPlusSize (TokenTree *tnode)
{
    int child0OfsetPlusSize=0;
    if(  tnode->children[0] !=NULL &&   strcmp(tnode->children[0]->getMemoryTypeString(),"Local")==0  )
    {        
        child0OfsetPlusSize=  abs(tnode->children[0]->getMemorySize())  + abs(tnode->children[0]->getMemoryOffset());
        if(tnode->children[0]->isArray()) 
        {
            child0OfsetPlusSize= child0OfsetPlusSize - 1 ;
        } 
    }
    return child0OfsetPlusSize;
}

void TokenTree::printMemory() 
{   
    if (this->getMemoryType() != MemoryType::UNDEFINED )
    {
        if(this->getNodeKind() == NodeKind::DECLARATION && this->getDeclKind() == DeclKind::FUNCTION)
        {
            int funMemSize=2;
            if(getNumChildren()>1)
            {
                funMemSize+=(this->children[0]->getNumSiblings(true));
                funMemSize = funMemSize * -1; 
                this->setMemorySize(funMemSize);
                printf("[mem: %s loc: %d size: %d] " , getMemoryTypeString(),getMemoryOffset(),getMemorySize() );                
            }
            else
            {
                funMemSize = funMemSize * -1; 
                this->setMemorySize(funMemSize);
                printf("[mem: %s loc: %d size: %d] " , getMemoryTypeString(),getMemoryOffset(),getMemorySize() );                
            }
        }
        else  if(this->getNodeKind() == NodeKind::STATEMENT && this->getStmtKind() == StmtKind::COMPOUND)
        {
            int siblingCount=0;       
            if(this->children[0] !=NULL)
            {
                siblingCount=(this->children[0]->getNumSiblings(false));
            }
            int child0OfsetPlusSize=findChild0OfsetPlusSize(this);
            int latSiblingOfsetPlusSize = findLastSiblingMemSize(this);
            if(siblingCount>0 && latSiblingOfsetPlusSize>0)
            {
                latSiblingOfsetPlusSize = latSiblingOfsetPlusSize * -1; 
                this->setMemorySize(latSiblingOfsetPlusSize);
                printf("[mem: %s loc: %d size: %d] " , getMemoryTypeString(),getMemoryOffset(),getMemorySize() );                
            }
            else if(  this->children[0] !=NULL &&   strcmp(this->children[0]->getMemoryTypeString(),"Local")==0  )
            {
                child0OfsetPlusSize = child0OfsetPlusSize * -1; 
                this->setMemorySize(child0OfsetPlusSize);
                printf("[mem: %s loc: %d size: %d] " , getMemoryTypeString(),getMemoryOffset(),getMemorySize() );                
            }
            else
            {
                TokenTree *tnode = this->parent; 
                while ( true ) 
                {
                    if(( tnode->getNodeKind() == NodeKind::STATEMENT && tnode->getStmtKind() == StmtKind::COMPOUND ) || ( tnode->getNodeKind() == NodeKind::DECLARATION && tnode->getDeclKind() == DeclKind::FUNCTION)  || (tnode->getNodeKind() == NodeKind::STATEMENT && tnode->getStmtKind() == StmtKind::FOR) )
                    {
                    break;
                    }
                    else{
                        tnode = tnode->parent;   
                    }
                }
                this->setMemorySize(tnode->getMemorySize());
                printf("[mem: %s loc: %d size: %d] " , getMemoryTypeString(),getMemoryOffset(),this->getMemorySize()); 
            }            
        }
        else  if(this->getNodeKind() == NodeKind::STATEMENT && this->getStmtKind() == StmtKind::FOR)
        {
            int chldMem=((this->children[0]->getMemoryOffset())-1);
            this->setMemorySize(chldMem);
            printf("[mem: %s loc: %d size: %d] " , getMemoryTypeString(),getMemoryOffset(),getMemorySize() );
        }
        else
        {
            printf("[mem: %s loc: %d size: %d] " , getMemoryTypeString(),getMemoryOffset(),getMemorySize() );
        }
    }
}

//The passed argument Set as memorySize
void TokenTree::setMemorySize(unsigned int i) {
    this->memorySize = i;
}

//Returns MEM Size
unsigned int TokenTree::getMemorySize() {
    return this->memorySize;
}

//The passed argument Set as memoryType  LOCAL, LOCAL_STATIC, PARAM, GLOBAL, UNDEFINED
void TokenTree::setMemoryType(MemoryType mt) {
    this->memoryType = mt;
}

//Returns MEM TYPE
MemoryType TokenTree::getMemoryType() {
    return this->memoryType;
}

char *TokenTree::getMemoryTypeString() {
    switch (this->getMemoryType()) {
        case MemoryType::GLOBAL:
            return (char *) "Global";
        case MemoryType::LOCAL:
            return (char *) "Local";
        case MemoryType::LOCAL_STATIC:
            return (char *) "LocalStatic";
        case MemoryType::PARAM:
            return (char *) "Parameter";
        case MemoryType::UNDEFINED:
            return (char *) "Undefined";
        case MemoryType::NONE:
            return (char *) "None";    
        default:
            return (char *) "Invalid/Err";
    }
}

//Checks it is a GLOBAL Mem Type or not
bool TokenTree::isInGlobalMemory() 
{
    //If MemoryType::UNDEFINED Error Shows
    if (this->getMemoryType() == MemoryType::UNDEFINED) {
        throw std::runtime_error("isInGlobalMemory called on node with undefined memory type!");
    }
    //If MEMTYPE is GLOBAL OR LOCAL_STATIC then returns True else returns false
    if (this->getMemoryType() == MemoryType::GLOBAL || this->getMemoryType() == MemoryType::LOCAL_STATIC) 
    {
        return true;
    }
    return false;
}

//Sets Mem Offset
void TokenTree::setMemoryOffset(int i) 
{
    this->memoryOffset = i;
}

//Returns Mem Offset
int TokenTree::getMemoryOffset() 
{
    return this->memoryOffset;
}

void TokenTree::calculateMemoryOffset() 
{
    //If it is a Global MEM then *offset becomes &globalOffset 
    //If it is a LOCAL MEM then *offset becomes &localOffset
    int *offset = this->isInGlobalMemory() ? &globalOffset : &localOffset; // Pick between local and global offset
    // Copying offset to location
    int location = *offset; 

    //IF arg is an ARRAY and not a PARAM then Decrement offset 1
    if (this->isArray() && this->getMemoryType() != MemoryType::PARAM) 
    {
        location --; // Decrement offset if using an array
    }
    this->setMemoryOffset(location); // Set memory offset to location
    (*offset) -= this->getMemorySize(); // Reduce offset by size of array
}

void TokenTree::copyMemoryInfo(TokenTree *tree) 
{
    if (this == tree) 
    {
        throw std::runtime_error("Invalid pointer. Copy memory info called on self.");
    }
    this->setMemoryType(tree->getMemoryType());
    this->setMemorySize(tree->getMemorySize());
    this->setMemoryOffset(tree->getMemoryOffset());
}

int TokenTree::_calculateMemoryOfChildren() 
{
    int sum = 0;
    if (this->getNodeKind() == NodeKind::DECLARATION && this->getDeclKind() != DeclKind::FUNCTION && !this->isInGlobalMemory()) {
        sum += getMemorySize();
    }

    for (int i = 0; i < MAX_CHILDREN; i++) {
        TokenTree *child = this->children[i];
        if (child != NULL) {
            sum += child->_calculateMemoryOfChildren();
        }
    }

    if (this->sibling != NULL) {
        sum += sibling->_calculateMemoryOfChildren();
    }

    return sum;
}

void TokenTree::calculateMemoryOfChildren() 
{
    int sum = 0;
    for (int i = 0; i < MAX_CHILDREN; i++)
    {
        TokenTree *child = this->children[i];
        if (child != NULL) {
            sum += child->_calculateMemoryOfChildren();
        }
    }
    this->setMemorySize(2 + sum);
}

bool TokenTree::wasGenerated() 
{
    return _wasGenerated;
}

void TokenTree::setGenerated() 
{
    this->setGenerated(true, false);
}

void TokenTree::setGenerated(bool b) 
{
    setGenerated(true, false);
}

void TokenTree::setGenerated(bool b, bool applyToChildren) 
{
    this->_wasGenerated = b;

    if (!applyToChildren) {
        return;
    }
    for (int i = 0; i < MAX_CHILDREN; i++) {
        TokenTree *child = this->children[i];
        if (child != NULL) {
            child->setGenerated(b, applyToChildren);
        }
    }
}

bool TokenTree::hasLastLine() 
{
    return _hasLastLine;
}

void TokenTree::setHasLastLine(bool b) 
{
    this->_hasLastLine = b;
}

int TokenTree::getLastLine() 
{
    return this->lastLine;
}

void TokenTree::setLastLine(int line) 
{
    this->lastLine = line;
}